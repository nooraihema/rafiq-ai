"""
The Expression Engine — Phase 3 of the architecture document, as real code.

evaluate() walks any Expression tree and produces a number. It has never
heard of EXIM or Anex — every calculation rule the two Tour Operators
expressed differently in their source contracts (numeric columns vs. prose
formulas) becomes the same kind of tree by the time it reaches this module,
and this module treats them identically.

M0 change: evaluate() was a single if-isinstance chain in Phase 1 — every
new node type meant editing that one function, exactly the shared chokepoint
the rest of the architecture avoids. It is now a dispatch registry
(NODE_EVALUATORS). Adding a future node type is one new dataclass in
expressions.py plus one @register_node function here — zero lines changed
in this file's existing code.
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Callable

from contract_platform.contract_model.expressions import (
    Expression, Constant, RateRef, Add, Subtract, Multiply, PercentOf,
    Conditional, Compare, Lookup, Min, Max, Round,
)
from contract_platform.contract_model.vocabulary import RoundMode


@dataclass
class EvaluationContext:
    """Everything the evaluator needs to resolve a RateRef or Lookup against
    a specific booking. rate_values maps rate_id -> resolved numeric amount;
    lookup_tables maps table_ref -> {key: value}."""
    rate_values: dict[str, float]
    lookup_tables: dict[str, dict] = None

    def __post_init__(self):
        if self.lookup_tables is None:
            self.lookup_tables = {}


class EvaluationError(Exception):
    """Raised when a tree references a rate or table the context doesn't
    have — this must be a loud failure, never a silent zero, for exactly
    the same reason the Excel engine flags out-of-contract dates in red."""
    pass


# --- Registry dispatch -------------------------------------------------
#
# NODE_EVALUATORS maps an Expression subclass to the function that knows how
# to evaluate it. evaluate() itself is just a lookup; it never grows a new
# branch when a new node type is added.

NODE_EVALUATORS: dict[type, Callable[[Expression, "EvaluationContext"], float]] = {}


def register_node(node_type):
    def decorator(fn):
        NODE_EVALUATORS[node_type] = fn
        return fn
    return decorator


def evaluate(expr: Expression, ctx: EvaluationContext) -> float:
    fn = NODE_EVALUATORS.get(type(expr))
    if fn is None:
        raise EvaluationError(f"Unknown expression node type: {type(expr).__name__}")
    return fn(expr, ctx)


@register_node(Constant)
def _eval_constant(expr: Constant, ctx: EvaluationContext) -> float:
    # Percent constants are returned as their raw number (e.g. 50, not
    # 0.5) — PercentOf is responsible for the division. Keeping that logic
    # in one place avoids the classic "was this already divided by 100?"
    # bug appearing in two places.
    return expr.value


@register_node(RateRef)
def _eval_rateref(expr: RateRef, ctx: EvaluationContext) -> float:
    if expr.rate_id not in ctx.rate_values:
        raise EvaluationError(f"No value provided for rate_id={expr.rate_id!r}")
    return ctx.rate_values[expr.rate_id]


@register_node(Add)
def _eval_add(expr: Add, ctx: EvaluationContext) -> float:
    return evaluate(expr.left, ctx) + evaluate(expr.right, ctx)


@register_node(Subtract)
def _eval_subtract(expr: Subtract, ctx: EvaluationContext) -> float:
    return evaluate(expr.left, ctx) - evaluate(expr.right, ctx)


@register_node(Multiply)
def _eval_multiply(expr: Multiply, ctx: EvaluationContext) -> float:
    return evaluate(expr.left, ctx) * evaluate(expr.right, ctx)


@register_node(PercentOf)
def _eval_percent_of(expr: PercentOf, ctx: EvaluationContext) -> float:
    base_value = evaluate(expr.base, ctx)
    pct_value = evaluate(expr.percent, ctx)
    return base_value * (pct_value / 100.0)


@register_node(Compare)
def _eval_compare(expr: Compare, ctx: EvaluationContext) -> bool:
    left_val = evaluate(expr.left, ctx)
    right_val = evaluate(expr.right, ctx)
    ops = {
        ">": lambda a, b: a > b,
        "<": lambda a, b: a < b,
        ">=": lambda a, b: a >= b,
        "<=": lambda a, b: a <= b,
        "==": lambda a, b: a == b,
    }
    return ops[expr.op](left_val, right_val)


@register_node(Conditional)
def _eval_conditional(expr: Conditional, ctx: EvaluationContext) -> float:
    condition_result = evaluate(expr.condition, ctx)
    branch = expr.if_true if condition_result else expr.if_false
    return evaluate(branch, ctx)


@register_node(Lookup)
def _eval_lookup(expr: Lookup, ctx: EvaluationContext) -> float:
    table = ctx.lookup_tables.get(expr.table_ref)
    if table is None:
        raise EvaluationError(f"No lookup table provided for table_ref={expr.table_ref!r}")
    key = evaluate(expr.key_expr, ctx)
    if key not in table:
        raise EvaluationError(f"Key {key!r} not found in lookup table {expr.table_ref!r}")
    return table[key]


@register_node(Min)
def _eval_min(expr: Min, ctx: EvaluationContext) -> float:
    return min(evaluate(expr.left, ctx), evaluate(expr.right, ctx))


@register_node(Max)
def _eval_max(expr: Max, ctx: EvaluationContext) -> float:
    return max(evaluate(expr.left, ctx), evaluate(expr.right, ctx))


@register_node(Round)
def _eval_round(expr: Round, ctx: EvaluationContext) -> float:
    value = evaluate(expr.expr, ctx)
    if expr.mode == RoundMode.NEAREST:
        return round(value)
    if expr.mode == RoundMode.UP:
        return math.ceil(value)
    if expr.mode == RoundMode.DOWN:
        return math.floor(value)
    raise EvaluationError(f"Unknown round mode: {expr.mode!r}")
