"""
Post-Odeon-review Pricing Engine fixes: cross-period "Stay" pricing and
SOPN consumption. Both confined to pricing_engine/calculator.py -- no
Contract Model, Expression Engine, or adapter changes.

Verified before implementing (see the architectural review this follows):
no existing test relied on "the whole stay must fit inside one Season" as
a behavior, and every existing single-season booking resolves through the
identical tie-break rule as before, proven directly below by re-running
the exact real-data scenarios from M1/M2 unmodified.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, RoomType, Occupancy, Season, Rate, ContractScope, Extracted,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel, RateBasis, MealPlan
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking, PricingError
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope as build_anex_scope

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ANEX_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def _hi(value):
    return Extracted(value=value, confidence=ConfidenceLevel.HIGH, source_note="test fixture")


def _two_period_scope():
    """A minimal synthetic scope with two contiguous, adjoining periods at
    different rates -- Period A: 01.05-20.05 @ 50.00, Period B:
    21.05-30.06 @ 70.00 -- mirroring the exact shape Odeon's (and every
    other reviewed contract's) base rate table uses."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]

    period_a = Season(label="Period A", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 5, 20)))
    period_b = Season(label="Period B", start_date=_hi(date(2026, 5, 21)), end_date=_hi(date(2026, 6, 30)))
    rate_a = Rate(room_type_id=room.id, season_id=period_a.id, basis=RateBasis.PER_PERSON_PER_NIGHT,
                  meal_plan=MealPlan.ALL_INCLUSIVE, currency="USD", amount=_hi(50.00))
    rate_b = Rate(room_type_id=room.id, season_id=period_b.id, basis=RateBasis.PER_PERSON_PER_NIGHT,
                  meal_plan=MealPlan.ALL_INCLUSIVE, currency="USD", amount=_hi(70.00))

    return ContractScope(
        hotel=hotel, tour_operator=to, currency="USD",
        seasons=[period_a, period_b], room_types=[room], rates=[rate_a, rate_b],
    ), room


# --- Cross-period "Stay" pricing ---------------------------------------------

def test_stay_fully_inside_one_season_is_unaffected():
    """The universal pre-existing case: must still produce exactly one
    invoice line, identical to every test written before this change."""
    scope, room = _two_period_scope()
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 5), check_out=date(2026, 5, 12),  # 7 nights, all in Period A
        adults=2, children=0, infants=0,
    )
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 50.00
    assert invoice.lines[0].nights == 7
    assert invoice.total == 50.00 * 7 * 2


def test_stay_spanning_a_period_boundary_splits_into_two_segments():
    """The new capability: 3 nights in Period A (18,19,20 May) + 4 nights
    in Period B (21,22,23,24 May) = 7 total nights, priced per the 'Stay'
    convention -- each night from its own period's rate, not rejected and
    not pinned to check-in's rate."""
    scope, room = _two_period_scope()
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 18), check_out=date(2026, 5, 25),
        adults=2, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 2
    line_a, line_b = invoice.lines
    assert line_a.unit_rate == 50.00 and line_a.nights == 3
    assert line_b.unit_rate == 70.00 and line_b.nights == 4
    assert invoice.total == (50.00 * 3 * 2) + (70.00 * 4 * 2)


def test_stay_with_a_real_gap_between_seasons_is_still_rejected():
    """If no Season covers a given night at all (a genuine gap, not just a
    boundary crossing), the booking must still fail -- this is not the
    same case as spanning two adjoining periods."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Only Season", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 5, 20)))
    rate = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.PER_PERSON_PER_NIGHT, amount=_hi(50.00))
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    # 15-25 May: nights 21-24 fall in a real gap (no Season covers them).
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 15), check_out=date(2026, 5, 25),
                              adults=2, children=0, infants=0)
    issues = validate_booking(scope, booking)
    codes = [i.code for i in issues]
    assert "DATES_OUTSIDE_SEASON" in codes

    try:
        price_booking(scope, booking)
        assert False, "expected PricingError"
    except PricingError:
        pass


def test_real_exim_dr01_booking_still_resolves_identically_after_the_change():
    """Re-runs M1's exact real-PDF scenario unmodified -- proves the tie-
    break rule (first matching Rate by scope.rates order) is unchanged
    for a single-season stay."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 46.00
    assert invoice.total == 46.00 * 7 * 2


def test_real_anex_booking_still_resolves_identically_after_the_change():
    """Re-runs M2's exact real-PDF scenario unmodified, including the
    market-overlap ambiguity that already existed before this change
    (Anex's Promo Room has overlapping East European/Russia & CIS Seasons
    for the same calendar dates) -- proves the per-night resolution
    doesn't alter that pre-existing tie-break behavior either.

    Post-Slice-4 correction: Anex's real Triple Reduction SUPPLEMENT rule
    now splits a 3-adult booking into a standard-rate line and a
    reduced-rate line (previously 1 flat line, before that rule existed).
    The market tie-break this test actually checks (both markets give
    62.00 for these dates) is what's asserted here, and is unaffected."""
    scope = build_anex_scope(ANEX_FIXTURE)
    promo = scope.room_types[0]
    booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
                              adults=3, children=0, infants=0)
    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    assert len(adult_lines) == 2
    assert {l.unit_rate for l in adult_lines} == {62.00, 60.00}
    assert invoice.total == (62.00 * 7 * 2) + (60.00 * 7 * 1)


# --- SOPN consumption ---------------------------------------------------------

def test_single_occupancy_booking_uses_sopn_rate_when_available():
    """The specific gap found during the Odeon review: EXIM's real SOPN
    Rate (extracted since M1, never consumed) must now be selected for a
    1-adult booking, instead of PPPN x 1."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    room = scope.room_types[0]
    sopn_rate = next(r for r in scope.rates if r.basis == RateBasis.SINGLE_OCCUPANCY_PER_NIGHT)
    assert sopn_rate.amount.value == 73.60  # confirmed real value, extracted since M1

    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=1, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 73.60  # SOPN, not PPPN's 46.00
    assert invoice.total == 73.60 * 7 * 1
    assert "SOPN" in invoice.lines[0].description


def test_multi_adult_booking_is_unaffected_by_sopn_preference():
    """2+ adults must never trigger SOPN preference -- confirms the fix is
    purely additive for the adults==1 case."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 46.00  # PPPN, unchanged


def test_single_occupancy_falls_back_to_pppn_when_no_sopn_rate_exists():
    """Anex/Alltours/Rocket/Touring have no SOPN rates at all -- a
    1-adult booking there must still fall back to PPPN, not fail."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(1), children=_hi(0), infants=_hi(0))]
    season = Season(label="Season", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.PER_PERSON_PER_NIGHT, amount=_hi(40.00))
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 6, 1), check_out=date(2026, 6, 8),
                              adults=1, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 40.00  # fell back to PPPN, no SOPN rate existed


# --- Market disambiguation -----------------------------------------------------

def test_unspecified_market_reproduces_the_exact_pre_fix_behavior():
    """No market_id given (every pre-existing call site) must resolve
    identically to before this fix -- re-runs M2's exact real scenario
    unmodified, same as the earlier rate-resolution regression tests.

    Post-Slice-4 correction: the real Triple Reduction rule now applies
    to this 3-adult booking's 3rd adult, same as the sibling test above."""
    scope = build_anex_scope(ANEX_FIXTURE)
    promo = scope.room_types[0]
    booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
                              adults=3, children=0, infants=0)  # market_id omitted
    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    assert {l.unit_rate for l in adult_lines} == {62.00, 60.00}
    assert invoice.total == (62.00 * 7 * 2) + (60.00 * 7 * 1)


def test_market_id_disambiguates_rates_that_genuinely_differ():
    """East European and Russia & CIS genuinely disagree for real July
    2026 nights (confirmed against the actual PDF: 74.00 vs. 68.00 for
    the same calendar dates) -- specifying market_id must select the
    correct one instead of resolving by incidental list order."""
    scope = build_anex_scope(ANEX_FIXTURE)
    promo = scope.room_types[0]
    east_european = next(m for m in scope.markets if m.name == "East European")
    russia_cis = next(m for m in scope.markets if m.name == "Russia & CIS")

    # 3 nights, 1-4 July 2026: East European's period (29.06-31.08) gives
    # 74.00; Russia & CIS's period (29.06-25.07) gives 68.00 for the exact
    # same calendar nights.
    ee_booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 4),
                                 adults=3, children=0, infants=0, market_id=east_european.id)
    rc_booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 4),
                                 adults=3, children=0, infants=0, market_id=russia_cis.id)

    ee_invoice = price_booking(scope, ee_booking)
    rc_invoice = price_booking(scope, rc_booking)

    assert ee_invoice.lines[0].unit_rate == 74.00
    assert rc_invoice.lines[0].unit_rate == 68.00
    assert ee_invoice.total != rc_invoice.total  # the actual bug this fix closes


def test_market_agnostic_rates_remain_eligible_regardless_of_requested_market():
    """A Rate with market_id=None (every non-Anex adapter's normal shape)
    must stay eligible even when the booking specifies a market_id --
    proves the fix is additive, not a hard filter that would break single-
    market adapters if they ever gained a market_id-bearing booking."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Season", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.PER_PERSON_PER_NIGHT,
                amount=_hi(55.00))  # market_id left as None, as every EXIM/Alltours/Rocket/Touring Rate is
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 6, 1), check_out=date(2026, 6, 8),
                              adults=2, children=0, infants=0, market_id="some-market-id-that-does-not-exist-here")
    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 55.00  # still matched -- market-agnostic Rate stays eligible
