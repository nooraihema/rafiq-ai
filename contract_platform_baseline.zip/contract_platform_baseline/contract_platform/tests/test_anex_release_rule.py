"""
M4 (next slice) — Anex's Room Rates table has one more real, already-
regex-matched column that was never carried past the match:
RATE_ROW_RE's own `release` group ("... 15 rooms 05 release" / "...
10 rooms 05 release" -- printed on every one of the real 9 date-range
rows, always 5 in this contract). Maps directly onto ReleaseRule, a
Restriction type that has existed in the Contract Model since M0
(alongside MinMaxStay) but that no adapter has ever built until now --
confirmed by inspection before writing any code (zero references to
ReleaseRule anywhere outside validation's generic type-union handling).

No Contract Model change: ReleaseRule.days_before_arrival already exists,
shaped exactly for this value. No new validation invariant needed either
-- the existing generic Restriction walk (dangling-reference and
provenance checks) already covers any Union member, ReleaseRule
included, the same way it started covering MinMaxStay automatically.

Deliberately modeled as a booking-time WARNING, not a blocking ERROR --
unlike MinMaxStay's explicit, black-and-white "3/999 nights" printed
rule, "Release 5" doesn't state what happens once a booking falls inside
that window (rejected outright? subject to availability? flagged for
manual confirmation?). Real hotel contracts commonly still honor such
bookings on request, so a hard ERROR would invent a stricter rule than
the contract actually states. WARNING (a pre-existing Severity level,
"should be reviewed, doesn't block by itself") is the responsible,
minimally-committal choice, and only checked when the caller actually
supplies booking.context.booking_date -- every booking that doesn't
(every real booking test before this slice) is completely unaffected.

Also deliberately does NOT build the "rooms" allocation count (15/10)
printed in the same real column -- there is no Model concept for room
allocation/allotment counts, and adding one would be a real Contract
Model change with no evidence yet forcing its exact shape (does it
belong on Season? Rate? a new Allocation type?). Flagged, not guessed
at, same discipline as every other real gap this project has declined to
invent a shape for.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import ReleaseRule
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, price_booking, validate_booking, Severity,
)

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def test_scope_produces_nine_real_release_rules():
    """9 real date-range rows (4 East + 5 Russia & CIS), each printing
    'release 05' -- must produce exactly 9 ReleaseRule Restrictions, each
    scoped to its own Rate (applies_to_rate_id), days_before_arrival == 5,
    HIGH confidence (native text, not OCR)."""
    scope = build_contract_scope(FIXTURE_PATH)
    release_rules = [r for r in scope.restrictions if isinstance(r, ReleaseRule)]
    assert len(release_rules) == 9
    rate_ids = {r.id for r in scope.rates}
    for rule in release_rules:
        assert rule.applies_to_rate_id in rate_ids
        assert rule.days_before_arrival.value == 5
        assert rule.days_before_arrival.confidence.value == "high"


def test_release_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH)
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_booking_made_inside_the_release_window_gets_a_warning_not_an_error():
    """A booking made 3 days before a 21.05-28.06 East-season check-in --
    inside the real 5-day release window -- must produce a WARNING
    (not blocking), and price_booking() must still succeed."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=3, children=0, infants=0,
        context=BookingApplicabilityContext(booking_date=date(2026, 5, 22)),  # 3 days before check-in
    )
    issues = validate_booking(scope, booking)
    warnings = [i for i in issues if i.code == "BOOKING_INSIDE_RELEASE_PERIOD"]
    assert len(warnings) >= 1
    assert all(w.severity == Severity.WARNING for w in warnings)

    invoice = price_booking(scope, booking)  # must not raise
    assert invoice.total > 0


def test_booking_made_well_before_the_release_window_is_unaffected():
    """A booking made 24 days before check-in -- outside the real 5-day
    release window -- must produce no release warning at all."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=3, children=0, infants=0,
        context=BookingApplicabilityContext(booking_date=date(2026, 5, 1)),  # 24 days before check-in
    )
    issues = validate_booking(scope, booking)
    assert not any(i.code == "BOOKING_INSIDE_RELEASE_PERIOD" for i in issues)


def test_booking_with_no_booking_date_is_completely_unaffected():
    """No booking_date supplied (every pre-existing test/booking shape) --
    must produce no release warning, proving this slice is purely
    additive for every booking that doesn't opt in."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
                              adults=3, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert not any(i.code == "BOOKING_INSIDE_RELEASE_PERIOD" for i in issues)
