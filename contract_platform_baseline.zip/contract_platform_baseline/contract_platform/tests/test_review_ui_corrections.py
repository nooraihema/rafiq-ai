"""
M5, Slice 2 — review_ui's first slice: closing the loop the Commit Gate
(M5 Slice 1) explicitly opened. CommitResult.low_confidence_fields
already carries enough detail to route a human to what needs
correcting; nothing existed yet that let a human actually act on it.

Chosen over serialization as the next slice on the same evidence-driven
basis as the commit gate: this closes a complete, coherent product loop
(draft -> reject -> correct -> re-commit) that is now the one visibly
missing piece, using entirely real data already in the test suite
(Alltours' DZP occupancy stack, LOW-confidence since M3, already the
real rejection case in test_registry_commit_gate.py). Serialization
remains real and undecided, but doesn't complete a loop by itself the
way this does, and isn't coupled to this slice's design either way (a
mutation-based correction API works unchanged regardless of how a scope
is later serialized).

No Contract Model change. `Extracted` (value, confidence, provenance,
source_note) is already a plain, mutable dataclass -- correcting a field
is a direct, in-place mutation of the exact object entities.
iter_extracted() already yields, not a new traversal or a new field.
Reuses iter_extracted() directly rather than writing a second,
independently-maintained walk of "where do Extracted values live in
this model" -- the same reuse discipline the commit gate followed for
validate()/iter_extracted() itself.

The correction applied in these tests is a real, defensible reviewer
action -- confirming an existing LOW-confidence guess is correct and
upgrading its confidence -- not an invented replacement value. No new
contract fact is fabricated anywhere in this slice.
"""

import os

from contract_platform.contract_model.entities import ContractScope, iter_extracted
from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as build_alltours_scope
from contract_platform.review_ui.corrections import list_review_items, apply_correction, ReviewItem
from contract_platform.registry.store import commit_scope

ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_list_review_items_surfaces_the_real_low_confidence_occupancy_fields():
    """Alltours' real DZP scope (M3) has exactly two real LOW-confidence
    fields -- the occupancy stack's adults/children -- must be exactly
    what's surfaced for review, nothing more, nothing invented."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    items = list_review_items(scope)
    assert len(items) == 2
    assert all(isinstance(i, ReviewItem) for i in items)
    assert {i.field_name for i in items} == {"adults", "children"}
    assert all(i.confidence == ConfidenceLevel.LOW for i in items)


def test_apply_correction_upgrades_confidence_in_place():
    """Confirming the existing LOW-confidence value is correct (a real,
    defensible reviewer action -- not inventing a different number) must
    upgrade it to HIGH, and the field must no longer appear in
    list_review_items."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    item = next(i for i in list_review_items(scope) if i.field_name == "adults")

    applied = apply_correction(scope, item.entity_id, "adults", item.current_value, ConfidenceLevel.HIGH)
    assert applied is True

    updated = next((eid, fname, ex) for eid, fname, ex in iter_extracted(scope)
                    if eid == item.entity_id and fname == "adults")
    assert updated[2].confidence == ConfidenceLevel.HIGH
    assert updated[2].value == item.current_value

    remaining_fields = {i.field_name for i in list_review_items(scope)}
    assert "adults" not in remaining_fields
    assert "children" in remaining_fields  # untouched, still needs review


def test_apply_correction_to_an_unknown_field_returns_false_and_does_not_mutate():
    """A stale or wrong (entity_id, field_name) pair must fail loudly
    (return False), never silently no-op or apply to the wrong field."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    before = list_review_items(scope)

    applied = apply_correction(scope, "not-a-real-entity-id", "adults", 99, ConfidenceLevel.HIGH)
    assert applied is False
    assert list_review_items(scope) == before


def test_correcting_every_low_confidence_field_then_allows_commit():
    """The real end-to-end proof, and the whole point of this slice: a
    scope rejected by the commit gate (M5 Slice 1) for real LOW-confidence
    fields must become committable once every one of those fields is
    corrected -- closing the draft -> reject -> correct -> re-commit loop
    for the first time."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])

    first_attempt = commit_scope(scope)
    assert first_attempt.committed is False

    for item in list_review_items(scope):
        applied = apply_correction(scope, item.entity_id, item.field_name, item.current_value, ConfidenceLevel.HIGH)
        assert applied is True

    assert list_review_items(scope) == []

    second_attempt = commit_scope(scope)
    assert second_attempt.committed is True
    assert second_attempt.low_confidence_fields == []
