"""
First step toward the end-to-end product workflow (PDF -> extraction ->
validation -> review -> pricing): the commit gate.

Extracted's own docstring (contract_model/entities.py) has stated this
rule since M0: "A value with LOW confidence is legal to exist in a
*draft* Contract Model, but the Validation layer must never let one
through to a persisted Model." Nothing has ever enforced that rule --
every adapter test builds a scope and immediately prices against it,
bypassing the draft/persisted distinction the Model has always promised.

Chosen as the smallest valuable next slice over full serialization:
both validation.invariants.validate() (structural correctness) and
validation.confidence.assess() / entities.iter_extracted() (per-field
confidence) already exist and are already proven correct by every prior
slice's tests -- this needed only new orchestration glue, no new
extraction or pricing logic, and no Contract Model change.

Lives in registry/ -- an empty scaffolded package already present in the
codebase (TourOperator's own docstring already said "used by
semantic_adapters and registry"), not a new top-level module invented
for this slice.

Real evidence used directly, not synthetic fixtures: EXIM's real DR01
scope (native text, M1) has zero LOW-confidence fields -- a genuine
commit-ready scope. Alltours' real DZP scope (M3) has two real
LOW-confidence fields (the occupancy stack's adults/children, flagged
"not invented" since M3) -- a genuine, real commit-rejection case, not a
hypothetical one.

Serialization (persisting a committed scope to a durable form) is
deliberately not attempted in this slice -- there's nothing to persist
yet without the gate deciding what's committable in the first place.
"""

import os

from contract_platform.contract_model.entities import (
    ContractScope, RoomType, Extracted, Provenance,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as build_alltours_scope
from contract_platform.registry.store import commit_scope, get_committed_scope, CommitResult

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_a_fully_high_confidence_scope_commits_successfully():
    """EXIM's real DR01 scope (native text) has zero LOW-confidence
    fields -- must commit successfully and become retrievable."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    result = commit_scope(scope)
    assert isinstance(result, CommitResult)
    assert result.committed is True
    assert result.low_confidence_fields == []
    assert not any(i.severity.value == "error" for i in result.validation_issues)
    assert get_committed_scope(scope.id) is scope


def test_a_scope_with_real_low_confidence_fields_is_rejected():
    """Alltours' real DZP scope (M3) has two real LOW-confidence fields
    -- the occupancy stack's adults/children, flagged 'not invented'
    since M3 -- must be rejected, not silently committed."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    result = commit_scope(scope)
    assert result.committed is False
    assert len(result.low_confidence_fields) == 2
    assert get_committed_scope(scope.id) is None


def test_a_scope_with_a_blocking_validation_error_is_rejected():
    """A RoomType with no Rate at all is a real, simple, deliberately
    constructed blocking error (invariant #1, MISSING_BASE_RATE) --
    proves the gate honors validate() independently of the confidence
    check, not just the LOW-confidence path."""
    room = RoomType(canonical_code="XX01", display_name="Test Room")
    scope = ContractScope(room_types=[room])
    result = commit_scope(scope)
    assert result.committed is False
    assert any(i.code == "MISSING_BASE_RATE" for i in result.validation_issues)
    assert get_committed_scope(scope.id) is None


def test_committing_the_same_scope_id_twice_overwrites_not_duplicates():
    """Re-committing an already-committed scope (e.g. after a correction)
    must simply replace the stored version, not accumulate duplicates --
    the simplest behavior a dict-backed store already gives for free,
    not something requiring new logic."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    commit_scope(scope)
    commit_scope(scope)
    assert get_committed_scope(scope.id) is scope
