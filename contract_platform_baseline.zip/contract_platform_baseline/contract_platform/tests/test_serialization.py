"""
M5, Slice 4 — the persistence layer's first piece: a JSON round-trip for
ContractScope. This is "Part 7" of the original architecture, referenced
but explicitly deferred throughout the codebase (invariants.py: "Full
cross-contract cycle detection... requires a persistence layer --
deliberately deferred per Part 7"; registry/store.py: "no serialization
yet -- there is nothing to persist to a durable form until something has
decided what's committable"). Now that the commit gate (M5 Slice 1) and
the end-to-end proof (M5 Slice 3) exist, there is something worth
persisting durably -- today's registry is in-memory only, lost on
process restart.

Design chosen after inspecting the full type surface first (entities.py
+ expressions.py in full, not assumed): 20 dataclasses in entities.py, a
13-node Expression union, a 4-type Restriction union, a 4-type
ApplicabilityCondition union, 8 str-Enum vocabularies. A self-describing
scheme was chosen over a type-hint-driven one specifically because this
codebase uses `from __future__ import annotations` (entities.py's
dataclass field .type values are strings, not resolved type objects) --
resolving those correctly for every Union/Optional/Generic field shape
would be real, avoidable complexity. Instead, every encoded dict carries
its own "__type__" tag (the class name), so decoding never has to guess
or pre-know a field's expected type -- consistent with Part 5's "never
silently guess" discipline, just applied to the serialization boundary
instead of adapter extraction.

Reflection (dataclasses.fields()) drives the mechanical round-trip
rather than a per-class hardcoded field list (unlike iter_extracted's
deliberately explicit, hand-enumerated walk). This is not a departure
from house style: iter_extracted is a *filtering* walk making a business
judgment call (which fields matter for confidence review); this is a
*preserving* walk with no judgment call to make (every field must
survive, always) -- reflection is the right tool for a "preserve
everything, decide nothing" task, explicit enumeration is the right
tool for "select meaningfully" ones. The two explicit registries this
module does define (dataclass name -> class, enum name -> class) are
the same kind of registry applicability.py's register_condition and
this project's other type dispatch tables already use.

Proven against two real scopes chosen for type-surface coverage, not
arbitrarily: EXIM's DR01 (MinMaxStay Restriction, PaymentRule with a
bare, non-Extracted Expression, CHILD_PCT AgeCondition rules, deep
Expression trees with Subtract/PercentOf/Constant/RateRef) and
Alltours' DZP (StayLengthCondition, AgeCondition role=ADULT,
CancellationRule with a bare Expression in CalculationUnit.NIGHTS) --
between them, every Restriction and ApplicabilityCondition subtype
built by any real adapter so far is exercised at least once.
"""

import json
import os
from datetime import date

from contract_platform.contract_model.entities import ContractScope
from contract_platform.contract_model.serialization import (
    serialize_scope, deserialize_scope, SerializationError,
)
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as build_alltours_scope
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, GuestAge, price_booking,
)
from contract_platform.contract_model.vocabulary import GuestType

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_serialize_scope_produces_valid_json():
    """The output must be real, parseable JSON -- not a Python repr, not
    pickle -- proven by round-tripping through the stdlib json module
    directly, independent of this project's own deserializer."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    raw = serialize_scope(scope)
    assert isinstance(raw, str)
    parsed = json.loads(raw)  # must not raise
    assert isinstance(parsed, dict)


def test_exim_scope_round_trips_with_identical_pricing():
    """The real end-to-end proof: a real 3-adult booking must price
    identically on the original scope and on a scope that has been
    serialized to JSON and deserialized back -- not just structurally
    similar, byte-identical invoice totals and line counts."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    restored = deserialize_scope(serialize_scope(scope))

    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=3, children=0, infants=0)

    original_invoice = price_booking(scope, booking)
    restored_invoice = price_booking(restored, booking)

    assert restored_invoice.total == original_invoice.total
    assert len(restored_invoice.lines) == len(original_invoice.lines)
    assert [l.unit_rate for l in restored_invoice.lines] == [l.unit_rate for l in original_invoice.lines]


def test_exim_scope_round_trips_with_full_structural_equality():
    """Every field, not just the ones pricing happens to touch, must
    survive -- including PaymentRule (a bare, non-Extracted Expression)
    and MinMaxStay (a contract-wide Restriction), neither exercised by
    price_booking() at all."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    restored = deserialize_scope(serialize_scope(scope))
    assert restored == scope
    assert len(restored.payment_rules) == len(scope.payment_rules) == 4
    assert len(restored.restrictions) == len(scope.restrictions) == 1


def test_alltours_scope_round_trips_with_identical_pricing():
    """Covers the Restriction/ApplicabilityCondition/Expression shapes
    EXIM doesn't: StayLengthCondition, AgeCondition(role=ADULT),
    CancellationRule's bare Expression in CalculationUnit.NIGHTS.
    A real 2-adult booking with one identified senior guest must price
    identically before and after the round trip."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    restored = deserialize_scope(serialize_scope(scope))

    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
        adults=2, children=0, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.ADULT, age=65),
            GuestAge(role=GuestType.ADULT, age=45),
        ]),
    )
    original_invoice = price_booking(scope, booking)
    restored_invoice = price_booking(restored, booking)

    assert restored_invoice.total == original_invoice.total
    assert {l.unit_rate for l in restored_invoice.lines} == {l.unit_rate for l in original_invoice.lines}
    assert len(scope.cancellation_rules) == len(restored.cancellation_rules) == 1


def test_expression_trees_round_trip_with_structural_equality():
    """A real, deep Expression tree (EXIM's 3rd Adult Amount Reduction:
    Subtract(RateRef, Constant)) must reconstruct into an equal tree, not
    just an equal evaluated result."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    restored = deserialize_scope(serialize_scope(scope))
    original_rule = next(r for r in scope.pricing_rules if r.applies_to_pax_number == 3)
    restored_rule = next(r for r in restored.pricing_rules if r.applies_to_pax_number == 3)
    assert restored_rule.calculation.value == original_rule.calculation.value


def test_an_unrecognized_type_tag_fails_loudly_not_silently():
    """A corrupted or foreign JSON payload must raise a clear error, per
    Part 5's discipline extended to the serialization boundary -- never
    silently construct the wrong object or drop data."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    raw = serialize_scope(scope)
    corrupted = raw.replace('"ContractScope"', '"NotARealType"')
    try:
        deserialize_scope(corrupted)
        assert False, "expected SerializationError for an unrecognized type tag"
    except SerializationError:
        pass
