"""
M4 (next slice) — Alltours' page 1 "7. Special Reduction" section has two
real Longstay tiers: "Longstay from 21. nights reduction for all rooms:
10%/10%/10%" (Periods I/II/III) and "Longstay from 29nights* reduction
... 12%/12%/12%". Both cleanly OCR (confirmed by regex match against the
real text before writing any production code, same discipline as every
prior slice), same section as the Senior (60+, 10%) reduction.

Longstay was chosen over Senior for this slice, per instructions
("whichever requires the smallest change and exercises the existing
ApplicabilityConditions on real bookings"): StayLengthCondition needs
only BookingRequest.check_in/check_out, already present on every booking
-- Senior's AgeCondition needs a populated BookingApplicabilityContext
with adult guest ages, a heavier end-to-end setup for the same amount of
real adapter evidence.

Only the 21-night tier is built as a PricingRule this slice. The
29-night tier is real, parseable data but deliberately NOT built:
composition.py's own docstring already flagged "no real contract data
yet has two PricingRules simultaneously applicable to the same booking"
as an honest, deferred limitation. A stay of 30+ nights genuinely
satisfies BOTH tiers' StayLengthCondition, and the source contract states
no explicit exclusivity/supersession between them (no "the higher tier
replaces the lower" language, no overlap-resolution footnote found on
inspection) -- picking a tie-break (e.g. "higher tier wins") would be
encoding business logic the contract doesn't state, which Part 5
forbids. Flagged in the adapter's own comment, not guessed at.

Also required a small, evidence-driven pricing_engine fix (not a Model
change -- StayLengthCondition.max_nights was already Optional in the
Model): _match_stay_length crashed on a None max_nights. Real data has
no printed ceiling for "from 21 nights" -- fixed to treat max_nights=None
as open-ended, same Optional-field idiom used everywhere else in this
codebase, proven by a dedicated unit test in
test_applicability_and_composition.py before this file's tests.
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.contract_model.entities import StayLengthCondition
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_dzp_scope_produces_four_real_longstay_rules():
    """One SUPPLEMENT rule per Season (2x Period I + Period II + Period
    III = 4), each gated by a real StayLengthCondition(min_nights=21,
    max_nights=None), room_type_id=None (real 'for all rooms' scope, same
    as the 3rd Adult Reduction slice), applies_to_pax_number=None (a
    whole-party reduction, not a numbered slot).

    Filtered to StayLengthCondition-gated rules specifically: scope.
    pricing_rules also holds the real Senior Discount rules (built in a
    later slice, AgeCondition-gated), which aren't this test's concern."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    longstay_rules = [
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT and r.applies_to_pax_number is None
        and r.applicability and isinstance(r.applicability[0], StayLengthCondition)
    ]
    assert len(longstay_rules) == 4
    for rule in longstay_rules:
        assert rule.room_type_id is None
        assert len(rule.applicability) == 1
        cond = rule.applicability[0]
        assert isinstance(cond, StayLengthCondition)
        assert cond.min_nights.value == 21
        assert cond.max_nights is None


def test_longstay_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_a_21_night_booking_prices_the_whole_party_at_the_real_reduced_rate():
    """The real end-to-end proof: a 21-night DZP booking (2 adults, the
    one confirmed occupancy combo) in Period II (66.00 PPPN) must price
    every adult at the real 10%-reduced rate (66.00 * 0.9 = 59.40), not
    the plain 66.00 -- and the booking's own StayLengthCondition, not
    just a hand-called rule_applies(), is what selects it."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 6, 11),
                              adults=2, children=0, infants=0)  # 21 nights, inside Period II
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 66.00 * 0.9
    assert invoice.total == 66.00 * 0.9 * 21 * 2


def test_a_20_night_booking_is_unaffected_by_the_longstay_rule():
    """One night short of the real 21-night floor -- must price at the
    plain rate, proving the StayLengthCondition genuinely gates the rule
    rather than always applying."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 6, 10),
                              adults=2, children=0, infants=0)  # 20 nights
    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 66.00


def test_a_much_longer_stay_still_matches_the_open_ended_condition():
    """A stay well past 21 nights (35 nights, still inside Period II's
    21.05-28.06 window so it stays a single rate segment) must still
    match -- proves max_nights=None really means open-ended, not an
    accidental upper bound at exactly 21."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 6, 25),
                              adults=2, children=0, infants=0)  # 35 nights
    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 66.00 * 0.9
