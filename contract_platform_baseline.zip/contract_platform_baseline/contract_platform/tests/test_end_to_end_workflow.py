"""
M5, Slice 3 — the first true end-to-end proof: PDF -> extraction ->
commit gate -> (review + correction, where needed) -> registry
retrieval -> pricing, as one continuous chain.

Inspection before writing any test here found that every M5 piece
(commit_scope, list_review_items/apply_correction, price_booking) was
already fully correct and already composed cleanly by hand -- proven by
directly scripting the chain against real EXIM and Alltours fixtures
before writing a single test: both flows worked with zero new
production code. That is this slice's actual, honestly-reported
finding: the gap was in test coverage of the *composition*, not in any
individual piece. Every M5 test up to this point proved one function in
isolation (commit_scope alone, list_review_items/apply_correction
alone) -- nothing had ever proven that a scope retrieved from the
registry (get_committed_scope), rather than the adapter's direct return
value, is what price_booking() actually receives in a real workflow, or
that the full "rejected -> corrected -> re-committed -> priced" path
produces the right real numbers together, not just at each isolated
step.

No new abstraction was introduced (no workflow.py wrapper function) --
there is no evidence yet that one is needed. The existing layered
functions already compose legibly by direct calls; inventing a
wrapper now would be exactly the kind of speculative design this
project has consistently avoided. If a real caller (a future CLI or API
layer) later needs one, that will be built when that layer exists, not
speculatively here.

M5, Slice 6 addition: after M5 Slice 5 wired disk persistence into the
registry, the one combination still untested was review_ui correction
*together with* persistence -- every persistence test used EXIM (never
needs review), and every review_ui test used the in-memory-only
registry. test_a_scope_needing_review_survives_a_restart_after_persisted_correction
closes that: a scope that needed correction, got corrected, and was
committed with storage_dir must still recover correctly (and price
correctly) after the in-memory cache is cleared, not just scopes that
committed cleanly on the first attempt. Found, as with every other
composition proof in this project, by scripting the combination by hand
before writing the test -- it worked with zero new production code.
"""

import os
import tempfile
from datetime import date

from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as build_alltours_scope
from contract_platform.registry import store as registry_store
from contract_platform.registry.store import commit_scope, get_committed_scope
from contract_platform.review_ui.corrections import list_review_items, apply_correction
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_a_fully_high_confidence_scope_flows_straight_through_to_a_priced_booking():
    """EXIM's real DR01 scope commits on the first attempt (no LOW-
    confidence fields) -- the simple path. Prices a real 7-night, 2-adult
    booking using the scope retrieved from the registry, not the
    adapter's direct return value, proving that hand-off is real."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    result = commit_scope(scope)
    assert result.committed is True

    committed_scope = get_committed_scope(scope.id)
    room = committed_scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    assert not any(i.severity.value == "error" for i in validate_booking(committed_scope, booking))

    invoice = price_booking(committed_scope, booking)
    assert invoice.total == 46.00 * 7 * 2


def test_a_scope_needing_review_flows_through_correction_to_a_priced_booking():
    """The full real path this slice exists to prove end-to-end:
    Alltours' real DZP scope is rejected on the first commit attempt (2
    real LOW-confidence occupancy fields, since M3), gets corrected via
    review_ui, commits successfully on the second attempt, and the
    scope retrieved from the registry afterward prices a real booking
    correctly -- draft -> reject -> correct -> re-commit -> price, as
    one continuous chain, for the first time."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])

    first_attempt = commit_scope(scope)
    assert first_attempt.committed is False
    assert get_committed_scope(scope.id) is None

    for item in list_review_items(scope):
        assert apply_correction(scope, item.entity_id, item.field_name, item.current_value, ConfidenceLevel.HIGH)

    second_attempt = commit_scope(scope)
    assert second_attempt.committed is True

    committed_scope = get_committed_scope(scope.id)
    room = committed_scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
                              adults=2, children=0, infants=0)
    assert not any(i.severity.value == "error" for i in validate_booking(committed_scope, booking))

    invoice = price_booking(committed_scope, booking)
    assert invoice.total == 66.00 * 7 * 2  # real Period II rate, confirmed since M3


def test_a_rejected_scope_is_not_retrievable_through_the_registry():
    """The commit gate must be a real gate for the registry-mediated
    path specifically: a rejected scope must never be retrievable via
    get_committed_scope, even though the caller still holds the
    in-memory object directly (this slice doesn't claim to prevent
    that -- only that the registry itself never hands out an
    uncommitted scope)."""
    scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    result = commit_scope(scope)
    assert result.committed is False
    assert get_committed_scope(scope.id) is None


def test_multiple_committed_scopes_coexist_independently_in_the_registry():
    """Two real, independently-built scopes (EXIM and a corrected
    Alltours) committed in the same process must not interfere with
    each other -- each retrievable by its own id, each pricing
    correctly on its own real numbers."""
    exim_scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    commit_scope(exim_scope)

    alltours_scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
    for item in list_review_items(alltours_scope):
        apply_correction(alltours_scope, item.entity_id, item.field_name, item.current_value, ConfidenceLevel.HIGH)
    commit_scope(alltours_scope)

    assert get_committed_scope(exim_scope.id) is exim_scope
    assert get_committed_scope(alltours_scope.id) is alltours_scope
    assert exim_scope.id != alltours_scope.id


def test_a_scope_needing_review_survives_a_restart_after_persisted_correction():
    """The one combination M5 Slices 5 and 6 hadn't proven together:
    review_ui correction *and* disk persistence, in the same chain.
    Alltours' real DZP scope is rejected, corrected via review_ui, and
    committed with storage_dir -- then the in-memory cache is cleared
    (simulating a process restart) and the scope must still recover
    correctly from disk and price a real booking identically to before
    the restart. Every prior persistence test used EXIM (never needs
    review); every prior review test used the in-memory-only registry.
    This is the first proof that a corrected scope's correction survives
    the round trip to disk, not just its originally-extracted fields."""
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])

        first_attempt = commit_scope(scope, storage_dir=storage_dir)
        assert first_attempt.committed is False

        for item in list_review_items(scope):
            assert apply_correction(scope, item.entity_id, item.field_name, item.current_value, ConfidenceLevel.HIGH)

        second_attempt = commit_scope(scope, storage_dir=storage_dir)
        assert second_attempt.committed is True

        room = scope.room_types[0]
        booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
                                  adults=2, children=0, infants=0)
        before_restart_invoice = price_booking(scope, booking)

        registry_store._COMMITTED_SCOPES.pop(scope.id)  # simulate a process restart

        recovered = get_committed_scope(scope.id, storage_dir=storage_dir)
        assert recovered is not None
        assert recovered is not scope
        assert list_review_items(recovered) == []  # the correction itself survived the round trip

        after_restart_invoice = price_booking(recovered, booking)
        assert after_restart_invoice.total == before_restart_invoice.total == 66.00 * 7 * 2
