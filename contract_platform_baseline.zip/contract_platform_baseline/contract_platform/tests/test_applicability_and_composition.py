"""
Foundation Hardening II (pre-M4) — Applicability and Composition.

Proves the two new, independent concerns work correctly:
  - applicability.py: does a single PricingRule apply to a single booking
  - composition.py: in what order do multiple applicable rules combine

And proves the integration end-to-end against real Anex data: a family
booking with a child priced through pricing_engine.calculator.price_booking()
itself, not evaluated by hand in a test the way M2 had to.

Also proves backward compatibility: every booking shape that worked before
this change (no context, no children) still produces byte-identical results.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, RoomType, Occupancy, Season, Rate, PricingRule,
    ContractScope, Extracted, StayLengthCondition, BookingDateCondition,
    DaysBeforeArrivalCondition, AgeCondition,
)
from contract_platform.contract_model.vocabulary import (
    ConfidenceLevel, RateBasis, RuleKind, GuestType, CalculationUnit,
)
from contract_platform.contract_model.expressions import Constant
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.applicability import rule_applies
from contract_platform.pricing_engine.composition import order_rules, DEFAULT_COMPOSITION_ORDER
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, GuestAge, price_booking, validate_booking,
)
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def _hi(value):
    return Extracted(value=value, confidence=ConfidenceLevel.HIGH, source_note="test fixture")


def _rule(kind, applicability=None):
    return PricingRule(
        kind=kind, season_id="season-1",
        calculation=_hi(Constant(1, CalculationUnit.USD)),
        applicability=applicability or [],
    )


def _booking(check_in, check_out, context=None):
    return BookingRequest(
        room_type_id="room-1", check_in=check_in, check_out=check_out,
        adults=2, children=1, infants=0, context=context,
    )


# --- Applicability: each condition type in isolation ------------------------

def test_rule_with_no_applicability_always_applies():
    rule = _rule(RuleKind.SUPPLEMENT)
    booking = _booking(date(2026, 5, 1), date(2026, 5, 8))
    assert rule_applies(rule, booking) is True


def test_stay_length_condition_matches_and_rejects():
    rule = _rule(RuleKind.SPO_OFFER, [StayLengthCondition(min_nights=_hi(7), max_nights=_hi(21))])
    long_enough = _booking(date(2026, 5, 1), date(2026, 5, 10))   # 9 nights
    too_short = _booking(date(2026, 5, 1), date(2026, 5, 4))      # 3 nights
    assert rule_applies(rule, long_enough) is True
    assert rule_applies(rule, too_short) is False


def test_stay_length_condition_with_no_max_nights_is_open_ended():
    """Real data (Alltours' 'Longstay from 21 nights') gives only a floor,
    no printed ceiling -- max_nights=None must mean 'no upper bound', not
    crash on a missing .value. A stay far longer than the floor must still
    match."""
    rule = _rule(RuleKind.SUPPLEMENT, [StayLengthCondition(min_nights=_hi(21), max_nights=None)])
    at_the_floor = _booking(date(2026, 5, 1), date(2026, 5, 22))    # 21 nights
    well_past_it = _booking(date(2026, 5, 1), date(2026, 7, 1))     # 61 nights
    below_it = _booking(date(2026, 5, 1), date(2026, 5, 15))        # 14 nights
    assert rule_applies(rule, at_the_floor) is True
    assert rule_applies(rule, well_past_it) is True
    assert rule_applies(rule, below_it) is False


def test_booking_date_condition_matches_and_rejects_and_fails_safe_without_context():
    rule = _rule(RuleKind.SPO_OFFER, [BookingDateCondition(
        from_date=_hi(date(2025, 7, 24)), to_date=_hi(date(2026, 4, 30)),
    )])
    in_window = _booking(
        date(2026, 5, 1), date(2026, 5, 8),
        context=BookingApplicabilityContext(booking_date=date(2026, 1, 15)),
    )
    out_of_window = _booking(
        date(2026, 5, 1), date(2026, 5, 8),
        context=BookingApplicabilityContext(booking_date=date(2026, 6, 1)),
    )
    no_context = _booking(date(2026, 5, 1), date(2026, 5, 8))

    assert rule_applies(rule, in_window) is True
    assert rule_applies(rule, out_of_window) is False
    assert rule_applies(rule, no_context) is False  # fail-safe: can't verify, so it doesn't apply


def test_days_before_arrival_condition_matches_and_rejects():
    rule = _rule(RuleKind.SPO_OFFER, [DaysBeforeArrivalCondition(min_days=_hi(14), max_days=_hi(90))])
    booked_early = _booking(
        date(2026, 6, 1), date(2026, 6, 8),
        context=BookingApplicabilityContext(booking_date=date(2026, 3, 1)),  # 92 days before -> just over, test boundary below
    )
    booked_just_in_time = _booking(
        date(2026, 6, 1), date(2026, 6, 8),
        context=BookingApplicabilityContext(booking_date=date(2026, 5, 10)),  # 22 days before
    )
    booked_too_late = _booking(
        date(2026, 6, 1), date(2026, 6, 8),
        context=BookingApplicabilityContext(booking_date=date(2026, 5, 30)),  # 2 days before
    )
    assert rule_applies(rule, booked_just_in_time) is True
    assert rule_applies(rule, booked_too_late) is False


def test_age_condition_matches_the_right_guest_and_rejects_others():
    rule = _rule(RuleKind.CHILD_POLICY, [AgeCondition(
        role=GuestType.CHILD, min_age=_hi(6), max_age=_hi(12.99),
    )])
    with_matching_child = _booking(
        date(2026, 5, 1), date(2026, 5, 8),
        context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.CHILD, age=8)]),
    )
    with_toddler_only = _booking(
        date(2026, 5, 1), date(2026, 5, 8),
        context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.CHILD, age=3)]),
    )
    senior_condition = _rule(RuleKind.SUPPLEMENT, [AgeCondition(
        role=GuestType.ADULT, min_age=_hi(60), max_age=_hi(120),
    )])
    with_senior = _booking(
        date(2026, 5, 1), date(2026, 5, 8),
        context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.ADULT, age=65)]),
    )

    assert rule_applies(rule, with_matching_child) is True
    assert rule_applies(rule, with_toddler_only) is False
    assert rule_applies(senior_condition, with_senior) is True  # same condition type, ADULT role (Alltours Senior discount shape)


def test_age_condition_with_no_max_age_is_open_ended():
    """Real data (Alltours' 'Senior from 60 years') gives only a floor, no
    printed ceiling -- max_age=None must mean 'no upper bound', not crash
    on a missing .value. A guest far past the floor must still match."""
    rule = _rule(RuleKind.SUPPLEMENT, [AgeCondition(role=GuestType.ADULT, min_age=_hi(60), max_age=None)])
    at_the_floor = _booking(date(2026, 5, 1), date(2026, 5, 8),
                             context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.ADULT, age=60)]))
    well_past_it = _booking(date(2026, 5, 1), date(2026, 5, 8),
                             context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.ADULT, age=95)]))
    below_it = _booking(date(2026, 5, 1), date(2026, 5, 8),
                         context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.ADULT, age=45)]))
    assert rule_applies(rule, at_the_floor) is True
    assert rule_applies(rule, well_past_it) is True
    assert rule_applies(rule, below_it) is False


def test_multiple_conditions_on_one_rule_are_and_ed():
    rule = _rule(RuleKind.SPO_OFFER, [
        StayLengthCondition(min_nights=_hi(7), max_nights=_hi(365)),
        BookingDateCondition(from_date=_hi(date(2025, 7, 24)), to_date=_hi(date(2026, 4, 30))),
    ])
    both_satisfied = _booking(
        date(2026, 5, 1), date(2026, 5, 10),
        context=BookingApplicabilityContext(booking_date=date(2026, 1, 1)),
    )
    only_stay_length_satisfied = _booking(
        date(2026, 5, 1), date(2026, 5, 10),
        context=BookingApplicabilityContext(booking_date=date(2026, 6, 1)),  # outside booking window
    )
    assert rule_applies(rule, both_satisfied) is True
    assert rule_applies(rule, only_stay_length_satisfied) is False


# --- Composition --------------------------------------------------------------

def test_order_rules_uses_default_composition_order():
    child = _rule(RuleKind.CHILD_POLICY)
    supplement = _rule(RuleKind.SUPPLEMENT)
    spo = _rule(RuleKind.SPO_OFFER)
    ordered = order_rules([spo, supplement, child])
    assert [r.kind for r in ordered] == [RuleKind.CHILD_POLICY, RuleKind.SUPPLEMENT, RuleKind.SPO_OFFER]


def test_order_rules_accepts_a_custom_order():
    child = _rule(RuleKind.CHILD_POLICY)
    spo = _rule(RuleKind.SPO_OFFER)
    custom = [RuleKind.SPO_OFFER, RuleKind.CHILD_POLICY]
    ordered = order_rules([child, spo], order=custom)
    assert [r.kind for r in ordered] == [RuleKind.SPO_OFFER, RuleKind.CHILD_POLICY]


def test_rule_kind_itself_carries_no_ordering_semantics():
    """Structural proof of the design constraint: composition ordering
    lives in composition.py's explicit table, not as an assumption about
    RuleKind's own declaration order or meaning."""
    import inspect
    from contract_platform.contract_model import vocabulary
    source = inspect.getsource(vocabulary.RuleKind)
    assert "order" not in source.lower()
    assert "precedence" not in source.lower()
    assert "composition" not in source.lower()


def test_applicability_is_registry_dispatch_not_an_isinstance_chain():
    """Mirrors M0's identical proof for expression_engine.evaluator: adding
    a new ApplicabilityCondition type must not require editing
    rule_applies()'s or condition_matches()'s body -- only a new
    @register_condition function. Proven by registering a throwaway
    condition type and confirming dispatch picks it up purely through the
    registry, with no changes to applicability.py itself."""
    from contract_platform.pricing_engine.applicability import (
        CONDITION_MATCHERS, register_condition, condition_matches, rule_applies,
    )

    class _AlwaysOnWeekday:
        pass

    assert _AlwaysOnWeekday not in CONDITION_MATCHERS

    @register_condition(_AlwaysOnWeekday)
    def _match_always_on_weekday(condition, booking):
        return True

    try:
        rule = _rule(RuleKind.SPO_OFFER, [_AlwaysOnWeekday()])
        booking = _booking(date(2026, 5, 1), date(2026, 5, 8))
        assert condition_matches(_AlwaysOnWeekday(), booking) is True
        assert rule_applies(rule, booking) is True
    finally:
        del CONDITION_MATCHERS[_AlwaysOnWeekday]  # don't leak test state into other tests


def test_unknown_condition_type_fails_safe_not_silently_true():
    """The registry-dispatch counterpart to evaluator.py's
    'unknown node type raises' test -- but with the opposite failure
    philosophy by design: applicability must fail SAFE (False), never
    silently let an unrecognized condition pass a rule as applicable."""
    from contract_platform.pricing_engine.applicability import condition_matches, CONDITION_MATCHERS

    class _NeverRegistered:
        pass

    assert _NeverRegistered not in CONDITION_MATCHERS
    booking = _booking(date(2026, 5, 1), date(2026, 5, 8))
    assert condition_matches(_NeverRegistered(), booking) is False


# --- Validation: new invariant ------------------------------------------------

def test_invalid_applicability_range_is_rejected():
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(50.0))
    bad_rule = _rule(RuleKind.CHILD_POLICY, [AgeCondition(role=GuestType.CHILD, min_age=_hi(12), max_age=_hi(6))])
    bad_rule.season_id = season.id
    bad_rule.room_type_id = room.id

    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
                           pricing_rules=[bad_rule])
    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "INVALID_APPLICABILITY_RANGE" in codes
    assert has_blocking_errors(issues)


# --- Backward compatibility ----------------------------------------------------

def test_booking_request_with_no_context_behaves_exactly_as_before():
    """No context, no children -- must reproduce M1/M2/M3's exact pre-change
    behavior. Uses the real Anex scope from M2.

    Post-Slice-4 correction: the real Triple Reduction SUPPLEMENT rule now
    applies to the 3rd adult of a 3-adult party -- this test's actual
    concern (no CHILD_POLICY line gets added when context is None) is
    unaffected."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=3, children=0, infants=0,
    )  # context defaults to None, exactly like every pre-existing call site
    invoice = price_booking(scope, booking)
    assert not any("Child" in l.description for l in invoice.lines)  # no child lines added
    assert {l.unit_rate for l in invoice.lines} == {62.00, 60.00}
    assert invoice.total == (62.00 * 7 * 2) + (60.00 * 7 * 1)


# --- Real end-to-end: a family booking priced through price_booking() itself --

def test_real_anex_family_booking_prices_child_line_through_pricing_engine():
    """First real proof that a PricingRule flows all the way through
    price_booking() itself -- M2 could only evaluate the rule's Expression
    by hand in a test, specifically because applicability/composition
    didn't exist yet. This is that gap closed, against the same real PDF,
    using Promo Room's actual printed occupancy combo (2 ADL+2CHD)."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]

    booking = BookingRequest(
        room_type_id=promo.id,
        check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),  # 7 nights, East European 21.05-28.06 (62.00)
        adults=2, children=2, infants=0,  # the real "2 ADL+2CHD" combo printed in the source
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.CHILD, age=8),   # within Anex's 06-12.99 band -> priced
            GuestAge(role=GuestType.CHILD, age=4),   # outside the band -> no matching rule, no line
        ]),
    )

    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 2  # base adult line + exactly one child line (the 8-year-old)
    base_line, child_line = invoice.lines
    assert base_line.unit_rate == 62.00
    assert base_line.line_total == 62.00 * 7 * 2
    assert child_line.unit_rate == 93.00  # 62.00 + 50% of 62.00, the real M2 number
    assert child_line.line_total == 93.00 * 7
    assert invoice.total == (62.00 * 7 * 2) + (93.00 * 7)
