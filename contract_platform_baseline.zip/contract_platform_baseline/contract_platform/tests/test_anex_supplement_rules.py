"""
M4 (next slice after Slice 4) — Anex's Room Rates table has three more
real, parseable per-night amounts beyond PPPN, never built:
"Single Supplement" (60%), "Triple Reduction Per Person" (2.00 USD),
"04th Room Reduction Per Person" (3.00 USD) -- printed on every one of
the real 9 date-range rows across both markets.

Triple/4th reduction are structurally identical to EXIM's real AMR
columns (M4 Slice 2): a flat per-night amount off the base per-person
rate for a specific numbered adult slot, valid regardless of party size
as long as the party has that many adults. Built the same way: a
SUPPLEMENT PricingRule with PricingRule.applies_to_pax_number set,
consumed by pricing_engine's existing _adult_lines positional logic --
zero pricing_engine or Contract Model changes, exactly the reuse the
roadmap calls for.

Single Supplement is deliberately NOT modeled as a PricingRule this
slice -- see the adapter's own comment for the real reason (a genuine
semantic mismatch with what applies_to_pax_number means for the other
two: "this numbered slot always gets this treatment regardless of party
size" is true for triple/4th reduction, but false for a single-occupancy
supplement, which only makes sense when the *entire* party is 1 adult,
not "the booking's 1st adult regardless of total party size"). Flagged
in the adapter, not silently worked around.
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def test_promo_room_produces_triple_and_fourth_adult_supplement_rules_for_every_season():
    """9 real date-range rows (4 East + 5 Russia & CIS), each with a real
    Triple Reduction and 04th Reduction value -- must produce 18
    SUPPLEMENT rules total, applies_to_pax_number in {3, 4} only (never 1
    -- Single Supplement is deliberately not modeled as a positional
    rule, see module docstring)."""
    scope = build_contract_scope(FIXTURE_PATH)
    supplement_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.SUPPLEMENT]
    assert len(supplement_rules) == 18
    assert {r.applies_to_pax_number for r in supplement_rules} == {3, 4}


def test_supplement_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH)
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_three_adult_booking_prices_the_third_adult_at_the_real_reduced_rate():
    """The real end-to-end proof: a 3-adult booking (the '03ADL' combo
    actually printed in the source) in the 21.05-28.06 East season
    (62.00 PPPN) must split into 2 standard-rate adults + 1 adult at the
    real Triple Reduction (62.00 - 2.00 = 60.00), not a flat 62.00 x 3."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=3, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    standard_line, reduced_line = adult_lines
    assert standard_line.unit_rate == 62.00 and standard_line.quantity == 2
    assert reduced_line.unit_rate == 60.00 and reduced_line.quantity == 1
    assert invoice.total == (62.00 * 7 * 2) + (60.00 * 7 * 1)


def test_two_adult_two_child_booking_is_completely_unaffected():
    """The '2 ADL+2CHD' combo (no 3rd/4th adult slot exists in a 2-adult
    party) must be byte-identical to before this slice -- no positional
    rule matches a party with only 2 adults."""
    scope = build_contract_scope(FIXTURE_PATH)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=2, children=2, infants=0,
    )
    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    assert len(adult_lines) == 1
    assert adult_lines[0].unit_rate == 62.00 and adult_lines[0].quantity == 2
