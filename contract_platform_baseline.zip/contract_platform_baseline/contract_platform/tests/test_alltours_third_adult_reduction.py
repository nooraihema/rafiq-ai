"""
M4 (next slice) — Alltours' page 1 "5. Supplements" section has exactly
one populated row in an otherwise-blank table: "for 3rd. adult reductlon
for all rooms | 6.00 6.00 6.00" (Periods I/II/III). Unlike the per-room
rate table (blocked on real OCR corruption -- 6 of 9 remaining room codes
don't match at all, and a 7th silently misreads 85.00 as 5.00, per the
prior slice's README note), this line reads cleanly with zero corruption
-- confirmed by inspection before writing any parsing code.

Structurally identical to EXIM's AMR and Anex's Triple Reduction (both
already built): a flat per-night amount off the base rate for the 3rd
adult slot. In fact PricingRule.applies_to_pax_number's own docstring
(M4 Slice 2) already cites this exact Alltours line as founding evidence
for the field -- this slice is that citation's contract getting built.

Real difference from EXIM/Anex: the source says "for all rooms", not
scoped to one room code -- built with room_type_id=None (PricingRule's
own documented "hotel-wide" meaning, present since M0), not DZP's id,
to faithfully carry the real data's own scope. No Contract Model or
pricing_engine change: applies_to_pax_number and room_type_id=None both
already exist and are already consumed correctly by _adult_lines.

Not end-to-end booking-provable yet: DZP's own valid_occupancies (from
M3) has exactly one real, low-confidence combo (2 adults) -- the
occupancy stack didn't OCR reliably enough to trust a 3-adult combo, so
a 3-adult DZP booking is correctly rejected at booking-time validation
regardless of this slice. Proven instead by direct Expression evaluation
(the same standard M4 Slice 2 used before booking-level tests existed
for EXIM), plus a real validate_booking() check that a 3-adult DZP
booking is rejected for the right, pre-existing reason (occupancy, not
this new rule).
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import BookingRequest, validate_booking
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_dzp_scope_produces_four_real_third_adult_reduction_rules():
    """One SUPPLEMENT rule per Season (2x Period I + Period II + Period
    III = 4), all applies_to_pax_number == 3, all room_type_id is None
    (hotel-wide, per the real 'for all rooms' data).

    Filtered to applies_to_pax_number == 3 specifically: scope.
    pricing_rules also holds the real Longstay SUPPLEMENT rules (built in
    a later slice), which are non-positional and aren't this test's
    concern."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    supplement_rules = [
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT and r.applies_to_pax_number == 3
    ]
    assert len(supplement_rules) == 4
    assert all(r.room_type_id is None for r in supplement_rules)


def test_third_adult_reduction_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_each_season_rule_evaluates_to_that_seasons_real_reduced_rate():
    """The real value this slice exists to prove: each season's rule,
    evaluated against that season's own Rate, gives rate - 6.00 -- not
    a flat number copy-pasted across periods.

    Filtered to applies_to_pax_number == 3, same reason as the test
    above."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    supplement_rules = [
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT and r.applies_to_pax_number == 3
    ]
    for rule in supplement_rules:
        rate = next(r for r in scope.rates if r.season_id == rule.season_id)
        ctx = EvaluationContext(rate_values={rate.id: rate.amount.value})
        result = evaluate(rule.calculation.value, ctx)
        assert result == rate.amount.value - 6.00


def test_a_three_adult_dzp_booking_is_still_rejected_for_the_real_pre_existing_reason():
    """DZP's own real occupancy data (M3) never confirmed a 3-adult combo
    -- a 3-adult booking must still fail booking-time validation with
    OCCUPANCY_NOT_PERMITTED, proving this slice doesn't silently make an
    unconfirmed occupancy bookable just because a pricing rule for it now
    exists."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
                              adults=3, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert any(i.code == "OCCUPANCY_NOT_PERMITTED" for i in issues), issues


def test_a_two_adult_dzp_booking_is_completely_unaffected():
    """The one real, confirmed occupancy combo (2 adults) has no 3rd-adult
    slot -- must price byte-identically to before this slice."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
                              adults=2, children=0, infants=0)
    from contract_platform.pricing_engine.calculator import price_booking
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 66.00
