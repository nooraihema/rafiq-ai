"""
Proves the M0-hardened foundation actually works, using the same real
numbers pulled from the EXIM and Anex contracts as Phase 1, plus new
coverage for everything M0 added: generic Extracted[T] applied beyond
Rate.amount, the merged PricingRule, typed Restriction, Min/Max/Round,
registry-dispatch extensibility, and the three new invariants.
"""

from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, RoomType, Occupancy, Season, Rate, ContractScope,
    Extracted, PricingRule, BlackoutPeriod, CombinabilityRule, ReleaseRule,
    MinMaxStay, AgeBand, iter_low_confidence,
)
from contract_platform.contract_model.vocabulary import (
    MealPlan, RateBasis, ConfidenceLevel, RuleKind, RoundMode, CalculationUnit,
)
from contract_platform.contract_model.expressions import (
    Constant, RateRef, Add, PercentOf, Min, Max, Round, Expression,
)
from contract_platform.expression_engine.evaluator import (
    evaluate, EvaluationContext, NODE_EVALUATORS, register_node, EvaluationError,
)
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.validation.confidence import assess


def _hi(value):
    """Shorthand for wrapping a plain value as a HIGH-confidence Extracted,
    since most test fixtures don't care about provenance detail."""
    return Extracted(value=value, confidence=ConfidenceLevel.HIGH, source_note="test fixture")


# --- Carried over from Phase 1, updated to the M0 shapes -----------------

def test_exim_dr01_rate_survives_the_full_model():
    """DR01 from the real EXIM contract: PPPN = 46.00 USD, verified against
    the source document earlier this session."""
    hotel = Hotel(name="Amarina Jannah Resort & Aqua Park")
    to = TourOperator(name="EXIM/DER Touristik")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL_GARDEN_VIEW", display_name="Double Room Garden View")
    room.valid_occupancies = [Occupancy(adults=_hi(1), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer 2026", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))

    rate = Rate(
        room_type_id=room.id, season_id=season.id, meal_plan=MealPlan.ALL_INCLUSIVE,
        basis=RateBasis.PER_PERSON_PER_NIGHT,
        amount=Extracted(value=46.00, confidence=ConfidenceLevel.HIGH, source_note="read directly from PPPN column"),
    )

    scope = ContractScope(
        hotel=hotel, tour_operator=to, valid_from=season.start_date.value, valid_to=season.end_date.value,
        seasons=[season], room_types=[room], rates=[rate],
    )

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"
    assert rate.amount.value == 46.00


def test_anex_double_room_plus_50_percent_child_rule_evaluates_correctly():
    """Real Anex clause: 'Double Room Rate + 50 % P.P IN DBL' for
    02 Adult + 02 Children (06-12.99). Built directly as an Expression tree
    instead of stored as the original sentence — this is what the AST buys
    us over the regex approach in the prototype."""
    double_room_rate_id = "rate_double_room"
    pppn_double_rate_id = "rate_pppn_double"

    expr = Add(
        RateRef(double_room_rate_id),
        PercentOf(RateRef(pppn_double_rate_id), Constant(50, CalculationUnit.PERCENT)),
    )

    ctx = EvaluationContext(rate_values={
        double_room_rate_id: 62.00,   # Double Room Rate, East market, from the real contract
        pppn_double_rate_id: 62.00,   # Per Person in DBL, same period
    })

    result = evaluate(expr, ctx)
    assert result == 62.00 + (62.00 * 0.5) == 93.0


def test_missing_base_rate_is_caught_by_validation():
    """A RoomType with zero Rates must be flagged, not silently accepted —
    Invariant #1."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="TEST_ROOM", display_name="Test Room")
    scope = ContractScope(hotel=hotel, tour_operator=to, room_types=[room], rates=[])

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "MISSING_BASE_RATE" in codes
    assert has_blocking_errors(issues)


def test_low_confidence_value_is_flagged_not_silently_persisted():
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="TEST_ROOM", display_name="Test Room")
    room.valid_occupancies = [Occupancy(adults=_hi(1), children=_hi(0), infants=_hi(0))]
    season = Season(label="Test Season", start_date=_hi(date(2026, 1, 1)), end_date=_hi(date(2026, 12, 31)))
    rate = Rate(
        room_type_id=room.id, season_id=season.id,
        amount=Extracted(value=99.0, confidence=ConfidenceLevel.LOW, source_note="best-effort OCR guess"),
    )
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "LOW_CONFIDENCE_VALUE" in codes

    report = assess(scope)
    assert report.needs_review is True


# --- New in M0 -------------------------------------------------------------

def test_low_confidence_check_now_covers_fields_beyond_rate_amount():
    """M0: Extracted[T] applies to Season dates and Occupancy counts too, and
    the LOW-confidence invariant must catch a LOW value in either — this was
    an inconsistency in Phase 1 (only Rate.amount was ever checked)."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="TEST_ROOM", display_name="Test Room")
    # Occupancy adult count extracted with LOW confidence (e.g. smudged scan).
    room.valid_occupancies = [Occupancy(
        adults=Extracted(value=2, confidence=ConfidenceLevel.LOW, source_note="illegible digit"),
        children=_hi(0), infants=_hi(0),
    )]
    season = Season(label="Test Season", start_date=_hi(date(2026, 1, 1)), end_date=_hi(date(2026, 12, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(50.0))
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    issues = validate(scope)
    low_conf_entity_ids = [i.entity_id for i in issues if i.code == "LOW_CONFIDENCE_VALUE"]
    assert room.valid_occupancies[0].id in low_conf_entity_ids

    report = assess(scope)
    # 2 season dates + 1 occupancy count(adults) + 1 rate amount = 4 tracked values
    # (children/infants also counted -> 6 total); just assert the LOW one is seen.
    assert report.low >= 1
    assert report.needs_review is True


# --- Engineering Infrastructure Slice: iter_low_confidence() -------------
#
# Found by inspection: the exact "iter_extracted() filtered to
# confidence == LOW" pattern was independently written three times
# (validation.confidence.assess(), registry.store.commit_scope(),
# review_ui.corrections.list_review_items()) before this slice --
# consolidated into one shared generator so the commit gate and the
# review listing can never silently drift on what counts as "needs
# review". These tests prove the shared function directly, plus that
# both real consumers still behave identically after being rewired to
# use it (a pure refactor, not a behavior change).

def test_iter_low_confidence_yields_only_the_low_confidence_fields():
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="TEST_ROOM", display_name="Test Room")
    room.valid_occupancies = [Occupancy(
        adults=Extracted(value=2, confidence=ConfidenceLevel.LOW, source_note="illegible digit"),
        children=_hi(0), infants=_hi(0),
    )]
    season = Season(label="Test Season", start_date=_hi(date(2026, 1, 1)), end_date=_hi(date(2026, 12, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(50.0))
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    low = list(iter_low_confidence(scope))
    assert len(low) == 1
    entity_id, field_name, extracted = low[0]
    assert entity_id == room.valid_occupancies[0].id
    assert field_name == "adults"
    assert extracted.confidence == ConfidenceLevel.LOW


def test_iter_low_confidence_yields_nothing_for_a_fully_high_confidence_scope():
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="TEST_ROOM", display_name="Test Room")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Test Season", start_date=_hi(date(2026, 1, 1)), end_date=_hi(date(2026, 12, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(50.0))
    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate])

    assert list(iter_low_confidence(scope)) == []


def test_pricing_rule_merges_child_policy_supplement_and_offer_by_kind():
    """M0: Offer/Supplement/ChildPolicyRule collapsed into PricingRule,
    distinguished by RuleKind. All three still round-trip through the same
    entity shape and the same list on ContractScope."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(62.0))

    child_policy = PricingRule(
        kind=RuleKind.CHILD_POLICY, room_type_id=room.id, season_id=season.id,
        label="2 ADL + 2 CHD: Double Room Rate + 50% P.P IN DBL",
        calculation=_hi(Add(RateRef(rate.id), PercentOf(RateRef(rate.id), Constant(50, CalculationUnit.PERCENT)))),
    )
    supplement = PricingRule(
        kind=RuleKind.SUPPLEMENT, room_type_id=room.id, season_id=season.id,
        label="Single supplement",
        calculation=_hi(PercentOf(RateRef(rate.id), Constant(25, CalculationUnit.PERCENT))),
    )
    spo = PricingRule(
        kind=RuleKind.SPO_OFFER, room_type_id=None, season_id=season.id,
        label="Early booking SPO", issued_date=date(2026, 1, 15),
        valid_from=date(2026, 1, 15), valid_to=date(2026, 3, 1),
        calculation=_hi(Constant(10, CalculationUnit.PERCENT)),
    )

    scope = ContractScope(
        hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
        pricing_rules=[child_policy, supplement, spo],
    )

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"

    kinds_present = {r.kind for r in scope.pricing_rules}
    assert kinds_present == {RuleKind.CHILD_POLICY, RuleKind.SUPPLEMENT, RuleKind.SPO_OFFER}
    assert spo.room_type_id is None  # hotel-wide, per the Offer semantics it replaces

    ctx = EvaluationContext(rate_values={rate.id: 62.0})
    assert evaluate(child_policy.calculation.value, ctx) == 93.0


def test_age_band_is_a_value_type_not_an_entity():
    """M0: AgeBand has no id and no independent lifecycle — it's inlined on
    Occupancy directly. Two AgeBands with identical bounds must be equal
    (frozen dataclass value-equality), which is the point of demoting it."""
    band_a = AgeBand(min_age=6, max_age=12.99, label="child_band_1")
    band_b = AgeBand(min_age=6, max_age=12.99, label="child_band_1")
    assert band_a == band_b
    assert not hasattr(band_a, "id")

    occ = Occupancy(adults=_hi(2), children=_hi(2), infants=_hi(0), child_age_band=band_a)
    assert occ.child_age_band == band_b


def test_typed_restriction_min_max_stay_and_blackout_are_checked():
    """M0: Restriction is now typed subclasses, not a dict. EXIM's real
    '3/999 nights' min/max-stay clause is representable and validated."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(46.0))

    min_max = MinMaxStay(
        applies_to_rate_id=rate.id,
        min_nights=_hi(3), max_nights=_hi(999),
    )
    blackout = BlackoutPeriod(
        applies_to_rate_id=rate.id,
        start_date=_hi(date(2026, 12, 24)), end_date=_hi(date(2026, 12, 26)),
    )

    scope = ContractScope(
        hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
        restrictions=[min_max, blackout],
    )

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"


def test_invalid_min_max_stay_is_rejected():
    """Invariant #7: min_nights > max_nights must be caught."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(46.0))
    bad_restriction = MinMaxStay(applies_to_rate_id=rate.id, min_nights=_hi(10), max_nights=_hi(3))

    scope = ContractScope(
        hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
        restrictions=[bad_restriction],
    )

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "INVALID_MIN_MAX_STAY" in codes
    assert has_blocking_errors(issues)


def test_dangling_restriction_reference_is_rejected():
    """Invariant #6: a Restriction pointing at a Rate id that doesn't exist
    in this scope must be flagged."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(46.0))
    dangling = ReleaseRule(applies_to_rate_id="rate_that_does_not_exist", days_before_arrival=_hi(21))

    scope = ContractScope(
        hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
        restrictions=[dangling],
    )

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "DANGLING_RESTRICTION_REFERENCE" in codes
    assert has_blocking_errors(issues)


def test_circular_pricing_rule_supersession_is_rejected():
    """Invariant #5: a supersedes_rule_id cycle must be caught."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))
    rate = Rate(room_type_id=room.id, season_id=season.id, amount=_hi(46.0))

    rule_a = PricingRule(kind=RuleKind.SUPPLEMENT, season_id=season.id, label="A", calculation=_hi(Constant(1, CalculationUnit.USD)))
    rule_b = PricingRule(kind=RuleKind.SUPPLEMENT, season_id=season.id, label="B", calculation=_hi(Constant(1, CalculationUnit.USD)))
    rule_a.supersedes_rule_id = rule_b.id
    rule_b.supersedes_rule_id = rule_a.id  # cycle

    scope = ContractScope(
        hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[rate],
        pricing_rules=[rule_a, rule_b],
    )

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "CIRCULAR_SUPERSESSION" in codes
    assert has_blocking_errors(issues)


def test_contract_supersession_field_is_representable():
    """M0: ContractScope.supersedes_contract_id — direct response to EXIM's
    printed text 'This contract supersedes any previous versions of this
    contract reference.'"""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    old_scope_id = "previous-contract-id"
    scope = ContractScope(hotel=hotel, tour_operator=to, supersedes_contract_id=old_scope_id)
    assert scope.supersedes_contract_id == old_scope_id

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "CIRCULAR_SUPERSESSION" not in codes  # pointing at a real other contract is fine


def test_min_max_and_round_nodes_evaluate_correctly():
    """M0: Min/Max/Round added to the Expression AST — direct response to
    the recurring 'IN CASE SINGLE + 2 CHILD RATE IS MORE THAN DOUBLE, DOUBLE
    RATE WILL BE APPLIED' clause pattern, and the silent-rounding gap."""
    ctx = EvaluationContext(rate_values={})

    assert evaluate(Min(Constant(120, CalculationUnit.USD), Constant(95, CalculationUnit.USD)), ctx) == 95
    assert evaluate(Max(Constant(120, CalculationUnit.USD), Constant(95, CalculationUnit.USD)), ctx) == 120

    assert evaluate(Round(Constant(46.4, CalculationUnit.USD), RoundMode.NEAREST), ctx) == 46
    assert evaluate(Round(Constant(46.5, CalculationUnit.USD), RoundMode.NEAREST), ctx) == 46  # banker's rounding, Python default
    assert evaluate(Round(Constant(46.1, CalculationUnit.USD), RoundMode.UP), ctx) == 47
    assert evaluate(Round(Constant(46.9, CalculationUnit.USD), RoundMode.DOWN), ctx) == 46


def test_single_plus_two_child_capped_at_double_rate_real_clause_shape():
    """The actual clause this Min node exists for: single+2child rate must
    never exceed the double rate."""
    single_plus_2child_id = "rate_single_2child"
    double_id = "rate_double"
    expr = Min(RateRef(single_plus_2child_id), RateRef(double_id))

    # Case 1: single+2child would be more expensive than double -> capped.
    ctx = EvaluationContext(rate_values={single_plus_2child_id: 105.0, double_id: 93.0})
    assert evaluate(expr, ctx) == 93.0

    # Case 2: single+2child is cheaper -> applied as-is.
    ctx2 = EvaluationContext(rate_values={single_plus_2child_id: 80.0, double_id: 93.0})
    assert evaluate(expr, ctx2) == 80.0


def test_evaluator_is_registry_dispatch_not_an_isinstance_chain():
    """M0: adding a new node type must not require editing evaluate()'s
    body — only a new dataclass plus a @register_node function. Proven here
    by registering a throwaway node type and confirming evaluate() picks it
    up purely through the registry, with no changes to evaluator.py itself."""

    class _Double(Expression):
        def __init__(self, inner):
            self.inner = inner

    assert _Double not in NODE_EVALUATORS

    @register_node(_Double)
    def _eval_double(expr, ctx):
        return evaluate(expr.inner, ctx) * 2

    try:
        ctx = EvaluationContext(rate_values={})
        result = evaluate(_Double(Constant(21, CalculationUnit.USD)), ctx)
        assert result == 42
    finally:
        del NODE_EVALUATORS[_Double]  # don't leak test state into other tests


def test_pppn_and_sopn_rates_coexist_without_triggering_duplicate_rate():
    """Regression test (found during M1 against the real EXIM PDF): a room
    legitimately has both a PPPN and a SOPN Rate for the same
    RoomType/Season/Market -- that's not a duplicate, Rate.basis exists
    precisely to distinguish them. A genuine duplicate (same basis twice)
    must still be caught."""
    hotel = Hotel(name="Test Hotel")
    to = TourOperator(name="Test TO")
    room = RoomType(hotel_id=hotel.id, canonical_code="DBL", display_name="Double")
    room.valid_occupancies = [Occupancy(adults=_hi(2), children=_hi(0), infants=_hi(0))]
    season = Season(label="Summer", start_date=_hi(date(2026, 5, 1)), end_date=_hi(date(2026, 10, 31)))

    from contract_platform.contract_model.vocabulary import RateBasis
    pppn = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.PER_PERSON_PER_NIGHT, amount=_hi(46.0))
    sopn = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.SINGLE_OCCUPANCY_PER_NIGHT, amount=_hi(73.6))

    scope = ContractScope(hotel=hotel, tour_operator=to, seasons=[season], room_types=[room], rates=[pppn, sopn])
    issues = validate(scope)
    assert "DUPLICATE_RATE" not in [i.code for i in issues], f"expected no DUPLICATE_RATE, got: {issues}"

    duplicate_pppn = Rate(room_type_id=room.id, season_id=season.id, basis=RateBasis.PER_PERSON_PER_NIGHT, amount=_hi(50.0))
    scope.rates.append(duplicate_pppn)
    issues = validate(scope)
    assert "DUPLICATE_RATE" in [i.code for i in issues]


def test_unknown_node_type_raises_evaluation_error():
    class _Unregistered(Expression):
        pass

    ctx = EvaluationContext(rate_values={})
    try:
        evaluate(_Unregistered(), ctx)
        assert False, "expected EvaluationError"
    except EvaluationError:
        pass
