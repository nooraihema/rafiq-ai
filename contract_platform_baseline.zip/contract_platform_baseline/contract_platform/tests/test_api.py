"""
Major Milestone — HTTP API: the second transport over orchestration.py's
shared business logic (the first is cli.py). Tests here prove the same
real behavior the CLI test suite already proved, but reached over HTTP
via Flask's test client (real request/response objects, real JSON
(de)serialization, real routing -- not a mock of Flask).

Deliberately does not re-prove business logic already proven exhaustively
by the CLI/orchestration test suites (e.g. every real adapter's pricing
rule shape) -- that would be redundant coverage of the same already-
tested orchestration functions. What's proven here is specific to this
transport: request parsing, status codes, JSON response shape, and that
the full ingest -> review -> correct -> describe -> price loop survives
being driven entirely over HTTP.
"""

import os
import tempfile
from datetime import date

from contract_platform.api.app import create_app, API_KEY_ENV_VAR

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")
TEST_API_KEY = "test-key-do-not-use-in-prod"


def _client():
    client = create_app(api_key=TEST_API_KEY).test_client()
    # Default header on every request this client makes, so every
    # existing call site below needs no per-call change.
    client.environ_base["HTTP_X_API_KEY"] = TEST_API_KEY
    return client


def test_missing_api_key_is_rejected():
    client = create_app(api_key=TEST_API_KEY).test_client()
    resp = client.get("/scopes")
    assert resp.status_code == 401


def test_wrong_api_key_is_rejected():
    client = create_app(api_key=TEST_API_KEY).test_client()
    resp = client.get("/scopes", headers={"X-API-Key": "wrong-key"})
    assert resp.status_code == 401


def test_no_configured_key_refuses_to_serve():
    client = create_app(api_key=None).test_client()
    import os as _os
    _os.environ.pop(API_KEY_ENV_VAR, None)
    resp = client.get("/scopes", headers={"X-API-Key": "anything"})
    assert resp.status_code == 503


def test_ui_root_loads_without_an_api_key():
    # Even with no key configured at all -- the page shell has no data
    # in it; only the /scopes* calls its JS makes need a real key.
    client = create_app(api_key=None).test_client()
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"Contract Platform" in resp.data


def test_post_scopes_commits_a_high_confidence_scope():
    with tempfile.TemporaryDirectory() as storage_dir:
        resp = _client().post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["committed"] is True
        assert data["room_type_count"] == 1
        assert data["review_items"] == []


def test_post_scopes_with_unknown_adapter_returns_400():
    resp = _client().post("/scopes", json={"adapter": "not_real", "pdf_path": EXIM_FIXTURE})
    assert resp.status_code == 400
    assert "not_real" in resp.get_json()["error"]


def test_post_scopes_missing_required_fields_returns_400():
    resp = _client().post("/scopes", json={"adapter": "exim"})  # no pdf_path
    assert resp.status_code == 400


def test_pdf_path_outside_configured_upload_dir_is_rejected():
    import tempfile
    with tempfile.TemporaryDirectory() as upload_dir:
        client = create_app(api_key=TEST_API_KEY, upload_dir=upload_dir).test_client()
        client.environ_base["HTTP_X_API_KEY"] = TEST_API_KEY
        # EXIM_FIXTURE is a real file, but it lives outside upload_dir --
        # this is the traversal case (e.g. pdf_path="/etc/passwd") a
        # caller with a valid API key should still not be able to reach.
        resp = client.post("/scopes", json={"adapter": "exim", "pdf_path": EXIM_FIXTURE})
        assert resp.status_code == 400
        assert "upload directory" in resp.get_json()["error"]


def test_get_scopes_lists_committed_ids():
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()
        ingest_resp = client.post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        scope_id = ingest_resp.get_json()["scope_id"]

        list_resp = client.get("/scopes", query_string={"storage_dir": storage_dir})
        assert list_resp.status_code == 200
        assert scope_id in list_resp.get_json()["scope_ids"]


def test_get_scope_describe_returns_real_room_types():
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()
        ingest_resp = client.post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        scope_id = ingest_resp.get_json()["scope_id"]

        resp = client.get(f"/scopes/{scope_id}", query_string={"storage_dir": storage_dir})
        assert resp.status_code == 200
        room_types = resp.get_json()["room_types"]
        assert len(room_types) == 1
        assert room_types[0]["canonical_code"] == "DR01"
        assert room_types[0]["room_type_id"]  # a real, non-empty id


def test_get_scope_describe_for_an_unknown_id_returns_404():
    resp = _client().get("/scopes/not-a-real-id")
    assert resp.status_code == 404


def test_post_scope_price_returns_the_real_known_invoice():
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()
        ingest_resp = client.post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        scope_id = ingest_resp.get_json()["scope_id"]
        room_type_id = client.get(f"/scopes/{scope_id}", query_string={"storage_dir": storage_dir}) \
            .get_json()["room_types"][0]["room_type_id"]

        resp = client.post(f"/scopes/{scope_id}/price", json={
            "storage_dir": storage_dir, "room_type_id": room_type_id,
            "check_in": "2026-07-01", "check_out": "2026-07-08", "adults": 2,
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["valid"] is True
        assert data["invoice"]["total"] == 46.00 * 7 * 2


def test_post_scope_price_with_child_ages_reaches_the_real_child_pct_discount():
    """The real proof this transport carries the exact same booking
    context the CLI does: a real child age reaches EXIM's real CHILD_PCT
    discount over HTTP, not just from argv."""
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()
        ingest_resp = client.post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        scope_id = ingest_resp.get_json()["scope_id"]
        room_type_id = client.get(f"/scopes/{scope_id}", query_string={"storage_dir": storage_dir}) \
            .get_json()["room_types"][0]["room_type_id"]

        resp = client.post(f"/scopes/{scope_id}/price", json={
            "storage_dir": storage_dir, "room_type_id": room_type_id,
            "check_in": "2026-07-01", "check_out": "2026-07-08", "adults": 2, "children": 1,
            "child_ages": [4],
        })
        data = resp.get_json()
        assert data["valid"] is True
        child_line = next(l for l in data["invoice"]["lines"] if "Child" in l["description"])
        assert child_line["unit_rate"] == 0.0


def test_post_scope_price_reports_an_invalid_booking_without_a_500():
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()
        ingest_resp = client.post("/scopes", json={
            "adapter": "exim", "pdf_path": EXIM_FIXTURE, "room_codes": ["DR01"], "storage_dir": storage_dir,
        })
        scope_id = ingest_resp.get_json()["scope_id"]
        room_type_id = client.get(f"/scopes/{scope_id}", query_string={"storage_dir": storage_dir}) \
            .get_json()["room_types"][0]["room_type_id"]

        resp = client.post(f"/scopes/{scope_id}/price", json={
            "storage_dir": storage_dir, "room_type_id": room_type_id,
            "check_in": "2026-07-01", "check_out": "2026-07-08", "adults": 4,
        })
        assert resp.status_code == 200  # a well-formed request with an invalid *outcome* is not a client error
        data = resp.get_json()
        assert data["valid"] is False
        assert any(i["code"] == "OCCUPANCY_NOT_PERMITTED" for i in data["validation_issues"])


def test_post_scope_price_for_an_unknown_scope_returns_404():
    resp = _client().post("/scopes/not-a-real-id/price", json={
        "room_type_id": "x", "check_in": "2026-07-01", "check_out": "2026-07-08", "adults": 2,
    })
    assert resp.status_code == 404


def test_the_full_ingest_review_correct_describe_price_loop_over_http():
    """The real end-to-end proof: Alltours' real DZP scope, rejected on
    first ingest, corrected field-by-field, then described and priced
    with a real Senior Discount context -- entirely through HTTP request/
    response cycles, driven by one Flask test client standing in for a
    real deployed server."""
    with tempfile.TemporaryDirectory() as storage_dir:
        client = _client()

        first = client.post("/scopes", json={
            "adapter": "alltours", "pdf_path": ALLTOURS_FIXTURE, "room_codes": ["DZP"], "storage_dir": storage_dir,
        })
        assert first.status_code == 200
        first_data = first.get_json()
        assert first_data["committed"] is False
        scope_id = first_data["scope_id"]

        review = client.get(f"/scopes/{scope_id}/review", query_string={"storage_dir": storage_dir})
        assert review.status_code == 200
        items = review.get_json()["review_items"]
        assert len(items) == 2

        last_correct = None
        for item in items:
            last_correct = client.post(f"/scopes/{scope_id}/correct", json={
                "storage_dir": storage_dir, "entity_id": item["entity_id"],
                "field_name": item["field_name"], "value": item["current_value"], "confidence": "high",
            })
            assert last_correct.status_code == 200
        assert last_correct.get_json()["committed"] is True

        describe = client.get(f"/scopes/{scope_id}", query_string={"storage_dir": storage_dir})
        room_type_id = describe.get_json()["room_types"][0]["room_type_id"]

        priced = client.post(f"/scopes/{scope_id}/price", json={
            "storage_dir": storage_dir, "room_type_id": room_type_id,
            "check_in": "2026-05-21", "check_out": "2026-05-28", "adults": 2,
            "adult_ages": [65, 45],
        })
        assert priced.status_code == 200
        priced_data = priced.get_json()
        assert priced_data["valid"] is True
        assert {round(l["unit_rate"], 2) for l in priced_data["invoice"]["lines"]} == {66.00, round(66.00 * 0.9, 2)}
