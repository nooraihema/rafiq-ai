"""
M2 — Walking Skeleton: Anex.

Same pipeline as M1, proven against a structurally different Tour
Operator: document_parser (unchanged, reused as-is -- proof it really is
TO-agnostic) -> semantic_adapters/anex -> contract_model -> validation ->
expression_engine. Per the roadmap's M2 success criteria, pricing_engine
and expression_engine require ZERO changes to accommodate Anex; this test
proves that by using them completely unmodified.

The number this test anchors on (93.00 USD) was hand-verified against the
source PDF this session: East market, 21.05.2026-28.06.2026, Per Person in
DBL = 62.00 USD; Children Policy & Family Plan, "02 Adult + 02 Children
(06-12.99), Double Room, Double Room Rate + 50 % P.P IN DBL" ->
62.00 + 50% of 62.00 = 93.00.
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext
from contract_platform.contract_model.expressions import RateRef
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def _build_scope():
    return build_contract_scope(FIXTURE_PATH)


def _find_rate(scope, market_name, start, end):
    market = next(m for m in scope.markets if m.name == market_name)
    season = next(
        s for s in scope.seasons
        if s.market_id == market.id and s.start_date.value == start and s.end_date.value == end
    )
    return next(r for r in scope.rates if r.season_id == season.id), season


def test_anex_adapter_produces_a_valid_contract_scope():
    scope = _build_scope()

    assert scope.hotel.name == "AMARINA JANNAH RESORT & AQUA PARK"
    assert scope.tour_operator.name == "ANEX TOURISM WORLDWIDE DMCC"
    assert scope.valid_from == date(2026, 5, 1)
    assert scope.valid_to == date(2026, 10, 31)

    market_names = {m.name for m in scope.markets}
    assert market_names == {"East European", "Russia & CIS"}

    assert len(scope.room_types) == 1
    promo = scope.room_types[0]
    assert promo.canonical_code == "PROMO"
    combos = {(o.adults.value, o.children.value) for o in promo.valid_occupancies}
    assert combos == {(2, 2), (3, 0)}  # "2 ADL+2CHD OR 03ADL"

    # 4 East European date ranges + 5 Russia & CIS date ranges = 9 seasons/rates
    assert len(scope.seasons) == 9
    assert len(scope.rates) == 9
    # 9 CHILD_POLICY (one per season) + 18 SUPPLEMENT (Triple + 4th Adult
    # Reduction, one pair per season -- built post-Slice-4, real data
    # parsed since M2 alongside PPPN but not modeled until now)
    child_policy_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.CHILD_POLICY]
    supplement_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.SUPPLEMENT]
    assert len(child_policy_rules) == 9
    assert len(supplement_rules) == 18

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"


def test_anex_promo_room_pppn_matches_the_real_pdf_for_the_target_season():
    """East market, 21.05.2026-28.06.2026: 62.00 USD -- the base figure the
    93.00 result depends on."""
    scope = _build_scope()
    rate, season = _find_rate(scope, "East European", date(2026, 5, 21), date(2026, 6, 28))
    assert rate.amount.value == 62.00
    assert rate.amount.confidence.value == "high"
    assert rate.amount.provenance.page_number in (2, 3)


def test_double_room_plus_50_percent_child_rule_evaluates_to_93_from_real_data():
    """The specific number this whole milestone exists to prove -- and
    proof that expression_engine needed zero changes: this Expression tree
    is evaluated by the exact same evaluate() used for EXIM in M1."""
    scope = _build_scope()
    rate, season = _find_rate(scope, "East European", date(2026, 5, 21), date(2026, 6, 28))

    rule = next(
        r for r in scope.pricing_rules
        if r.season_id == season.id and r.kind.value == "child_policy"
    )
    assert rule.calculation.confidence.value == "high"

    ctx = EvaluationContext(rate_values={rate.id: rate.amount.value})
    result = evaluate(rule.calculation.value, ctx)
    assert result == 93.00


def test_all_nine_seasons_produce_a_correctly_evaluating_child_policy_rule():
    """Not just the one hand-verified season -- every East/Russia&CIS date
    range's child-policy rule must independently evaluate to
    rate * 1.5, proving the pattern holds across the real data, not just
    one cherry-picked row. Filtered to CHILD_POLICY specifically: scope.
    pricing_rules also contains the real Triple/4th Adult Reduction
    SUPPLEMENT rules (built post-Slice-4), which evaluate to a different
    formula entirely and aren't this test's concern."""
    scope = _build_scope()
    for rule in scope.pricing_rules:
        if rule.kind != RuleKind.CHILD_POLICY:
            continue
        rate = next(r for r in scope.rates if r.season_id == rule.season_id)
        ctx = EvaluationContext(rate_values={rate.id: rate.amount.value})
        result = evaluate(rule.calculation.value, ctx)
        assert result == round(rate.amount.value * 1.5, 10)


def test_pricing_engine_prices_a_plain_three_adult_anex_booking_with_zero_code_changes():
    """Runs the same pricing_engine.price_booking used for EXIM in M1,
    completely unmodified, against Anex's ContractScope -- the concrete
    proof of the roadmap's M2 success criterion ('zero changes required to
    pricing_engine ... to accommodate Anex'). Uses 3 adults / 0 children --
    the '03ADL' combo explicitly printed in the source, since a plain
    2-adult/0-child combo was never printed (Maximum Occupancy only lists
    '2 ADL+2CHD OR 03ADL') and the adapter deliberately doesn't invent it.

    Post-Slice-4 correction: the real Triple Reduction SUPPLEMENT rule
    (built after this test was written) now applies to the 3rd adult --
    pricing_engine itself is still completely unmodified for this
    scenario; the expected values below just reflect the real discount
    the source document actually specifies."""
    scope = _build_scope()
    promo = scope.room_types[0]

    booking = BookingRequest(
        room_type_id=promo.id,
        check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),  # 7 nights, inside 21.05-28.06
        adults=3, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    assert {l.unit_rate for l in adult_lines} == {62.00, 60.00}
    assert invoice.total == (62.00 * 7 * 2) + (60.00 * 7 * 1)


def test_document_parser_was_not_modified_for_anex():
    """Structural proof that document_parser really is TO-agnostic: the
    Anex adapter imports the identical read_pdf_pages function EXIM uses,
    with no Anex-specific branch inside document_parser itself."""
    import inspect
    from contract_platform.document_parser import pdf_reader
    source = inspect.getsource(pdf_reader)
    assert "anex" not in source.lower()
    assert "exim" not in source.lower()
