"""
M6, Slice 1 — the CLI: the first way to reach this project's fully
proven pipeline (extraction -> commit gate -> review -> persistence ->
pricing) from outside a Python test file.

Major Milestone — HTTP API: run_ingest/run_review/run_correct/
run_describe/run_price/IngestResult/CorrectResult/RoomTypeSummary/
PriceResult were extracted from cli.py into orchestration.py so the new
HTTP API (api/app.py) could share them without importing this transport
module. Every test below is unchanged in behavior — only the import
source moved. main() (this file's actual subject) stays in cli.py.

Chosen after re-evaluating the whole project, not by continuing the
roadmap mechanically. Every other candidate for "the next qualitative
leap" was checked first and found genuinely blocked by missing evidence,
the same discipline this project has applied to every adapter gap:
- A fourth adapter needs a fourth real contract PDF. None exists in
  tests/fixtures/ (checked directly) or anywhere else in the repo.
  Building one from synthetic data would violate this project's real-
  data-only discipline outright.
- Schema migration needs a second real ContractScope.schema_version
  value. None has ever been produced by any adapter -- nothing to
  migrate between.
- CombinabilityRule needs a fourth adapter's real data (Touring, Rocket,
  Eden) to force its shape. Same blocker as the fourth adapter itself.
- Registry evolution (listing, deletion, etc.) has no evidenced need --
  nothing in this codebase or its usage so far calls for it.

The CLI is different: it isn't blocked by missing real-world data at
all. Every piece it needs (adapters, the commit gate, review_ui,
persistence, pricing) is already built and already proven -- the actual
remaining gap is that none of it is *reachable* except by importing
internal modules directly, exactly the way this test suite itself does.
That reachability gap, not a new correctness gap, is this slice's target.

Deliberately minimal for a first CLI slice: one command (`ingest`) that
runs a real PDF through extraction and the commit gate and reports the
result -- committed with basic scope stats, or rejected with the real
validation issues and review items. Pricing a specific booking, listing
committed scopes, and applying corrections from the command line are
all real, plausible future commands, but nothing evidences which one
matters most yet -- they stay unbuilt rather than guessed at, the same
restraint this project has applied to every other unevidenced shape.

No Contract Model, pricing_engine, or adapter change. cli.py is pure
orchestration over already-tested functions, the same "thin
orchestration only" discipline registry/store.py and review_ui/
corrections.py have both followed.

A real, adapter-signature inconsistency was found by inspection before
writing any CLI code, not assumed: exim/alltours' build_contract_scope
both accept an optional room_codes list; anex's does not (it always
builds the single real Promo Room product, M2's own documented scope).
run_ingest() handles this explicitly per adapter, rather than assuming
a uniform signature across adapters that inspection showed doesn't
exist.

M6, Slice 3 addition: `review` and `correct` commands, closing the CLI-
side gap named at the end of Slice 2 -- a rejected scope's draft form is
now persisted (registry.save_draft_scope, M6 Slice 3), so a human can
come back in a completely separate CLI invocation, see exactly what
needs fixing (`review`), and fix it one field at a time (`correct`),
without ever writing Python. This is the actual product loop this whole
project has been building toward, finally reachable end-to-end from a
terminal.

M6, Slice 4 addition: `describe` and `price` commands. Chosen over
hardening the registry's file-based writes for concurrent access (the
other real candidate identified during a full project assessment) on a
product-impact basis: concurrency safety closes a risk nothing has
exercised yet (this is still a single-operator CLI, no server, no
evidence of concurrent usage anywhere), while `price` closes the single
most visible product gap -- this is a pricing platform, and there was no
way to get a price out of it from the command line. `describe` exists
because `price` needs a room_type_id (a UUID) and nothing before this
slice let a CLI user discover one without already having Python access
to inspect a committed scope directly -- the exact blocker named in M6
Slice 3's own "Next" note. `price` is deliberately scoped to the core
booking fields only (room_type_id, dates, adult/child/infant counts) --
no BookingApplicabilityContext (guest ages, booking date) support yet,
since nothing has evidenced a CLI-level need for per-guest or
per-booking-date conditions specifically, as opposed to what --adults/
--children/--check-in/--check-out already cover.

M6, Slice 5 addition: closes the gap Slice 4 deliberately left open.
Real inspection found that a large share of already-built, already-
tested PricingRules were completely unreachable through `price` as it
stood -- EXIM's CHILD_PCT age-band discounts (M4 Slice 3) and Alltours'
Senior Discount (M4) both require BookingApplicabilityContext.guest_ages;
Anex's Release Rule (M4) only ever fires with a supplied booking_date.
None of the three had any way to reach the CLI at all. `price` gains
`--child-ages`/`--adult-ages`/`--booking-date`, wired straight through to
the same BookingApplicabilityContext/GuestAge objects pricing_engine has
used since M4 -- no new engine logic, purely closing a CLI reachability
gap for features that already existed. Valid-booking output now also
prints WARNING-level issues (e.g. Release Rule's "inside the release
period" notice) alongside the invoice, not just on the invalid path --
the same "never hide information" discipline `review`/`correct` already
follow, extended to a case (a *valid* booking with something still worth
knowing) `price` hadn't covered before.
"""

import io
import os
import tempfile
from contextlib import redirect_stdout
from datetime import date

from contract_platform.cli import main
from contract_platform.orchestration import (
    run_ingest, run_review, run_correct, run_describe, run_price,
    IngestResult, CorrectResult, RoomTypeSummary, PriceResult,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel, GuestType
from contract_platform.registry import store as registry_store
from contract_platform.registry.store import get_committed_scope, commit_scope, list_committed_scope_ids
from contract_platform.pricing_engine.calculator import GuestAge, BookingApplicabilityContext

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")
ANEX_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")


def test_run_ingest_commits_a_high_confidence_scope():
    """EXIM's real DR01 scope commits on the first attempt -- the simple
    path, reported with real, non-zero counts, not placeholder zeros."""
    result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"])
    assert isinstance(result, IngestResult)
    assert result.committed is True
    assert result.room_type_count == 1
    assert result.rate_count > 0
    assert result.pricing_rule_count > 0
    assert result.review_items == []


def test_run_ingest_reports_real_review_items_for_a_rejected_scope():
    """Alltours' real DZP scope (LOW-confidence occupancy since M3) must
    be reported as rejected, carrying the same real review items
    review_ui.list_review_items would surface directly."""
    result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"])
    assert result.committed is False
    assert len(result.review_items) == 2
    assert {i.field_name for i in result.review_items} == {"adults", "children"}


def test_run_ingest_rejects_an_unknown_adapter_name():
    try:
        run_ingest("not_a_real_adapter", EXIM_FIXTURE)
        assert False, "expected ValueError for an unknown adapter name"
    except ValueError as e:
        assert "not_a_real_adapter" in str(e)


def test_run_ingest_rejects_room_codes_for_anex():
    """A real, inspected signature difference: anex's build_contract_scope
    doesn't accept room_codes at all -- passing any must fail clearly,
    not silently ignore the argument or crash with an unrelated
    TypeError from deep inside the adapter."""
    try:
        run_ingest("anex", ANEX_FIXTURE, room_codes=["SOMETHING"])
        assert False, "expected ValueError for room_codes passed to anex"
    except ValueError as e:
        assert "anex" in str(e).lower()


def test_run_ingest_with_storage_dir_persists_the_committed_scope():
    """The CLI's commit must actually use the real persistence path
    (M5 Slice 5), not bypass it -- a scope ingested with storage_dir
    must be recoverable after the in-memory cache is cleared."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        assert result.committed is True

        registry_store._COMMITTED_SCOPES.pop(result.scope_id)
        recovered = get_committed_scope(result.scope_id, storage_dir=storage_dir)
        assert recovered is not None
        assert len(recovered.room_types) == 1


def test_main_prints_a_commit_summary_and_returns_zero_on_success():
    """Uses the 'ingest' subcommand -- main() was restructured to real
    subcommands in M6 Slice 2 once a second command (list) existed;
    corrected from Slice 1's flat main(["exim", ...]) invocation."""
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = main(["ingest", "exim", EXIM_FIXTURE, "--room-codes", "DR01"])
    assert exit_code == 0
    output = buf.getvalue()
    assert "Committed" in output
    assert "room type" in output.lower()


def test_main_prints_review_items_and_returns_nonzero_on_rejection():
    buf = io.StringIO()
    with redirect_stdout(buf):
        exit_code = main(["ingest", "alltours", ALLTOURS_FIXTURE, "--room-codes", "DZP"])
    assert exit_code != 0
    output = buf.getvalue()
    assert "Rejected" in output
    assert "adults" in output
    assert "children" in output


def test_list_committed_scope_ids_includes_a_freshly_committed_scope():
    """A scope committed with a fresh storage_dir must appear in that
    same storage_dir's listing."""
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        assert scope.scope_id in list_committed_scope_ids(storage_dir=storage_dir)


def test_list_committed_scope_ids_recovers_from_disk_after_cache_cleared():
    """The real point of this command existing on a CLI at all: a fresh
    process (simulated by clearing the in-memory cache) must still see
    what's on disk, not just what happened to be committed in the same
    run."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        registry_store._COMMITTED_SCOPES.pop(result.scope_id)
        assert result.scope_id in list_committed_scope_ids(storage_dir=storage_dir)


def test_list_committed_scope_ids_without_storage_dir_does_not_see_disk_only_entries():
    """Without storage_dir, listing must never silently fall back to
    disk -- an id only recoverable from a storage_dir must not appear
    in a call that omits it, same 'no implicit default location'
    discipline get_committed_scope already follows."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        registry_store._COMMITTED_SCOPES.pop(result.scope_id)
        assert result.scope_id not in list_committed_scope_ids()


def test_main_list_command_prints_committed_scope_ids():
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)

        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["list", "--storage-dir", storage_dir])
        assert exit_code == 0
        assert result.scope_id in buf.getvalue()


def test_run_review_lists_the_real_review_items_from_a_saved_draft():
    """Alltours' real DZP scope is rejected by ingest (saving a draft
    automatically, M6 Slice 3), and a completely separate run_review()
    call -- simulating a fresh CLI invocation -- must see the same 2
    real review items."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)
        assert result.committed is False

        items = run_review(result.scope_id, storage_dir)
        assert {i.field_name for i in items} == {"adults", "children"}


def test_run_review_raises_for_an_unknown_scope_id():
    with tempfile.TemporaryDirectory() as storage_dir:
        try:
            run_review("not-a-real-id", storage_dir)
            assert False, "expected ValueError for a scope id with no saved draft"
        except ValueError:
            pass


def test_run_correct_applies_one_field_and_reports_still_needs_review():
    """Correcting only one of Alltours DZP's two real review items must
    leave the scope still rejected, with exactly the one remaining field
    reported -- not silently committed early, not losing track of what's
    left."""
    with tempfile.TemporaryDirectory() as storage_dir:
        ingest_result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)
        first_item = next(i for i in ingest_result.review_items if i.field_name == "adults")

        result = run_correct(ingest_result.scope_id, storage_dir, first_item.entity_id, "adults",
                              first_item.current_value, ConfidenceLevel.HIGH)
        assert isinstance(result, CorrectResult)
        assert result.applied is True
        assert result.committed is False
        assert {i.field_name for i in result.remaining_review_items} == {"children"}


def test_run_correct_recommits_once_the_last_field_is_fixed():
    """The real end-to-end proof: correcting both real review items
    across two separate run_correct() calls (matching real one-field-
    at-a-time CLI usage) must commit the scope on the second call, and
    it must then be retrievable through the ordinary registry path."""
    with tempfile.TemporaryDirectory() as storage_dir:
        ingest_result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)

        for item in ingest_result.review_items:
            result = run_correct(ingest_result.scope_id, storage_dir, item.entity_id, item.field_name,
                                  item.current_value, ConfidenceLevel.HIGH)

        assert result.committed is True
        assert get_committed_scope(ingest_result.scope_id, storage_dir=storage_dir) is not None


def test_run_correct_raises_for_an_unknown_field():
    with tempfile.TemporaryDirectory() as storage_dir:
        ingest_result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)
        result = run_correct(ingest_result.scope_id, storage_dir, "not-a-real-entity", "adults",
                              2, ConfidenceLevel.HIGH)
        assert result.applied is False
        assert result.committed is False


def _entity_id_for_field(storage_dir: str, scope_id: str, field_name: str) -> str:
    """Test helper only: real CLI usage would read the entity id off the
    `review` command's own printed output (it prints entity_id.field_name
    for each item) -- this just avoids re-parsing that text in the test
    itself, since run_review() already returns it structured."""
    return next(i.entity_id for i in run_review(scope_id, storage_dir) if i.field_name == field_name)


def test_main_review_and_correct_commands_close_the_full_loop():
    """The real, complete, terminal-only proof of this slice: ingest
    (rejected) -> review (lists real items) -> correct x2 (recommits) ->
    list (the scope now appears as committed) -- entirely through main(),
    the same way a real user would drive it, never touching run_ingest/
    run_review/run_correct directly."""
    with tempfile.TemporaryDirectory() as storage_dir:
        ingest_buf = io.StringIO()
        with redirect_stdout(ingest_buf):
            exit_code = main(["ingest", "alltours", ALLTOURS_FIXTURE, "--room-codes", "DZP",
                               "--storage-dir", storage_dir])
        assert exit_code == 1
        scope_id = ingest_buf.getvalue().splitlines()[0].split()[-1]

        review_buf = io.StringIO()
        with redirect_stdout(review_buf):
            exit_code = main(["review", scope_id, "--storage-dir", storage_dir])
        assert exit_code == 0
        assert "adults" in review_buf.getvalue()
        assert "children" in review_buf.getvalue()

        for field_name, value in [("adults", "2"), ("children", "0")]:
            correct_buf = io.StringIO()
            with redirect_stdout(correct_buf):
                exit_code = main(["correct", scope_id, "--storage-dir", storage_dir,
                                   "--entity-id", _entity_id_for_field(storage_dir, scope_id, field_name),
                                   "--field-name", field_name, "--value", value])

        assert exit_code == 0
        assert "committed successfully" in correct_buf.getvalue()

        list_buf = io.StringIO()
        with redirect_stdout(list_buf):
            main(["list", "--storage-dir", storage_dir])
        assert scope_id in list_buf.getvalue()


def test_run_describe_lists_a_committed_scopes_room_types():
    """EXIM's real DR01 scope, once committed, must be describable --
    the real room_type_id a subsequent `price` call needs, not just a
    bare count."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        assert result.committed is True

        room_types = run_describe(result.scope_id, storage_dir=storage_dir)
        assert len(room_types) == 1
        assert isinstance(room_types[0], RoomTypeSummary)
        assert room_types[0].room_type_id
        assert room_types[0].canonical_code == "DR01"


def test_run_describe_raises_for_an_unknown_scope_id():
    with tempfile.TemporaryDirectory() as storage_dir:
        try:
            run_describe("not-a-real-id", storage_dir=storage_dir)
            assert False, "expected ValueError for an unknown/uncommitted scope id"
        except ValueError as e:
            assert "not-a-real-id" in str(e)


def test_run_price_prices_a_real_booking_against_a_committed_scope():
    """The real end-to-end proof: describe -> price, using the actual
    room_type_id describe() returns, must produce the real known invoice
    total (46.00 PPPN * 7 nights * 2 adults), not a placeholder."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        price_result = run_price(result.scope_id, storage_dir, room_type_id,
                                  date(2026, 7, 1), date(2026, 7, 8), adults=2, children=0, infants=0)
        assert isinstance(price_result, PriceResult)
        assert price_result.valid is True
        assert price_result.invoice is not None
        assert price_result.invoice.total == 46.00 * 7 * 2


def test_run_price_reports_invalid_for_an_occupancy_the_room_does_not_support():
    """DR01's real occupancy combos (inspected directly) top out at 3
    adults -- a 4-adult booking is a real, deterministic invalid case,
    not a synthetic one."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        price_result = run_price(result.scope_id, storage_dir, room_type_id,
                                  date(2026, 7, 1), date(2026, 7, 8), adults=4, children=0, infants=0)
        assert price_result.valid is False
        assert price_result.invoice is None
        assert any(i.code == "OCCUPANCY_NOT_PERMITTED" for i in price_result.validation_issues)


def test_run_price_raises_for_an_unknown_scope_id():
    with tempfile.TemporaryDirectory() as storage_dir:
        try:
            run_price("not-a-real-id", storage_dir, "some-room-id", date(2026, 7, 1), date(2026, 7, 8), adults=2)
            assert False, "expected ValueError for an unknown/uncommitted scope id"
        except ValueError as e:
            assert "not-a-real-id" in str(e)


def test_main_describe_command_prints_room_types():
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)

        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["describe", result.scope_id, "--storage-dir", storage_dir])
        assert exit_code == 0
        assert "DR01" in buf.getvalue()


def test_main_price_command_prints_invoice_and_returns_zero_on_a_valid_booking():
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["price", result.scope_id, "--storage-dir", storage_dir,
                               "--room-type-id", room_type_id, "--check-in", "2026-07-01",
                               "--check-out", "2026-07-08", "--adults", "2"])
        assert exit_code == 0
        output = buf.getvalue()
        assert "644.00" in output or "644.0" in output


def test_main_price_command_prints_issues_and_returns_nonzero_on_an_invalid_booking():
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["price", result.scope_id, "--storage-dir", storage_dir,
                               "--room-type-id", room_type_id, "--check-in", "2026-07-01",
                               "--check-out", "2026-07-08", "--adults", "4"])
        assert exit_code != 0
        assert "OCCUPANCY_NOT_PERMITTED" in buf.getvalue()


def test_run_price_with_child_ages_reaches_the_real_exim_child_pct_discount():
    """EXIM's real CHILD_PCT rules (M4 Slice 3) were completely
    unreachable from the CLI before this slice -- a 2-adult/1-child DR01
    booking with the child's real age supplied must produce the real
    100%-reduction child line (unit_rate 0.0), not price the child at
    the standard adult rate for lack of any way to say how old they
    are."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("exim", EXIM_FIXTURE, room_codes=["DR01"], storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        price_result = run_price(result.scope_id, storage_dir, room_type_id,
                                  date(2026, 7, 1), date(2026, 7, 8), adults=2, children=1,
                                  child_ages=[4])
        assert price_result.valid is True
        child_line = next(l for l in price_result.invoice.lines if "Child" in l.description)
        assert child_line.unit_rate == 0.0
        assert price_result.invoice.total == (46.00 * 7 * 2) + (0.0 * 7 * 1)


def test_run_price_with_adult_ages_reaches_the_real_alltours_senior_discount():
    """Alltours' real Senior Discount (M4) needs an identified ADULT
    guest age -- unreachable from the CLI before this slice. One senior
    (65) and one non-senior (45) must produce exactly one standard-rate
    line and one 10%-reduced line, never both discounted or neither.

    DZP's real occupancy stack is LOW-confidence (flagged since M3), so
    it's rejected on the first ingest -- corrected here the same way
    every other Alltours-based test in this project already does, not a
    special case for this test."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)
        assert result.committed is False
        for item in result.review_items:
            correct_result = run_correct(result.scope_id, storage_dir, item.entity_id, item.field_name,
                                          item.current_value, ConfidenceLevel.HIGH)
        assert correct_result.committed is True

        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        price_result = run_price(result.scope_id, storage_dir, room_type_id,
                                  date(2026, 5, 21), date(2026, 5, 28), adults=2, children=0,
                                  adult_ages=[65, 45])
        assert price_result.valid is True
        assert {round(l.unit_rate, 2) for l in price_result.invoice.lines} == {66.00, round(66.00 * 0.9, 2)}


def test_run_price_with_booking_date_reaches_the_real_anex_release_warning():
    """Anex's real Release Rule (M4) only ever fires with a supplied
    booking_date -- unreachable from the CLI before this slice. A
    booking made 3 real days before a real 21.05-28.06 check-in (inside
    the real 5-day release window) must surface the warning, not price
    silently as if it were never checked."""
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("anex", ANEX_FIXTURE, storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        price_result = run_price(result.scope_id, storage_dir, room_type_id,
                                  date(2026, 5, 25), date(2026, 6, 1), adults=3, children=0,
                                  booking_date=date(2026, 5, 22))
        assert price_result.valid is True
        assert any(i.code == "BOOKING_INSIDE_RELEASE_PERIOD" for i in price_result.validation_issues)


def test_main_price_command_prints_warnings_alongside_a_valid_invoice():
    with tempfile.TemporaryDirectory() as storage_dir:
        result = run_ingest("anex", ANEX_FIXTURE, storage_dir=storage_dir)
        room_type_id = run_describe(result.scope_id, storage_dir=storage_dir)[0].room_type_id

        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["price", result.scope_id, "--storage-dir", storage_dir,
                               "--room-type-id", room_type_id, "--check-in", "2026-05-25",
                               "--check-out", "2026-06-01", "--adults", "3",
                               "--booking-date", "2026-05-22"])
        assert exit_code == 0
        output = buf.getvalue()
        assert "BOOKING_INSIDE_RELEASE_PERIOD" in output
        assert "Total" in output  # the invoice still printed -- a warning never blocks pricing
