"""
M1 — Walking Skeleton: EXIM.

Real PDF in, one correct invoice line out, through every layer of the
architecture: document_parser -> semantic_adapters/exim -> contract_model
-> validation -> expression_engine -> pricing_engine.

The number this test anchors on (46.00 USD PPPN for DR01, summer 2026) was
hand-verified against the source PDF this session -- see page 3, "1. DR01 -
Double Room Garden View", row "01.05.26 31.10.26 All 46,00 73,60 ...".
"""

import os
from datetime import date

from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import (
    BookingRequest, price_booking, validate_booking, PricingError,
)

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def _build_dr01_scope():
    return build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])


def test_exim_adapter_produces_a_valid_contract_scope_for_dr01():
    scope = _build_dr01_scope()

    assert scope.hotel.name == "Amarina Jannah Resort & Aqua Park"
    assert scope.valid_from == date(2026, 5, 1)
    assert scope.valid_to == date(2026, 10, 31)

    assert len(scope.room_types) == 1
    room = scope.room_types[0]
    assert room.canonical_code == "DR01"
    assert room.display_name == "Double Room Garden View"
    assert len(room.valid_occupancies) == 7  # 1+0, 1+1, 1+2, 2+0, 2+1, 2+2, 3+0

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"


def test_exim_dr01_pppn_rate_extracted_correctly_from_the_real_pdf():
    """The specific number this whole milestone exists to prove."""
    scope = _build_dr01_scope()
    pppn_rates = [r for r in scope.rates if r.basis.value == "per_person_per_night"]
    assert len(pppn_rates) == 1
    assert pppn_rates[0].amount.value == 46.00
    assert pppn_rates[0].amount.confidence.value == "high"
    assert pppn_rates[0].amount.provenance.page_number == 3

    sopn_rates = [r for r in scope.rates if r.basis.value == "single_occupancy_per_night"]
    assert len(sopn_rates) == 1
    assert sopn_rates[0].amount.value == 73.60


def test_exim_dr01_end_to_end_invoice_matches_hand_verified_value():
    """PDF -> adapter -> validation -> expression_engine -> pricing_engine,
    for a real 7-night booking, 2 adults, in DR01."""
    scope = _build_dr01_scope()
    issues = validate(scope)
    assert not has_blocking_errors(issues)

    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id,
        check_in=date(2026, 7, 1),
        check_out=date(2026, 7, 8),  # 7 nights
        adults=2, children=0, infants=0,
    )

    booking_issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in booking_issues), booking_issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    line = invoice.lines[0]
    assert line.unit_rate == 46.00           # the known-correct PPPN value
    assert line.nights == 7
    assert line.quantity == 2
    assert line.line_total == 46.00 * 7 * 2  # 644.00
    assert invoice.total == 644.00
    assert invoice.currency == "USD"


def test_booking_with_invalid_occupancy_is_rejected_before_pricing():
    """5 adults is not a valid DR01 combination (max is 3+0) -- must be
    caught by booking-time validation, never silently priced."""
    scope = _build_dr01_scope()
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
        adults=5, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    codes = [i.code for i in issues]
    assert "OCCUPANCY_NOT_PERMITTED" in codes

    try:
        price_booking(scope, booking)
        assert False, "expected PricingError"
    except PricingError:
        pass


def test_booking_outside_the_contracted_season_is_rejected():
    scope = _build_dr01_scope()
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 12, 20), check_out=date(2026, 12, 27),
        adults=2, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    codes = [i.code for i in issues]
    assert "DATES_OUTSIDE_SEASON" in codes


def test_pricing_engine_never_uses_a_raw_float_it_goes_through_the_expression_engine():
    """Structural check: the pricing path must produce the number by
    evaluating a RateRef Expression against the Rate's Extracted amount,
    not by reading Rate.amount.value directly into the invoice.

    Checks the full call chain price_booking() delegates to, not just its
    own source: M4 Slice 2 correctly extracted base-rate evaluation into
    _adult_lines() (to generalize consumption beyond a flat unit_rate x
    adults once real positional SUPPLEMENT rules exist) -- the property
    being tested still holds, just one function away from where it did
    before."""
    import inspect
    from contract_platform.pricing_engine import calculator
    combined_source = (
        inspect.getsource(calculator.price_booking)
        + inspect.getsource(calculator._adult_lines)
    )
    assert "evaluate(" in combined_source
    assert "RateRef(" in combined_source
