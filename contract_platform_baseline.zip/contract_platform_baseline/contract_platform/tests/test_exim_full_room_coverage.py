"""
M4, first slice — EXIM full room coverage.

Deliberately scoped narrowly, per the agreed plan: extend EXIM to all 15
real rooms, validate the resulting ContractScope at full scale, price
representative bookings across diverse rooms. No new PricingRule
construction was in scope for *this* slice at the time it was written --
that arrived in the very next slice (M4 Slice 2: EXIM AMR -> real
SUPPLEMENT rules), which is why one test below is a corrected version of
this slice's original "no PricingRule was built yet" boundary marker
rather than a fresh addition.

Two real adapter bugs were found and fixed extending to full coverage
(both in find_rate_block_for_room, semantic_adapters/exim/adapter.py):
  1. A page-level "Rates" substring pre-filter silently skipped page 4,
     a continuation of the same Rates table with no repeated section
     header -- FR04's real rate row lives there and was unfindable.
  2. Removing that filter naively then let the Units-table occurrence of
     a room's header line (which matches the same loose header regex)
     shadow the real Rates-table occurrence, since Units comes first in
     page order -- fixed by discriminating candidate blocks by content
     (must contain PPPN or SOPN) rather than by page-level text.
Both are EXIM-adapter-specific implementation bugs, not Contract Model or
Pricing Engine issues -- exactly the kind of thing full-scale coverage is
expected to surface and the checkpoint discipline is designed to catch
cheaply.
"""

import os
from datetime import date

from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")

ALL_ROOM_CODES = [
    "DR01", "SR01", "DR05", "SR05", "DR07", "SR07", "DR08", "SR08",
    "FR02", "FR04", "SU02", "DR09", "SR09", "DR10", "SR10",
]

_CACHED_SCOPE = None


def _build_full_scope():
    global _CACHED_SCOPE
    if _CACHED_SCOPE is None:
        _CACHED_SCOPE = build_contract_scope(FIXTURE_PATH, room_codes=ALL_ROOM_CODES)
    return _CACHED_SCOPE


def _room(scope, code):
    return next(r for r in scope.room_types if r.canonical_code == code)


def test_all_fifteen_real_rooms_parse_successfully():
    """The specific real bug this slice found and fixed: every room must
    be independently parseable, including FR04 (continuation-page rate
    block) and every room whose header line also appears, unrelated, in
    the Units/Facilities/Allocation sections."""
    scope = _build_full_scope()
    parsed_codes = {r.canonical_code for r in scope.room_types}
    assert parsed_codes == set(ALL_ROOM_CODES)
    assert len(scope.room_types) == 15


def test_every_room_pppn_matches_the_real_source_table():
    """Cross-checked against the real PDF's Rates section for every room
    -- not spot-checked, all 15."""
    scope = _build_full_scope()
    expected_pppn = {
        "DR01": 46.00, "SR01": 73.60, "DR05": 51.00, "SR05": 81.60,
        "DR07": 54.00, "SR07": 86.40, "DR08": 61.00, "SR08": 97.60,
        "FR02": 73.50, "FR04": 76.00, "SU02": 86.00, "DR09": 46.00,
        "SR09": 73.60, "DR10": 51.00, "SR10": 81.60,
    }
    for code, expected in expected_pppn.items():
        room = _room(scope, code)
        rate = next(
            r for r in scope.rates
            if r.room_type_id == room.id and r.basis.value == "per_person_per_night"
        )
        assert rate.amount.value == expected, f"{code}: expected {expected}, got {rate.amount.value}"


def test_full_scope_validates_with_no_blocking_errors_at_scale():
    """First real test of the model-level invariants (every room has a
    base rate, no duplicate rates, occupancies closed) against a
    real, adapter-built, multi-room scope rather than 1-2 hand-built
    rooms in a unit test."""
    scope = _build_full_scope()
    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"


def test_rooms_without_an_explicit_occupancy_combo_list_correctly_fall_back_to_low_confidence():
    """Single rooms (and DR10, and FR04 -- none named in the source
    document's free-text 'Room Occupancy:' combo block) must fall back
    to the documented LOW-confidence single-combo path, not silently
    invent a combo list the document doesn't give. Confirms this M1-era
    fallback logic still fires correctly at full scale, not just for the
    one room M1 originally tested it against."""
    scope = _build_full_scope()
    fallback_rooms = ["SR01", "SR05", "SR07", "SR08", "SR09", "SR10", "DR10", "FR04"]
    for code in fallback_rooms:
        room = _room(scope, code)
        assert len(room.valid_occupancies) == 1, f"{code}: expected exactly the LOW-confidence fallback combo"
        occ = room.valid_occupancies[0]
        assert occ.adults.confidence.value == "low"


def test_rooms_with_explicit_occupancy_combo_lists_are_high_confidence_and_fully_enumerated():
    """The double/family/suite rooms the source document does explicitly
    enumerate must retain every real combo, at full HIGH confidence --
    proves the fallback above is genuinely conditional, not a blanket
    default."""
    scope = _build_full_scope()
    expected_combo_counts = {
        "DR01": 7, "DR05": 8, "DR07": 8, "DR08": 8, "DR09": 8,
        "FR02": 11, "SU02": 5,
    }
    for code, expected_count in expected_combo_counts.items():
        room = _room(scope, code)
        assert len(room.valid_occupancies) == expected_count, code
        assert all(o.adults.confidence.value == "high" for o in room.valid_occupancies), code


def test_representative_bookings_price_correctly_across_diverse_rooms():
    """Prices real bookings across a deliberately varied set: a plain
    double, a single room (exercising the SOPN path at scale, not just
    DR01/SR01 in isolation), a family room, a suite, and a second double
    room sharing DR01's exact rate (DR09) as a cross-check that two
    different RoomTypes correctly resolve independently.

    DR09's 3-adult case is deliberately not a flat unit_rate x 3: the
    real contract's "3A AmR pN" column (6.00) means the 3rd adult prices
    at 40.00 (46.00 - 6.00), not 46.00 -- confirmed once M4 Slice 2 built
    this into a real SUPPLEMENT PricingRule. See
    test_exim_supplement_rules.py for the dedicated proof; this test just
    needs the correct total, not the breakdown."""
    scope = _build_full_scope()

    cases = [
        ("DR01", 2, 0, 0, 46.00, 46.00 * 7 * 2),
        ("SR01", 1, 0, 0, 73.60, 73.60 * 7 * 1),  # SOPN, not PPPN
        ("FR02", 2, 2, 0, 73.50, 73.50 * 7 * 2),
        ("SU02", 2, 1, 0, 86.00, 86.00 * 7 * 2),
        ("DR09", 3, 0, 0, 46.00, (46.00 * 7 * 2) + (40.00 * 7 * 1)),  # 3rd adult reduced
    ]

    for code, adults, children, infants, expected_unit_rate, expected_total in cases:
        room = _room(scope, code)
        booking = BookingRequest(
            room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
            adults=adults, children=children, infants=infants,
        )
        issues = validate_booking(scope, booking)
        assert not any(i.severity.value == "error" for i in issues), f"{code}: {issues}"

        invoice = price_booking(scope, booking)
        assert invoice.lines[0].unit_rate == expected_unit_rate, code
        assert invoice.total == expected_total, code


def test_amr_supplement_rules_do_not_affect_rooms_without_a_third_adult_booked():
    """A 2-adult booking on a room that DOES have a real 3rd-adult
    SUPPLEMENT rule must be completely unaffected by it -- the rule only
    applies when a booking actually has a matching pax slot. Superseded
    the old Slice-1 boundary marker (scope.pricing_rules == []), which
    was correct for Slice 1 and is deliberately no longer true after
    Slice 2 built real SUPPLEMENT rules -- this test replaces it with the
    thing that actually matters now: those rules don't leak into bookings
    they don't apply to."""
    scope = _build_full_scope()
    assert len(scope.pricing_rules) > 0  # Slice 2 built real rules; this is now expected

    room = _room(scope, "DR01")
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1  # no positional line for a 2-adult booking
    assert invoice.total == 46.00 * 7 * 2
