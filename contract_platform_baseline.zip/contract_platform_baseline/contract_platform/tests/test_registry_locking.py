"""
Write-write mutual exclusion for the registry -- the gap the atomic-
writes slice's own docstring named and deliberately left open: two
genuinely concurrent commits to the same scope_id resolved last-write-
wins. That gap became a real, not just theoretical, risk once the API
layer made this project reachable from multiple concurrent HTTP
requests (potentially across gunicorn's several worker processes)
rather than only ever one CLI operator at a time.

The concrete failure mode this closes: two callers correcting different
fields on the same rejected scope at the same instant. Each individually
loads the same stale draft, applies its own edit, and commits -- one
commit's file write overwrites the other's, so one caller's correction
is silently lost even though that caller's own response reported
success. registry.store.scope_lock() serializes the entire load-modify-
commit sequence per scope_id (see its own docstring for the two-layer
in-process/cross-process design); orchestration.run_correct() and
run_ingest() now wrap their read-modify-write sequences in it.

Proven two ways, matching how test_registry_atomic_writes.py proved
atomicity itself: a direct test of the locking primitive under real
thread concurrency (a deliberately slow critical section must never
overlap), and a real end-to-end scenario using Alltours' actual DZP
fixture -- the same real two-LOW-confidence-field scope already used in
test_review_ui_corrections.py -- with two genuine threads correcting its
two different fields at the same instant.
"""

import os
import threading
import time

from contract_platform.registry.store import scope_lock
from contract_platform.orchestration import run_ingest, run_correct
from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.registry.store import get_committed_scope

ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_scope_lock_serializes_two_threads_never_overlapping():
    """A deliberately slow critical section, entered by two threads at
    the same instant: with real mutual exclusion, they can never be
    inside it at the same time -- proven by an overlap flag, not just a
    logical argument."""
    overlap_detected = []
    currently_inside = {"count": 0}
    guard = threading.Lock()

    def critical_section():
        with scope_lock("shared-scope-id", storage_dir=None):
            with guard:
                currently_inside["count"] += 1
                if currently_inside["count"] > 1:
                    overlap_detected.append(True)
            time.sleep(0.05)
            with guard:
                currently_inside["count"] -= 1

    threads = [threading.Thread(target=critical_section) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert overlap_detected == []


def test_concurrent_corrections_to_different_fields_never_lose_an_update():
    """The real end-to-end proof. Alltours' DZP room has exactly two
    real LOW-confidence fields (adults, children) -- a scope needing
    both corrected before it can commit. Two genuine threads correct
    the two different fields at the same instant, synchronized with a
    Barrier so neither can simply finish before the other starts (which
    would trivially avoid the race rather than test it).

    Without scope_lock around the full load-modify-commit sequence,
    both threads can load the same stale draft, each apply only their
    own field's fix, and race to commit -- one write overwrites the
    other, so the final scope is missing one correction and stays
    uncommitted forever, silently, even though both HTTP-level calls
    reported applied=True. With it, the final state must always be
    fully committed, regardless of which thread happened to acquire the
    lock first."""
    import tempfile
    with tempfile.TemporaryDirectory() as storage_dir:
        ingest_result = run_ingest("alltours", ALLTOURS_FIXTURE, room_codes=["DZP"], storage_dir=storage_dir)
        assert ingest_result.committed is False  # both fields still LOW-confidence, as expected
        assert {i.field_name for i in ingest_result.review_items} == {"adults", "children"}

        adults_item = next(i for i in ingest_result.review_items if i.field_name == "adults")
        children_item = next(i for i in ingest_result.review_items if i.field_name == "children")

        barrier = threading.Barrier(2)
        errors = []

        def correct(item, field_name):
            try:
                barrier.wait()  # force both threads to start their correction at the same instant
                run_correct(ingest_result.scope_id, storage_dir, item.entity_id, field_name,
                            item.current_value, ConfidenceLevel.HIGH)
            except Exception as e:  # pragma: no cover - surfaced via `errors`, not a bare assert in a thread
                errors.append(e)

        t1 = threading.Thread(target=correct, args=(adults_item, "adults"))
        t2 = threading.Thread(target=correct, args=(children_item, "children"))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        assert errors == []
        # The real proof: both corrections survived and the scope is
        # now committed -- neither thread's write silently erased the
        # other's, whichever one happened to run first.
        committed = get_committed_scope(ingest_result.scope_id, storage_dir=storage_dir)
        assert committed is not None
