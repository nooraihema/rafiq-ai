"""
M6, Slice 3 — draft scope persistence: the real gap M6 Slice 2's own
README note surfaced. A rejected scope, before this slice, only existed
in the calling process's memory -- lost the moment that process exited.
For a CLI review/correct loop to work at all (ingest in one invocation,
fix in a later, separate one), a rejected scope has to survive between
those invocations the same way a committed one already does.

Chosen as the highest-value next slice after inspecting the whole
project fresh, not by following the previous "Next" note mechanically
(the note happened to name this same gap, but it was re-derived here by
asking what a real user would actually hit first: running `ingest`,
seeing "Rejected: 2 fields need review", and then having no way to
proceed via the CLI at all -- arguably the most visible dead end in the
product today, more so than a `price` command, which is only useful
once a scope is already committed, or an API, which has no scaffolding
or dependency evidence anywhere in this codebase).

No Contract Model change. save_draft_scope()/load_draft_scope()/
discard_draft_scope() reuse contract_model/serialization.py (M5 Slice 4)
exactly the way commit_scope()'s own committed-scope persistence
already does -- this is the same mechanism, applied to a second real
state (draft, not just committed), not a new one.

Drafts live in a drafts/ subdirectory under storage_dir, deliberately
separate from committed scopes' <scope_id>.json files at the top level
-- "is this id committed?" and "is this id a pending draft?" must never
be confused by filename alone.
"""

import os
import tempfile

from contract_platform.contract_model.entities import ContractScope, RoomType
from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as build_alltours_scope
from contract_platform.registry.store import (
    commit_scope, save_draft_scope, load_draft_scope, discard_draft_scope, get_committed_scope,
)
from contract_platform.review_ui.corrections import list_review_items, apply_correction

ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_save_and_load_draft_scope_round_trips():
    """A basic, direct round trip -- no adapter, no OCR cost -- proving
    the draft mechanism itself works before layering the commit gate on
    top of it."""
    with tempfile.TemporaryDirectory() as storage_dir:
        room = RoomType(canonical_code="XX01", display_name="Test Room")
        scope = ContractScope(room_types=[room])

        save_draft_scope(scope, storage_dir)
        loaded = load_draft_scope(scope.id, storage_dir)

        assert loaded is not None
        assert loaded is not scope
        assert loaded == scope


def test_load_draft_scope_returns_none_for_an_unknown_id():
    with tempfile.TemporaryDirectory() as storage_dir:
        assert load_draft_scope("not-a-real-id", storage_dir) is None


def test_commit_scope_saves_a_draft_on_rejection_when_storage_dir_given():
    """The real integration point: commit_scope() itself must save the
    draft on rejection, not require the caller to remember to call
    save_draft_scope() separately."""
    with tempfile.TemporaryDirectory() as storage_dir:
        room = RoomType(canonical_code="XX01", display_name="Test Room")
        scope = ContractScope(room_types=[room])

        result = commit_scope(scope, storage_dir=storage_dir)
        assert result.committed is False

        loaded = load_draft_scope(scope.id, storage_dir)
        assert loaded is not None
        assert loaded == scope


def test_commit_scope_without_storage_dir_saves_no_draft():
    """Omitting storage_dir must reproduce the exact pre-Slice-3
    behavior -- a rejected scope with no storage_dir is simply lost when
    the process exits, same as before this slice, not silently saved
    somewhere implicit."""
    room = RoomType(canonical_code="XX01", display_name="Test Room")
    scope = ContractScope(room_types=[room])
    result = commit_scope(scope)  # no storage_dir
    assert result.committed is False
    # nothing to check on disk -- there is no location to check, by design


def test_discard_draft_scope_is_a_safe_no_op_for_an_unknown_id():
    with tempfile.TemporaryDirectory() as storage_dir:
        discard_draft_scope("not-a-real-id", storage_dir)  # must not raise


def test_the_real_end_to_end_loop_reject_save_draft_correct_recommit_discard_draft():
    """The actual proof this slice exists for: Alltours' real DZP scope
    is rejected and saved as a draft, corrected via review_ui (loading
    the draft fresh, not reusing the original in-memory object --
    proving the persisted draft itself is what gets corrected), and
    re-committed successfully -- after which the draft is discarded, not
    left behind as a stale, misleading artifact."""
    with tempfile.TemporaryDirectory() as storage_dir:
        original = build_alltours_scope(ALLTOURS_FIXTURE, room_codes=["DZP"])
        first_attempt = commit_scope(original, storage_dir=storage_dir)
        assert first_attempt.committed is False

        draft = load_draft_scope(original.id, storage_dir)
        assert draft is not None
        assert draft is not original

        for item in list_review_items(draft):
            assert apply_correction(draft, item.entity_id, item.field_name, item.current_value, ConfidenceLevel.HIGH)

        second_attempt = commit_scope(draft, storage_dir=storage_dir)
        assert second_attempt.committed is True

        assert load_draft_scope(original.id, storage_dir) is None  # discarded, not left stale
        assert get_committed_scope(original.id, storage_dir=storage_dir) is not None
