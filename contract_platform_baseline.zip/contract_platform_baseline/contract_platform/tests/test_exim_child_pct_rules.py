"""
M4, Slice 3 — EXIM's CHILD_PCT columns (1C2A/2C2A), the platform's first
position-*and*-age-dependent CHILD_POLICY rules.

Real data (DR05's Rates block): "1C2A 1R %R PN"=100.00, "1C2A 2R %R
PN"=100.00, "2C2A 1R %R PN"=100.00, "2C2A 2R %R PN"=50.00 -- i.e. the 1st
child is free in both age bands (2-6 and 7-14), the 2nd child is free in
the younger band but only 50% reduced in the older one. child_n (1/2) is
position -- reuses PricingRule.applies_to_pax_number, added in Slice 2 for
adults, with no new Model field, exactly as the M4 checkpoint list
predicted ("no AgeCondition.position field implied"). age_range_n (1/2)
selects which Units-table age band (age_band_1/age_band_2) the rule's
AgeCondition is built from.

DR01/DR09/SR01 only have 1st-child columns (no 2nd-child row at all) --
proves the generalization doesn't invent a 2nd-child rule where the real
data has none.
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, GuestAge, price_booking, validate_booking,
)
from contract_platform.contract_model.vocabulary import GuestType
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def _pppn(scope):
    return next(r for r in scope.rates if r.basis.value == "per_person_per_night")


def test_dr01_produces_two_child_pct_rules_one_per_age_band_first_child_only():
    """DR01's real data has only 1st-child columns (1C2A 1R, 1C2A 2R) --
    no 2nd-child row exists for this room. Must produce exactly 2
    CHILD_POLICY rules, both applies_to_pax_number == 1."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    child_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.CHILD_POLICY]
    assert len(child_rules) == 2
    assert all(r.applies_to_pax_number == 1 for r in child_rules)
    assert all(r.applicability and r.applicability[0].role == GuestType.CHILD for r in child_rules)

    pppn = _pppn(scope)
    for rule in child_rules:
        ctx = EvaluationContext(rate_values={pppn.id: pppn.amount.value})
        # 100% reduction -> child stays free
        assert evaluate(rule.calculation.value, ctx) == 0.0


def test_dr05_produces_four_child_pct_rules_position_and_age_dependent():
    """DR05 has both 1st- and 2nd-child rows, with the real data point
    this slice exists to prove: 2nd child in the older band (7-14) is
    only 50% reduced, not free."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR05"])
    child_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.CHILD_POLICY]
    assert len(child_rules) == 4

    pppn = _pppn(scope)
    ctx = EvaluationContext(rate_values={pppn.id: pppn.amount.value})

    second_child_older_band = next(
        r for r in child_rules
        if r.applies_to_pax_number == 2 and r.applicability[0].max_age.value == 14.0
    )
    assert evaluate(second_child_older_band.calculation.value, ctx) == pppn.amount.value * 0.5

    second_child_younger_band = next(
        r for r in child_rules
        if r.applies_to_pax_number == 2 and r.applicability[0].max_age.value == 6.0
    )
    assert evaluate(second_child_younger_band.calculation.value, ctx) == 0.0


def test_pricing_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR05"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_two_child_booking_prices_each_child_at_its_own_positional_rate():
    """The real end-to-end proof: a DR05 booking with 2 adults and 2
    children (ages 4 and 10) must price the 1st child (age 4) free and
    the 2nd child (age 10) at 50% of PPPN -- not both at the same rate,
    and not both free."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR05"])
    room = scope.room_types[0]
    pppn = _pppn(scope)
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
        adults=2, children=2, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.CHILD, age=4),
            GuestAge(role=GuestType.CHILD, age=10),
        ]),
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    child_lines = [l for l in invoice.lines if "Child" in l.description]
    assert len(child_lines) == 2
    first_child_line = next(l for l in child_lines if "age 4" in l.description)
    second_child_line = next(l for l in child_lines if "age 10" in l.description)
    assert first_child_line.unit_rate == 0.0
    assert second_child_line.unit_rate == pppn.amount.value * 0.5


def test_single_child_booking_only_matches_the_first_child_position():
    """A booking with just one child (age 10, the older band) must match
    the 1st-child rule for that band (100% reduction), not accidentally
    fall through to the 2nd-child rule's 50% just because both match the
    age band -- position is assigned by party order, not guessed."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR05"])
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
        adults=2, children=1, infants=0,
        context=BookingApplicabilityContext(guest_ages=[GuestAge(role=GuestType.CHILD, age=10)]),
    )
    invoice = price_booking(scope, booking)
    child_line = next(l for l in invoice.lines if "Child" in l.description)
    assert child_line.unit_rate == 0.0  # 1st child, older band = 100% reduction


def test_anex_child_policy_unaffected_by_positional_generalization():
    """Anex's one real CHILD_POLICY rule has applies_to_pax_number == None
    (position-agnostic) -- must keep matching every child regardless of
    party position, byte-identical to before this slice."""
    from contract_platform.semantic_adapters.anex.adapter import build_contract_scope as build_anex_scope
    anex_fixture = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")
    scope = build_anex_scope(anex_fixture)
    promo = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
        adults=2, children=2, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.CHILD, age=8),
            GuestAge(role=GuestType.CHILD, age=9),
        ]),
    )
    invoice = price_booking(scope, booking)
    child_lines = [l for l in invoice.lines if "Child" in l.description]
    assert len(child_lines) == 2
    assert all(l.unit_rate == 62.00 * 1.5 for l in child_lines)
