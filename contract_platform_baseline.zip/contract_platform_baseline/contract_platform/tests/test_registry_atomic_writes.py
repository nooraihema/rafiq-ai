"""
Engineering Infrastructure Slice — atomic writes for registry/store.py.

This project's own full assessment named this the top technical risk:
every write to disk (a committed scope's file, a draft's file) used a
plain open(path, "w"), with no atomicity and no protection against a
crash or a genuinely concurrent writer leaving a truncated, corrupted
JSON file behind for the next reader (this process or a different one)
to load. Deferred twice in favor of product features (M6 Slices 4-5)
since nothing had exercised it yet -- addressed now under the same
"inspect the whole project, find the highest real value" mandate that
led to the PDF page cache before it.

Proven with genuine OS-level thread concurrency, not just a logical
argument: many threads writing to the same path at once must never
produce a corrupted or partially-written file -- the final file must
always be exactly one complete writer's content, parseable, never a
truncated or interleaved mix.

Deliberately scoped to atomicity only, not full write-write mutual
exclusion. Two genuinely concurrent commits to the same scope id still
resolve last-write-wins after this slice -- a real, smaller, separate
question, not attempted here without more specific evidence of the
exact concurrency pattern to design a lock around.
"""

import json
import os
import tempfile
import threading

from contract_platform.registry.store import _atomic_write, commit_scope, save_draft_scope
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.contract_model.entities import ContractScope, RoomType

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def test_atomic_write_produces_a_complete_readable_file():
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "target.json")
        _atomic_write(path, json.dumps({"a": 1, "b": "x" * 10000}))
        with open(path) as f:
            data = json.load(f)
        assert data["a"] == 1
        assert len(data["b"]) == 10000


def test_atomic_write_leaves_no_temp_files_behind():
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "target.json")
        _atomic_write(path, '{"a": 1}')
        assert os.listdir(tmp_dir) == ["target.json"]


def test_atomic_write_overwrites_an_existing_file_completely():
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "target.json")
        _atomic_write(path, json.dumps({"version": 1, "padding": "x" * 5000}))
        _atomic_write(path, json.dumps({"version": 2}))
        with open(path) as f:
            data = json.load(f)
        assert data == {"version": 2}  # not a leftover mix of both writes
        assert os.listdir(tmp_dir) == ["target.json"]


def test_atomic_write_under_many_concurrent_writers_never_corrupts_the_file():
    """The real proof: genuine OS-level thread concurrency, many writers
    racing to the same path, and the result must always be exactly one
    complete writer's content -- parseable JSON, never a truncated or
    interleaved mix of two writers' bytes."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "target.json")
        writer_count = 25
        contents = [json.dumps({"writer": i, "payload": "x" * 8000}) for i in range(writer_count)]

        threads = [threading.Thread(target=_atomic_write, args=(path, c)) for c in contents]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        with open(path) as f:
            final = json.load(f)  # must not raise -- proves no corrupted/truncated file resulted
        assert final["writer"] in range(writer_count)
        assert len(final["payload"]) == 8000

        # exactly one file remains -- no stray temp files leaked from the race
        assert os.listdir(tmp_dir) == ["target.json"]


def test_commit_scope_leaves_no_stray_temp_files_after_a_real_commit():
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
        result = commit_scope(scope, storage_dir=storage_dir)
        assert result.committed is True
        assert os.listdir(storage_dir) == [f"{scope.id}.json"]


def test_save_draft_scope_leaves_no_stray_temp_files():
    with tempfile.TemporaryDirectory() as storage_dir:
        room = RoomType(canonical_code="XX01", display_name="Test Room")
        scope = ContractScope(room_types=[room])
        save_draft_scope(scope, storage_dir)
        drafts_dir = os.path.join(storage_dir, "drafts")
        assert os.listdir(drafts_dir) == [f"{scope.id}.json"]
