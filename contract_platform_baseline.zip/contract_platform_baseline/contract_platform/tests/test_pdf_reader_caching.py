"""
The PDF page cache — chosen as the highest-value next step after
re-inspecting the whole project fresh, not a product feature.

Real evidence, not a hypothesis: every full-suite regression run across
many recent slices has needed 2-3 relaunches to complete, each run
taking 10-15+ minutes, because document_parser.read_pdf_pages() re-runs
600-DPI OCR from scratch on every single call -- and dozens of test
functions across this suite each independently build an Alltours scope
from the same PDF, the same pages, producing byte-identical OCR input
every time. Confirmed by reading pdf_reader.py directly before writing
any code: there was no caching anywhere, at any layer.

This is not a business feature and touches no business logic --
document_parser has zero business knowledge by design (its own module
docstring), and a cache of a deterministic function's output (same PDF
path + same mtime + same page number always produces the same text)
cannot silently produce a wrong result the way inventing contract data
would. That's why this is judged safe to default-enable with zero new
parameters, unlike registry's storage_dir (real business data, always
caller-supplied, never a guessed default) -- a cache miss only ever
costs time, never correctness.

Scoped to an in-memory, per-process cache only -- not persisted to
disk. That covers the actual observed pain (every full-suite run is one
process; dozens of tests in that one process re-read the same pages).
Disk-level caching (surviving across separate process invocations, e.g.
repeated individual `python3 -m contract_platform` runs during
development) is a real, plausible future enhancement, but the in-memory
cache alone addresses the concretely observed problem -- deferred rather
than guessed at, same discipline as every other slice in this project.
"""

import os
import shutil
import tempfile
import time
from unittest.mock import patch

from contract_platform.document_parser import pdf_reader

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")
ALLTOURS_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_ocr_is_not_recomputed_on_a_second_read_of_the_same_page():
    """The actual proof this cache exists for: a second read of the same
    real Alltours page must not call pytesseract again at all."""
    pdf_reader._PAGE_CACHE.clear()
    with patch.object(pdf_reader.pytesseract, "image_to_string",
                       wraps=pdf_reader.pytesseract.image_to_string) as mock_ocr:
        first = pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[1])
        assert mock_ocr.call_count == 1

        second = pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[1])
        assert mock_ocr.call_count == 1  # not called again

        assert second[0].text == first[0].text
        assert second[0].extraction_method == first[0].extraction_method == "ocr:tesseract"


def test_a_cached_read_is_measurably_faster_than_the_first():
    pdf_reader._PAGE_CACHE.clear()
    start = time.monotonic()
    pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[1])
    first_duration = time.monotonic() - start

    start = time.monotonic()
    pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[1])
    second_duration = time.monotonic() - start

    assert second_duration < first_duration / 5


def test_different_pages_of_the_same_file_are_cached_independently():
    pdf_reader._PAGE_CACHE.clear()
    page1 = pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[1])
    page3 = pdf_reader.read_pdf_pages(ALLTOURS_FIXTURE, page_numbers=[3])
    assert page1[0].text != page3[0].text
    assert page1[0].page_number == 1
    assert page3[0].page_number == 3


def test_native_text_extraction_is_also_cached_and_stays_correct():
    """EXIM's real native-text pages must be unaffected in correctness
    by adding caching -- same text, same extraction_method, every time."""
    pdf_reader._PAGE_CACHE.clear()
    first = pdf_reader.read_pdf_pages(EXIM_FIXTURE, page_numbers=[1])
    second = pdf_reader.read_pdf_pages(EXIM_FIXTURE, page_numbers=[1])
    assert first[0].text == second[0].text
    assert first[0].extraction_method == second[0].extraction_method == "native_text"


def test_cache_key_changes_when_the_underlying_file_is_modified():
    """A real correctness guard, not just a performance proof: if the PDF
    at a given path is modified (a different mtime), the old cache entry
    must not be silently reused for the new content -- proven here by
    confirming the cache grows a second, distinct entry rather than
    treating the changed file as identical to before."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_pdf = os.path.join(tmp_dir, "copy.pdf")
        shutil.copy(EXIM_FIXTURE, tmp_pdf)
        pdf_reader._PAGE_CACHE.clear()

        pdf_reader.read_pdf_pages(tmp_pdf, page_numbers=[1])
        assert len(pdf_reader._PAGE_CACHE) == 1

        future = os.path.getmtime(tmp_pdf) + 10
        os.utime(tmp_pdf, (future, future))
        pdf_reader.read_pdf_pages(tmp_pdf, page_numbers=[1])
        assert len(pdf_reader._PAGE_CACHE) == 2  # the mtime change produced a new, distinct cache key
