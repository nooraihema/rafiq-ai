"""
M5, Slice 5 — wiring contract_model/serialization.py (M5 Slice 4) into
registry/store.py, so a committed ContractScope survives a process
restart instead of only living in the in-memory dict M5 Slice 1 built.

Chosen over a CLI/API/UI pivot after inspecting the codebase for
evidence either way. Persistence has strong, repeated, textual evidence
of intent already in the codebase (invariants.py and registry/store.py
both explicitly named "Part 7"/serialization as the deferred piece this
slice closes). A CLI/API has none: no scaffolded empty package exists
for one anywhere (unlike registry/ and review_ui/, which were both
pre-scaffolded before the slices that filled them in), and no code
comment anywhere references a "Part N" for a product-facing entry
point. Building one now, with nothing pointing at its shape, would be
exactly the speculative design this project has consistently avoided --
persistence is the evidenced choice, not merely the expected one.

Design, kept deliberately backward compatible: commit_scope() and
get_committed_scope() both gain an optional storage_dir parameter.
Omitting it (every pre-existing call site, and every pre-existing test)
reproduces the exact in-memory-only behavior from M5 Slice 1 -- this
slice is purely additive, not a breaking change to an already-tested
function signature. Passing storage_dir makes commit_scope() also write
the committed scope to <storage_dir>/<scope_id>.json via
serialize_scope(), and makes get_committed_scope() fall back to reading
that file (via deserialize_scope()) when the id isn't in the in-memory
cache -- the real "survives a process restart" case, simulated in tests
by clearing the in-memory cache directly rather than by actually
restarting a process.

No hardcoded storage location anywhere in registry/store.py -- storage_dir
is always caller-supplied. There is no evidence anywhere in this codebase
for what the "right" default location would be, and inventing one would
be the same kind of silent guess Part 5 forbids adapters from making,
applied to infrastructure instead of extracted contract data.

The commit gate itself is unchanged: a rejected scope is still never
written to disk, the same way it was never added to the in-memory cache
-- persistence only ever applies to what already passed the gate.
"""

import os
import tempfile

from contract_platform.contract_model.entities import ContractScope, RoomType
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as build_exim_scope
from contract_platform.registry import store as registry_store
from contract_platform.registry.store import commit_scope, get_committed_scope
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking
from datetime import date

EXIM_FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def test_commit_scope_without_storage_dir_behaves_exactly_as_before():
    """No storage_dir given (every pre-existing call site) -- must
    reproduce M5 Slice 1's exact in-memory-only behavior. Proven by
    clearing the in-memory cache and confirming the scope is gone, since
    nothing was ever written to disk for it."""
    scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
    result = commit_scope(scope)
    assert result.committed is True
    assert get_committed_scope(scope.id) is scope

    registry_store._COMMITTED_SCOPES.pop(scope.id)
    assert get_committed_scope(scope.id) is None


def test_commit_scope_with_storage_dir_writes_a_real_json_file():
    """A real committed scope, given a storage_dir, must produce a real,
    independently-parseable JSON file on disk -- not just an in-memory
    side effect."""
    import json
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
        result = commit_scope(scope, storage_dir=storage_dir)
        assert result.committed is True

        expected_path = os.path.join(storage_dir, f"{scope.id}.json")
        assert os.path.exists(expected_path)
        with open(expected_path) as f:
            parsed = json.load(f)  # must not raise
        assert parsed["__type__"] == "ContractScope"


def test_get_committed_scope_recovers_from_disk_after_the_cache_is_cleared():
    """The real proof this slice exists for: clearing the in-memory
    cache (simulating a process restart) must not lose the scope when a
    storage_dir was used -- get_committed_scope must recover it from
    disk, and the recovered scope must price a real booking identically
    to the original."""
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
        commit_scope(scope, storage_dir=storage_dir)

        registry_store._COMMITTED_SCOPES.pop(scope.id)  # simulate restart
        assert scope.id not in registry_store._COMMITTED_SCOPES

        recovered = get_committed_scope(scope.id, storage_dir=storage_dir)
        assert recovered is not None
        assert recovered is not scope  # a genuinely different object, reconstructed from disk
        assert recovered == scope      # but structurally identical

        room = recovered.room_types[0]
        booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                                  adults=2, children=0, infants=0)
        original_room = scope.room_types[0]
        original_booking = BookingRequest(room_type_id=original_room.id, check_in=date(2026, 7, 1),
                                           check_out=date(2026, 7, 8), adults=2, children=0, infants=0)
        assert price_booking(recovered, booking).total == price_booking(scope, original_booking).total


def test_get_committed_scope_with_no_storage_dir_does_not_fall_back_to_disk():
    """Without storage_dir, a cleared cache must return None, even if a
    file happens to exist on disk from a different call -- omitting
    storage_dir must never silently start reading from some implicit
    default location."""
    with tempfile.TemporaryDirectory() as storage_dir:
        scope = build_exim_scope(EXIM_FIXTURE, room_codes=["DR01"])
        commit_scope(scope, storage_dir=storage_dir)  # written to disk here
        registry_store._COMMITTED_SCOPES.pop(scope.id)

        assert get_committed_scope(scope.id) is None  # no storage_dir passed this time


def test_a_rejected_scope_is_never_committed_to_disk():
    """The commit gate applies before commit-persistence, not just
    before the in-memory cache -- a scope with a real blocking error (a
    RoomType with no Rate, invariant #1) must never produce a *committed*
    file on disk, even when storage_dir is given.

    M6 Slice 3 correction: a rejected scope IS now saved as a draft
    (registry.save_draft_scope, a real, separate mechanism for a CLI
    review/correct loop) -- so this test is narrowed from "the directory
    is empty" to "no committed <scope_id>.json exists", which is what it
    actually verifies, and explicitly confirms the draft path separately
    rather than leaving that as an unstated assumption."""
    with tempfile.TemporaryDirectory() as storage_dir:
        room = RoomType(canonical_code="XX01", display_name="Test Room")
        scope = ContractScope(room_types=[room])

        result = commit_scope(scope, storage_dir=storage_dir)
        assert result.committed is False
        assert not os.path.exists(os.path.join(storage_dir, f"{scope.id}.json"))
        assert os.path.exists(os.path.join(storage_dir, "drafts", f"{scope.id}.json"))
