"""
M4 (next slice) — Alltours' page 1 "7. Special Reduction" section has one
more real, cleanly-OCR'd row: "Senior from 60 years reduction for
allrooms ... 10% | 10% | 10%" (Periods I/II/III), right above the
Longstay row already built.

Genuinely different shape from Longstay, and the reason this slice needed
more than adapter wiring. Longstay is a *booking-level* fact (nights) --
one StayLengthCondition check against the whole booking correctly decides
whether the discount applies to every adult uniformly. Senior is a
*per-guest* fact (age) -- AgeCondition's own matcher (_match_age) has
always used "any guest of this role/age" semantics, precisely because
_child_policy_lines already threads it per single guest for children.
Reusing _adult_lines' whole-booking override (built for Longstay) would
have been wrong here: if just one of two adults is a senior and the whole
party got discounted, the non-senior adult would be silently
undercharged. So this slice needed a genuine per-guest ADULT consumption
path in _adult_lines, structurally mirroring _child_policy_lines but for
adults -- not a Contract Model change (AgeCondition already supports
role=ADULT, documented since Foundation Hardening II), and not a new
abstraction, just the existing per-guest pattern applied to a role it
hadn't been exercised for yet.

Only identified adults (booking.context.guest_ages entries with
role=ADULT) can ever receive the discount -- every pre-existing booking
(no ADULT entries in guest_ages, since no adapter needed adult ages
before this slice) is completely unaffected, proven directly against
EXIM and Anex's existing tests.
"""

import os
from datetime import date

from contract_platform.contract_model.vocabulary import RuleKind, GuestType
from contract_platform.contract_model.entities import AgeCondition
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, GuestAge, price_booking, validate_booking,
)

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_dzp_scope_produces_four_real_senior_discount_rules():
    """One SUPPLEMENT rule per Season (2x Period I + Period II + Period
    III = 4), each gated by a real AgeCondition(role=ADULT, min_age=60,
    max_age=None), room_type_id=None (real 'for all rooms' scope),
    applies_to_pax_number=None (per-guest, not a numbered slot)."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    senior_rules = [
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT and r.applies_to_pax_number is None
        and r.applicability and isinstance(r.applicability[0], AgeCondition)
    ]
    assert len(senior_rules) == 4
    for rule in senior_rules:
        assert rule.room_type_id is None
        cond = rule.applicability[0]
        assert cond.role == GuestType.ADULT
        assert cond.min_age.value == 60
        assert cond.max_age is None


def test_senior_discount_rules_validate_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_a_booking_with_one_senior_adult_discounts_only_that_guest():
    """The real end-to-end proof, and the specific bug this slice exists
    to avoid: 2 adults, only one identified as a senior (age 65) -- must
    produce one line at the plain rate (the other, non-senior adult) and
    one line at the real 10%-reduced rate (66.00 * 0.9 = 59.40), never a
    flat discount applied to both."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
        adults=2, children=0, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.ADULT, age=65),
            GuestAge(role=GuestType.ADULT, age=45),
        ]),
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 2
    standard_line = next(l for l in invoice.lines if l.unit_rate == 66.00)
    senior_line = next(l for l in invoice.lines if l.unit_rate == 66.00 * 0.9)
    assert standard_line.quantity == 1
    assert senior_line.quantity == 1
    assert invoice.total == (66.00 * 7 * 1) + (66.00 * 0.9 * 7 * 1)


def test_a_booking_with_both_adults_senior_discounts_both():
    """Both identified as seniors -- both lines at the reduced rate, not
    just one."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
        adults=2, children=0, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.ADULT, age=61),
            GuestAge(role=GuestType.ADULT, age=70),
        ]),
    )
    invoice = price_booking(scope, booking)
    assert all(l.unit_rate == 66.00 * 0.9 for l in invoice.lines)
    assert invoice.total == 66.00 * 0.9 * 7 * 2


def test_a_booking_with_no_context_is_completely_unaffected():
    """No context at all (every pre-existing booking shape) -- must
    reproduce the plain rate exactly, proving the Senior Discount can
    never silently apply without an adapter/caller explicitly identifying
    a guest's age."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 66.00
    assert invoice.total == 66.00 * 7 * 2


def test_a_booking_with_an_under_60_adult_identified_is_unaffected():
    """An identified adult who doesn't meet the real 60-year floor must
    price at the plain rate, proving the AgeCondition genuinely gates the
    rule rather than always applying once any ADULT guest is identified."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    room = scope.room_types[0]
    booking = BookingRequest(
        room_type_id=room.id, check_in=date(2026, 5, 21), check_out=date(2026, 5, 28),
        adults=2, children=0, infants=0,
        context=BookingApplicabilityContext(guest_ages=[
            GuestAge(role=GuestType.ADULT, age=59),
            GuestAge(role=GuestType.ADULT, age=40),
        ]),
    )
    invoice = price_booking(scope, booking)
    assert all(l.unit_rate == 66.00 for l in invoice.lines)
