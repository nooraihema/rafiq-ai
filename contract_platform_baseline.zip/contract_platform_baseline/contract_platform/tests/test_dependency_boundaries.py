"""
This is the single most important test in the whole codebase, and the
direct implementation of the CTO synthesis point from the architecture
document: 'make the violation impossible to write, not just discouraged.'

It scans every .py file under specific packages and fails loudly if a
forbidden import appears - so a rule like 'pricing_engine must never
import semantic_adapters' is enforced automatically, not by remembering
to check during code review.

Written in pure standard library (no pytest) so it runs identically here
and on your machine, with or without pytest installed. If pytest is
available later, this file's test_* functions are still discoverable by it.
"""

import ast
import pathlib

PLATFORM_ROOT = pathlib.Path(__file__).resolve().parent.parent

FORBIDDEN_IMPORTS = {
    "contract_model": ["semantic_adapters", "document_parser", "pricing_engine", "orchestration", "cli", "api"],
    "expression_engine": ["semantic_adapters", "document_parser", "pricing_engine", "orchestration", "cli", "api"],
    "validation": ["semantic_adapters", "document_parser", "pricing_engine", "orchestration", "cli", "api"],
    "pricing_engine": ["semantic_adapters", "document_parser", "orchestration", "cli", "api"],
    "registry": ["semantic_adapters", "document_parser", "orchestration", "cli", "api"],
    "review_ui": ["semantic_adapters", "document_parser", "orchestration", "cli", "api"],
    "semantic_adapters": ["orchestration", "cli", "api"],
    "document_parser": ["orchestration", "cli", "api"],
}


def _imported_top_level_names(py_file: pathlib.Path) -> set:
    tree = ast.parse(py_file.read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                for part in node.module.split("."):
                    names.add(part)
    return names


def _check_package(package: str, forbidden: list) -> list:
    package_dir = PLATFORM_ROOT / package
    assert package_dir.exists(), f"expected package directory {package_dir} to exist"
    violations = []
    for py_file in package_dir.rglob("*.py"):
        imported = _imported_top_level_names(py_file)
        hit = imported.intersection(set(forbidden))
        if hit:
            violations.append(f"{py_file.relative_to(PLATFORM_ROOT)} imports forbidden package(s): {hit}")
    return violations


def test_no_forbidden_imports_anywhere():
    all_violations = []
    for package, forbidden in FORBIDDEN_IMPORTS.items():
        all_violations.extend(_check_package(package, forbidden))
    assert not all_violations, "Dependency boundary violated:\n" + "\n".join(all_violations)
