"""
M4 (next slice) — Alltours' page 3 "11. Cancellations by Customers /
Cancellation Fees" section has a real, three-tier customer cancellation
policy: free cancellation 7+ days before arrival (the implicit absence
of any penalty rule -- not built as its own entry), a 1-night fee for
cancellations "from 6 days before arrival until the day of arrival", and
a separate 3-night no-show charge. Maps onto CancellationRule, a
Contract Model type present since M0 (alongside PaymentRule) that no
adapter had ever built (confirmed by inspection before writing any code:
zero references anywhere in semantic_adapters/ or pricing_engine/).

Only the 6-day/1-night tier is built as a CancellationRule. The no-show
charge (3 nights) is real, equally clean data, but deliberately NOT
built as a CancellationRule -- a no-show is, by the contract's own
wording, a distinct thing from a cancellation (the customer never
canceled; they simply didn't arrive). Forcing it into
CancellationRule.deadline_days_before_arrival would misrepresent a real
distinction the source text itself makes, the same discipline already
applied to Anex's Single Supplement and Alltours' own 29-night Longstay
tier -- flagged, not guessed into a shape that doesn't fit.

This slice required reading a new page (page 3) for the first time --
the adapter previously only read page 1. The two-column OCR layout on
this page interleaves unrelated text between "the organizer" and "will
pay the equivalent of 1 night", so the real values are matched as two
independent regex fragments on the same page, not one pattern requiring
adjacency (see the adapter's own parse function for why).

No pricing_engine consumption: like PaymentRule, this is a policy fact
about a hypothetical future action (cancelling), not something
price_booking()/validate_booking() evaluate today -- there is no
"cancel a booking" operation anywhere in this pricing_engine to wire it
into. Proven by direct construction and Expression evaluation instead.
"""

import os

from contract_platform.contract_model.entities import CancellationRule
from contract_platform.contract_model.vocabulary import CalculationUnit
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


def test_scope_produces_one_real_cancellation_rule():
    """The real 6-day/1-night tier: exactly one CancellationRule,
    deadline_days_before_arrival == 6, scoped to the contract."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    assert len(scope.cancellation_rules) == 1
    rule = scope.cancellation_rules[0]
    assert rule.contract_scope_id == scope.id
    assert rule.deadline_days_before_arrival == 6

    ctx = EvaluationContext(rate_values={})
    assert evaluate(rule.penalty_calculation, ctx) == 1.0


def test_cancellation_rule_does_not_break_validation():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_penalty_calculation_is_expressed_in_nights_not_a_bare_currency_amount():
    """The real text says "the equivalent of 1 night", not a dollar
    figure -- the actual cost depends on whichever room/rate is booked,
    which the contract-wide cancellation clause doesn't reference. Must
    be a real Expression using CalculationUnit.NIGHTS, not an invented
    currency amount."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    rule = scope.cancellation_rules[0]
    assert rule.penalty_calculation.unit == CalculationUnit.NIGHTS
