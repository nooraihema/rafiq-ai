"""
M4 (next slice) — EXIM's page 6 "Turnover Guarantee Conditions" box has
4 real, identically-shaped, unambiguous lines: "The Tour Operator will
pay to the Supplier a deposit of <amount> USD at latest on <date>" --
confirmed by regex match against the real text before writing any
adapter code. Maps directly onto PaymentRule, a Contract Model type
present since M0 (alongside CancellationRule) that no adapter has ever
built (confirmed by inspection: zero references anywhere in
semantic_adapters/ or pricing_engine/).

Chosen over every other backlog item on cost/benefit: Alltours' 29-night
tier and Anex's Single Supplement/Min-node clause are blocked on real,
already-flagged ambiguities; Alltours' room codes are OCR-blocked;
CombinabilityRule has no adapter data. PaymentRule needed one new (but
simple and unambiguous) regex against clean native text, zero Contract
Model changes, and reuses PaymentTrigger.FIXED_DEADLINE -- an enum value
that already existed for exactly this shape (a deposit due by a fixed
calendar date, not tied to a booking's check-in/check-out).

No pricing_engine consumption: unlike every prior M4 slice, this is B2B
contract-financial metadata (a deposit schedule between the Tour
Operator and the Supplier), not a customer-booking-facing fact -- there
is no natural "booking-time check" for it, the same way there isn't one
for other unconsumed Restriction/metadata types already in the Model
(BlackoutPeriod, CombinabilityRule). Proven by direct construction and
Expression evaluation instead of an end-to-end booking test, the same
standard used for EXIM's very first SUPPLEMENT rule before booking-level
tests existed.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import PaymentRule
from contract_platform.contract_model.vocabulary import PaymentTrigger
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def test_scope_produces_four_real_deposit_payment_rules():
    """The real page-6 deposit schedule: 1,000,000 USD by 30.09.2025,
    then three 500,000 USD payments by 13.11.2025, 11.12.2025, and
    12.02.2026 -- must produce exactly 4 PaymentRule entries with those
    exact amounts and dates, each trigger=FIXED_DEADLINE, each scoped to
    this contract."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    assert len(scope.payment_rules) == 4
    for rule in scope.payment_rules:
        assert rule.contract_scope_id == scope.id
        assert rule.trigger == PaymentTrigger.FIXED_DEADLINE

    amounts_and_dates = sorted((r.deadline_date, r.amount_calculation) for r in scope.payment_rules)
    expected_dates = [date(2025, 9, 30), date(2025, 11, 13), date(2025, 12, 11), date(2026, 2, 12)]
    assert [d for d, _ in amounts_and_dates] == expected_dates

    ctx = EvaluationContext(rate_values={})
    amounts = [evaluate(expr, ctx) for _, expr in amounts_and_dates]
    assert amounts == [1_000_000.0, 500_000.0, 500_000.0, 500_000.0]


def test_deposit_payment_rules_do_not_break_validation():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_deposit_payments_are_not_duplicated_per_room():
    """The deposit schedule is printed once for the whole contract, not
    per room -- a multi-room scope must still produce exactly 4
    PaymentRule entries, not one set per room built."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01", "DR05", "SU02"])
    assert len(scope.payment_rules) == 4
