"""
M3 — Architectural validation: Alltours.

Per the M3 ground rules: prove the current architecture (Contract Model,
Pricing Engine, Expression Engine) can represent this contract by adding
only a new Semantic Adapter. This PDF is a scanned image with zero
embedded text (confirmed: every page returns 0 characters from native
pdfplumber extraction), which pushed the one legitimate extension made
here -- an OCR fallback inside document_parser itself, still zero business
knowledge, explicitly within that module's stated scope ("PDF/Excel/Word/
image"). contract_model, pricing_engine, and expression_engine are
untouched.

The numbers this test anchors on (DZP: 72.00 / 66.00 / 80.00 EUR for
Period I/II/III) were read directly off the source contract's Roomtype
table, row 1.
"""

import os
from datetime import date

from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext
from contract_platform.contract_model.expressions import RateRef
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Alltours_S26.pdf")


_CACHED_SCOPE = None


def _build_scope():
    global _CACHED_SCOPE
    if _CACHED_SCOPE is None:
        _CACHED_SCOPE = build_contract_scope(FIXTURE_PATH, room_codes=["DZP"])
    return _CACHED_SCOPE


def test_document_parser_ocr_fallback_actually_fired_for_this_scanned_pdf():
    """Structural proof this really is a scanned document exercising the
    new OCR path, not a lucky native-text extraction."""
    from contract_platform.document_parser.pdf_reader import read_pdf_pages
    pages = read_pdf_pages(FIXTURE_PATH, page_numbers=[1])
    assert all(p.extraction_method == "ocr:tesseract" for p in pages)


def test_alltours_adapter_produces_a_valid_contract_scope():
    scope = _build_scope()

    assert scope.hotel.name == "Amarina Jannah Resort"
    assert scope.tour_operator.name == "alltours flugreisen gmbh / byebye gmbh"
    assert scope.valid_from == date(2026, 5, 1)
    assert scope.valid_to == date(2026, 10, 31)
    assert scope.currency == "EUR"  # first real non-USD data point across all 3 adapters

    assert len(scope.room_types) == 1
    room = scope.room_types[0]
    assert room.canonical_code == "DZP"

    # Period I is genuinely split across two disjoint calendar ranges in
    # the source (low season on both ends of summer) -> 2 Season objects
    # sharing the "Period I" label, plus Period II and III = 4 total.
    assert len(scope.seasons) == 4
    assert len(scope.rates) == 4

    issues = validate(scope)
    assert not has_blocking_errors(issues), f"expected no blocking errors, got: {issues}"


def test_dzp_rates_match_the_real_scanned_contract_for_all_three_periods():
    """The specific numbers this milestone exists to prove -- read via OCR,
    not a native text layer, and still landing on the exact printed
    values."""
    scope = _build_scope()
    rates_by_period = {}
    for season in scope.seasons:
        rate = next(r for r in scope.rates if r.season_id == season.id)
        rates_by_period.setdefault(season.label.split(" (")[0], []).append(rate.amount.value)

    assert set(rates_by_period["Period I"]) == {72.00}   # both disjoint ranges share the same rate
    assert rates_by_period["Period II"] == [66.00]
    assert rates_by_period["Period III"] == [80.00]

    for season in scope.seasons:
        rate = next(r for r in scope.rates if r.season_id == season.id)
        assert rate.amount.confidence.value == "medium"  # OCR-sourced, per this adapter's confidence policy
        assert rate.currency == "EUR"


def test_occupancy_stack_is_flagged_low_confidence_not_invented():
    """The stacked min/max occupancy cell doesn't OCR reliably -- Part 5
    requires this become a flagged LOW-confidence value, never a guessed
    placeholder passed off as real."""
    scope = _build_scope()
    room = scope.room_types[0]
    assert len(room.valid_occupancies) == 1
    occ = room.valid_occupancies[0]
    assert occ.adults.confidence.value == "low"
    assert occ.children.confidence.value == "low"
    assert "did not OCR reliably" in occ.adults.source_note

    issues = validate(scope)
    codes = [i.code for i in issues]
    assert "LOW_CONFIDENCE_VALUE" in codes
    # LOW confidence is a WARNING, not a blocking ERROR -- the scope is a
    # legitimate draft, not silently treated as final.
    assert not has_blocking_errors(issues)


def test_pricing_engine_prices_a_real_alltours_booking_with_zero_code_changes():
    """The third consecutive TO priced by the exact same price_booking
    function, completely unmodified -- Contract Model, Pricing Engine, and
    Expression Engine all untouched by this milestone."""
    scope = _build_scope()
    room = scope.room_types[0]

    booking = BookingRequest(
        room_type_id=room.id,
        check_in=date(2026, 6, 1), check_out=date(2026, 6, 8),  # 7 nights, inside Period II
        adults=2, children=0, infants=0,
    )
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert invoice.lines[0].unit_rate == 66.00
    assert invoice.total == 66.00 * 7 * 2
    assert invoice.currency == "EUR"


def test_rate_evaluated_through_expression_engine_not_a_raw_float():
    scope = _build_scope()
    period_ii_rate = next(
        r for r in scope.rates
        if any(s.id == r.season_id and s.label.startswith("Period II ") for s in scope.seasons)
    )
    ctx = EvaluationContext(rate_values={period_ii_rate.id: period_ii_rate.amount.value})
    assert evaluate(RateRef(period_ii_rate.id), ctx) == 66.00


def test_contract_model_pricing_engine_expression_engine_were_not_touched_for_alltours():
    """Structural proof of the milestone's core claim: no Alltours-specific
    *parsing logic* anywhere in the three protected modules -- checking for
    the concrete artifacts an Alltours-specific leak would actually look
    like (its room codes, its known OCR misread, its regex patterns),
    not for the word "Alltours" appearing at all. Foundation Hardening II
    (post-M3) legitimately cites Alltours as one of four real-contract
    evidence sources in contract_model's comments, the same way it cites
    EXIM/Anex/TUI -- that's evidence-tracing documentation, not adapter
    logic leaking across the boundary, and is not what this test exists
    to catch."""
    import inspect
    from contract_platform.contract_model import entities, expressions
    from contract_platform.pricing_engine import calculator
    from contract_platform.expression_engine import evaluator

    # "promo room" deliberately excluded: it's not actually unique to
    # Alltours (Anex, EXIM, Rocket, and Odeon all use the same room name
    # in their own real data) -- it was a false-positive artifact, not a
    # genuine Alltours-specific leak, discovered when a legitimate
    # cross-contract evidence citation in calculator.py's docstring
    # (citing Anex's real "Promo Room") tripped this check.
    alltours_specific_artifacts = ["dzp", "ezp", "pzp", "grp.code"]
    for module in (entities, expressions, calculator, evaluator):
        source = inspect.getsource(module).lower()
        for artifact in alltours_specific_artifacts:
            assert artifact not in source, f"{artifact!r} leaked into {module.__name__}"
