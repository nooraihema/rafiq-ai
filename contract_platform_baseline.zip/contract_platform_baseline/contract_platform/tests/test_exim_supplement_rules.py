"""
M4, Slice 2 — first real non-CHILD_POLICY PricingRule (SUPPLEMENT),
positional pax assignment, and calculator.py rule-consumption
generalization.

Evidence-driven pivot from the original prediction: the plan was to
isolate M4 checkpoint 1 (generalize consumption beyond CHILD_POLICY)
from checkpoint 3 (guest-position assignment). Real data ruled that out:
checked both EXIM (AMR: "3A AmR pN"/"4A AmR pN") and Alltours ("for 3rd.
adult reduction") before choosing this slice, and every real
non-CHILD_POLICY rule available in a built adapter is positional -- there
is no position-independent SUPPLEMENT case in the actual data. Following
the evidence (as agreed), this slice does both together, scoped as
narrowly as the real data allows: adults only (no age-band matching,
unlike children), a single adapter (EXIM), no new adapter work.

PricingRule gained one new field, `applies_to_pax_number: Optional[int]`,
justified by two independent real TOs expressing the identical shape
(EXIM's AMR columns, Alltours' 3rd-adult reduction) -- the same evidence
bar Foundation Hardening II required before any Model addition.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import PricingRule
from contract_platform.contract_model.vocabulary import RuleKind
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import BookingRequest, price_booking, validate_booking

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def test_dr01_produces_a_real_supplement_rule_from_real_amr_data():
    """The specific real value this slice exists to prove: DR01's real
    '3A AmR pN' column (6.00) becomes a SUPPLEMENT PricingRule whose
    Expression, evaluated, gives the 3rd adult's correct reduced rate.

    M4 Slice 3 correction: DR01 now also produces CHILD_POLICY rules from
    its CHILD_PCT columns, so this asserts there is exactly one SUPPLEMENT
    rule specifically, not that it's the only PricingRule on the room."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    supplement_rules = [r for r in scope.pricing_rules if r.kind == RuleKind.SUPPLEMENT]
    assert len(supplement_rules) == 1
    rule = supplement_rules[0]
    assert rule.kind == RuleKind.SUPPLEMENT
    assert rule.applies_to_pax_number == 3
    assert rule.calculation.confidence.value == "high"

    from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext
    pppn_rate = next(r for r in scope.rates if r.basis.value == "per_person_per_night")
    ctx = EvaluationContext(rate_values={pppn_rate.id: pppn_rate.amount.value})
    assert evaluate(rule.calculation.value, ctx) == 40.00  # 46.00 - 6.00


def test_pricing_rule_with_applies_to_pax_number_validates_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_three_adult_booking_prices_the_third_adult_at_the_reduced_rate():
    """The real end-to-end proof: a 3-adult DR01 booking must produce two
    lines -- 2 adults at full PPPN, 1 adult at the SUPPLEMENT-adjusted
    rate -- not a flat unit_rate x 3."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=3, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues

    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 2
    standard_line, reduced_line = invoice.lines
    assert standard_line.unit_rate == 46.00 and standard_line.quantity == 2
    assert reduced_line.unit_rate == 40.00 and reduced_line.quantity == 1
    assert reduced_line.nights == 7
    assert invoice.total == (46.00 * 7 * 2) + (40.00 * 7 * 1)


def test_two_adult_booking_on_the_same_room_is_completely_unaffected():
    """Backward compatibility, proven directly: the same room that has a
    real 3rd-adult SUPPLEMENT rule must produce the exact pre-Slice-2
    single-line invoice for a 2-adult booking, since no pax slot 3 exists
    in that party."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert len(invoice.lines) == 1
    assert invoice.lines[0].unit_rate == 46.00
    assert invoice.total == 46.00 * 7 * 2


def test_room_with_no_matching_positional_rule_is_byte_identical_to_before_this_slice():
    """A party size with no matching positional rule must still produce a
    single adult-rate line -- proven against Anex's real '2 ADL+2CHD'
    combo, where only pax 3/4 have SUPPLEMENT rules (Triple/4th Adult
    Reduction, built post-Slice-4), so a 2-adult party is unaffected by
    either adapter's positional rules."""
    from contract_platform.semantic_adapters.anex.adapter import build_contract_scope as build_anex_scope
    anex_fixture = os.path.join(os.path.dirname(__file__), "fixtures", "Anex_S26.pdf")
    scope = build_anex_scope(anex_fixture)
    promo = scope.room_types[0]
    booking = BookingRequest(room_type_id=promo.id, check_in=date(2026, 5, 25), check_out=date(2026, 6, 1),
                              adults=2, children=2, infants=0)
    invoice = price_booking(scope, booking)
    adult_lines = [l for l in invoice.lines if "Child" not in l.description]
    assert len(adult_lines) == 1
    assert adult_lines[0].unit_rate == 62.00


def test_supplement_rule_is_scoped_to_its_own_room_not_leaking_to_others():
    """DR01's 3rd-adult SUPPLEMENT rule must not affect a different room
    in the same scope that has its own, differently-valued rule."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01", "DR05"])
    dr01 = next(r for r in scope.room_types if r.canonical_code == "DR01")
    dr05 = next(r for r in scope.room_types if r.canonical_code == "DR05")

    dr01_rule = next(r for r in scope.pricing_rules if r.room_type_id == dr01.id)
    dr05_rule = next(r for r in scope.pricing_rules if r.room_type_id == dr05.id)
    assert dr01_rule.id != dr05_rule.id

    booking_dr05 = BookingRequest(room_type_id=dr05.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                                   adults=3, children=0, infants=0)
    invoice = price_booking(scope, booking_dr05)
    reduced_line = invoice.lines[1]
    assert "DR01" not in reduced_line.description  # scoped correctly, no cross-room leakage


def test_pricing_rule_default_applies_to_pax_number_is_none():
    """Every rule built before this slice (Anex's CHILD_POLICY) has no
    positional meaning -- the new field's default must be None, not 0 or
    some other sentinel that could accidentally match a real pax slot."""
    rule = PricingRule()
    assert rule.applies_to_pax_number is None
