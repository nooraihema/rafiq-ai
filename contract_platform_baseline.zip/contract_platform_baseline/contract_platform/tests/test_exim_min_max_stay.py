"""
M4, Slice 4 — EXIM's Min/Max Stay clause (page 5: "01.05.26 31.10.26 All
3/999 ..."), parsed since M1 (MIN_MAX_STAY_RE existed, unused) but never
built into a real MinMaxStay Restriction or enforced at booking time.

Real data is contract-wide ("Min/Max Stay\nAll\n...", one row for the
whole contract, not per room) -- built as one Restriction with
applies_to_contract_scope_id, not room- or rate-scoped, matching invariant
#6's existing DANGLING_RESTRICTION_REFERENCE check and the MinMaxStay
type's own docstring ("EXIM's explicit '3/999 nights' min/max-stay
clause"). No Contract Model change: MinMaxStay and its validation
invariant (#7) have existed since M0.
"""

import os
from datetime import date

from contract_platform.contract_model.entities import MinMaxStay
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope
from contract_platform.validation.invariants import validate, has_blocking_errors
from contract_platform.pricing_engine.calculator import (
    BookingRequest, PricingError, price_booking, validate_booking,
)

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "Exim_S26.pdf")


def test_dr01_produces_a_real_min_max_stay_restriction():
    """The specific real value this slice exists to prove: page 5's
    '3/999' clause becomes a MinMaxStay Restriction, contract-scoped, HIGH
    confidence."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    min_max_restrictions = [r for r in scope.restrictions if isinstance(r, MinMaxStay)]
    assert len(min_max_restrictions) == 1
    restriction = min_max_restrictions[0]
    assert restriction.min_nights.value == 3
    assert restriction.max_nights.value == 999
    assert restriction.applies_to_contract_scope_id == scope.id
    assert restriction.min_nights.confidence.value == "high"


def test_restriction_validates_cleanly():
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    issues = validate(scope)
    assert not has_blocking_errors(issues), issues


def test_restriction_is_contract_scoped_not_duplicated_per_room():
    """The clause is printed once for the whole contract ('All'), not per
    room -- a multi-room scope must still produce exactly one
    MinMaxStay Restriction, not one per room built."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01", "DR05", "SU02"])
    min_max_restrictions = [r for r in scope.restrictions if isinstance(r, MinMaxStay)]
    assert len(min_max_restrictions) == 1


def test_booking_shorter_than_min_stay_is_rejected():
    """A 2-night booking is below the real 3-night minimum -- must fail
    booking-time validation and must not be priceable."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 3),
                              adults=2, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert any(i.code == "STAY_LENGTH_OUTSIDE_MIN_MAX_STAY" and i.severity.value == "error" for i in issues), issues

    try:
        price_booking(scope, booking)
        assert False, "expected PricingError for a stay below the contract minimum"
    except PricingError:
        pass


def test_booking_at_exactly_the_minimum_is_accepted():
    """3 nights is the real inclusive minimum -- must be accepted, not
    rejected by an off-by-one boundary error."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 4),
                              adults=2, children=0, infants=0)
    issues = validate_booking(scope, booking)
    assert not any(i.severity.value == "error" for i in issues), issues
    invoice = price_booking(scope, booking)
    assert invoice.total > 0


def test_normal_length_booking_is_unaffected():
    """A real 7-night booking (well within 3-999) must be unaffected --
    proven directly against the same booking Slice 2's tests already use,
    so this slice adds a check without changing existing pricing."""
    scope = build_contract_scope(FIXTURE_PATH, room_codes=["DR01"])
    room = scope.room_types[0]
    booking = BookingRequest(room_type_id=room.id, check_in=date(2026, 7, 1), check_out=date(2026, 7, 8),
                              adults=2, children=0, infants=0)
    invoice = price_booking(scope, booking)
    assert invoice.total == 46.00 * 7 * 2
