import sys
from contract_platform.cli import main

if __name__ == "__main__":
    sys.exit(main())
