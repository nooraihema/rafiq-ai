"""
The Universal Contract Model — the structural half of the ontology
(vocabulary.py is the controlled-term half). Together they are the only
vocabulary the Pricing Engine will ever need to understand.

Every field that holds a value an adapter extracted (rather than derived)
carries a ConfidenceLevel via Extracted[T], and — per Part 6 of the final
architecture — the provenance of exactly where in the source document it
came from. This is what lets the Validation layer decide, per-field,
whether something can be trusted automatically or must be routed to a
human via review_ui, and what lets review_ui point a reviewer straight
back at the original page/table/cell.

Nothing in this file may import from semantic_adapters, document_parser,
or pricing_engine. This file has no idea a PDF, or a Tour Operator, exists.

M0 changes from the Phase 1 draft (see roadmap Part 2 for the full
rationale on each):
  - Extracted is now generic (Extracted[T]) and carries Provenance.
  - AgeBand is demoted from an entity with its own id to a plain inlined
    value type — it has no independent identity or lifecycle.
  - Offer, Supplement, and ChildPolicyRule are merged into one entity,
    PricingRule, distinguished by RuleKind.
  - Restriction is now a sealed set of typed dataclasses instead of a
    dict-typed `detail` field.
  - ContractScope gained supersedes_contract_id, direct response to
    EXIM's own printed text about contract amendment.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from typing import Generic, Optional, TypeVar, Union
import uuid

from contract_platform.contract_model.vocabulary import (
    MealPlan, RateBasis, GuestType, PaymentTrigger, ConfidenceLevel, RuleKind,
)
from contract_platform.contract_model.expressions import Expression


def _new_id() -> str:
    return str(uuid.uuid4())


T = TypeVar("T")


@dataclass
class Provenance:
    """Exactly where in the source document a value came from. Every
    extracted value's confidence and its origin travel together, by
    construction (Part 6) — no separate lookup structure to keep in sync."""
    page_number: int
    table_index: Optional[int] = None
    row: Optional[int] = None
    column: Optional[int] = None
    raw_text: str = ""
    extraction_method: str = ""   # e.g. "pdfplumber.lattice_table", "regex.rate_pattern"


@dataclass
class Extracted(Generic[T]):
    """Wraps any value that came from an adapter's interpretation of a
    document, paired with how confident the adapter is in it. A value with
    LOW confidence is legal to exist in a *draft* Contract Model, but the
    Validation layer must never let one through to a persisted Model.

    M0: now generic and carries optional Provenance, applied to every
    adapter-populated field across the model (Rate amounts, Season dates,
    Occupancy counts, PricingRule calculations, Restriction values) —
    Phase 1 only wrapped Rate.amount, which was an inconsistency, not a
    decision."""
    value: T
    confidence: ConfidenceLevel
    provenance: Optional[Provenance] = None
    source_note: Optional[str] = None  # e.g. "matched pattern: 'X Room Rate + N% P.P IN DBL'"


@dataclass
class Hotel:
    id: str = field(default_factory=_new_id)
    name: str = ""
    location: str = ""
    official_rating: Optional[str] = None


@dataclass
class TourOperator:
    """Identity only. This class is used by semantic_adapters and registry.
    It must never be imported by pricing_engine or expression_engine."""
    id: str = field(default_factory=_new_id)
    name: str = ""


@dataclass
class Market:
    id: str = field(default_factory=_new_id)
    name: str = ""              # e.g. "Russia & CIS", "East European"
    countries: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class AgeBand:
    """A value type, not an entity (M0 — demoted per the Phase 1 critique).
    (min_age, max_age, label) inlined wherever needed. No id, no
    independent lifecycle — two AgeBands with the same bounds are simply
    equal, which is the correct semantics for a value type."""
    min_age: float = 0.0
    max_age: float = 0.0
    label: str = ""


@dataclass
class Occupancy:
    """One valid combination of guests for a RoomType — parsed from strings
    like '2 ADL+2CHD OR 03ADL+1CHD' into individual explicit combinations,
    never kept as the original free-text string past adapter time.

    M0: adults/children/infants are now Extracted[int] — each count is
    itself a value an adapter read off the page, with its own confidence
    and provenance, not an assumed-reliable integer."""
    id: str = field(default_factory=_new_id)
    adults: Extracted = None        # Extracted[int]
    children: Extracted = None      # Extracted[int]
    infants: Extracted = None       # Extracted[int]
    child_age_band: Optional[AgeBand] = None


@dataclass
class RoomType:
    id: str = field(default_factory=_new_id)
    hotel_id: str = ""
    canonical_code: str = ""       # e.g. "DBL_GARDEN_VIEW" — stable across TOs
    display_name: str = ""
    aliases: list[str] = field(default_factory=list)  # TO-specific names seen so far
    valid_occupancies: list[Occupancy] = field(default_factory=list)
    max_reduction_persons: Optional[int] = None


@dataclass
class Season:
    """M0: start_date/end_date are now Extracted[date] — a season boundary
    read off a contract is exactly the kind of value that can be
    low-confidence (smudged scan, ambiguous date format) and needs to
    carry provenance back to the source."""
    id: str = field(default_factory=_new_id)
    label: str = ""
    start_date: Extracted = None    # Extracted[date]
    end_date: Extracted = None      # Extracted[date]
    market_id: Optional[str] = None


@dataclass
class Rate:
    id: str = field(default_factory=_new_id)
    room_type_id: str = ""
    season_id: str = ""
    market_id: Optional[str] = None
    meal_plan: MealPlan = MealPlan.ALL_INCLUSIVE
    basis: RateBasis = RateBasis.PER_PERSON_PER_NIGHT
    amount: Extracted = None        # Extracted[float]
    currency: str = "USD"


@dataclass
class PricingRule:
    """M0: replaces Offer, Supplement, and ChildPolicyRule. Stripped of
    naming, all three were the same shape — 'a Calculation, scoped to a
    RoomType/Season, possibly time-boxed, possibly superseding another
    rule' — modeling the sequence of questions asked during design, not a
    real distinction the business domain makes. `kind` is what a caller
    switches on when it needs to know which of the three this is (e.g.
    review_ui grouping); the Pricing Engine itself treats every
    PricingRule identically regardless of kind. `kind` carries no
    precedence/ordering meaning of its own — see pricing_engine/
    composition.py, which is the one place ordering is decided, as an
    explicit, separate, swappable policy.

    room_type_id=None means hotel-wide (carried over from Offer).

    Foundation Hardening II: added `applicability` — see
    ApplicabilityCondition below. Whether a rule applies to a given
    booking is now a first-class, checkable property of the rule itself,
    separate from `calculation` (how much it's worth) and separate from
    composition (how it combines with other applicable rules).

    M4 Slice 2: added `applies_to_pax_number`. Evidence: both EXIM
    ("3A AmR pN"/"4A AmR pN" -- 3rd/4th Adult Amount Reduction) and
    Alltours ("for 3rd. adult reduction") independently express a
    real, common shape -- a per-night amount that applies specifically
    to a numbered guest slot within the party, not to the booking as a
    whole and not to any single guest's identity/age. Checked before
    adding: this is not an ApplicabilityCondition (it doesn't gate
    whether the rule applies to the *booking*; every booking with enough
    adults has a "3rd adult" slot) and not solvable in the adapter (the
    adapter can extract the number and the amount, but nothing in
    pricing_engine could assign it to the correct guest without this
    field). None = not a positional rule (every rule before this change,
    including Anex's CHILD_POLICY, which is unaffected)."""
    id: str = field(default_factory=_new_id)
    kind: RuleKind = RuleKind.SUPPLEMENT
    room_type_id: Optional[str] = None
    season_id: str = ""
    label: str = ""
    calculation: Extracted = None   # Extracted[Expression]
    issued_date: Optional[date] = None
    valid_from: Optional[date] = None
    valid_to: Optional[date] = None
    applies_to_pax_number: Optional[int] = None
    supersedes_rule_id: Optional[str] = None
    applicability: list = field(default_factory=list)  # list[ApplicabilityCondition]


# --- ApplicabilityCondition: sealed set of typed subtypes (Foundation --
# Hardening II, pre-M4) ------------------------------------------------
#
# Evidence: four independent real contracts (EXIM, Anex, Alltours, TUI)
# each attach a condition to when/whether a PricingRule's calculation
# applies, not just what it computes. Four condition *kinds* were
# actually observed with real or schema-confirmed data:
#   - stay length            (TUI Early Bird "1-365 nights"; Alltours Longstay)
#   - absolute booking date  (TUI Early Bird "24/07/2025 to 30/04/2026")
#   - days-before-arrival    (present as a distinct field in TUI's own
#                             schema, alongside the absolute-date field --
#                             blank in this particular contract, but real,
#                             confirmed vocabulary, not speculation)
#   - a guest-attribute age band (Anex/EXIM child bands; Alltours child
#                             bands AND a Senior-age condition -- unified
#                             under the existing GuestType enum rather
#                             than a separate "is this a child" flag,
#                             since a Senior check and a child-band check
#                             are the same shape of predicate over a
#                             guest's role and age)
#
# Deliberately NOT modeled here (see README "Foundation Hardening II" for
# the reasoning): child *position* (1st/2nd child), and charge-component
# scope (TUI's "Offer applies to: Room Rate/Board vs Board Supplements vs
# Gala..." checkboxes) -- the former only matters once pricing_engine
# disambiguates multiple children, the latter is a composition concern,
# not an applicability one. Neither has a real adapter need yet.
#
# Same discipline as Restriction: sealed typed dataclasses, the Python
# type is the discriminator, every value is Extracted[T]. Multiple
# conditions on one rule are AND'd -- no contract evidence has shown a
# need for OR-within-one-rule; a rule needing OR semantics is more
# honestly represented as two separate PricingRules sharing one
# `calculation`.

@dataclass
class StayLengthCondition:
    id: str = field(default_factory=_new_id)
    min_nights: Extracted = None    # Extracted[int]
    max_nights: Extracted = None    # Extracted[int]


@dataclass
class BookingDateCondition:
    id: str = field(default_factory=_new_id)
    from_date: Extracted = None     # Extracted[date]
    to_date: Extracted = None       # Extracted[date]


@dataclass
class DaysBeforeArrivalCondition:
    id: str = field(default_factory=_new_id)
    min_days: Extracted = None      # Extracted[int]
    max_days: Extracted = None      # Extracted[int]


@dataclass
class AgeCondition:
    """role uses the existing GuestType enum (ADULT/CHILD/INFANT) --
    a Senior-age condition (Alltours) is role=ADULT with a raised
    min_age; a child-band condition (Anex/EXIM/Alltours) is role=CHILD.
    No new vocabulary needed."""
    id: str = field(default_factory=_new_id)
    role: GuestType = GuestType.CHILD
    min_age: Extracted = None       # Extracted[float]
    max_age: Extracted = None       # Extracted[float]


ApplicabilityCondition = Union[StayLengthCondition, BookingDateCondition, DaysBeforeArrivalCondition, AgeCondition]


# --- Restriction: sealed set of typed subtypes (M0) ---------------------
#
# Phase 1 had Restriction.detail: dict — nothing validated its shape or
# contents. Each restriction kind is now its own dataclass with real,
# checked fields. The Python type itself is the discriminator; no parallel
# enum tag is needed (see vocabulary.py note).
#
# The three "applies_to_*" fields are structural foreign keys the adapter
# assigns, not extracted business content, so they stay plain Optional[str]
# rather than Extracted — invariant #6 checks they point at something real.

@dataclass
class BlackoutPeriod:
    id: str = field(default_factory=_new_id)
    applies_to_rule_id: Optional[str] = None
    applies_to_rate_id: Optional[str] = None
    applies_to_contract_scope_id: Optional[str] = None
    start_date: Extracted = None    # Extracted[date]
    end_date: Extracted = None      # Extracted[date]


@dataclass
class CombinabilityRule:
    id: str = field(default_factory=_new_id)
    applies_to_rule_id: Optional[str] = None
    applies_to_rate_id: Optional[str] = None
    applies_to_contract_scope_id: Optional[str] = None
    rule_ids: Extracted = None      # Extracted[list[str]]
    mode: Extracted = None          # Extracted[Literal["exclusive", "requires"]]


@dataclass
class ReleaseRule:
    id: str = field(default_factory=_new_id)
    applies_to_rule_id: Optional[str] = None
    applies_to_rate_id: Optional[str] = None
    applies_to_contract_scope_id: Optional[str] = None
    days_before_arrival: Extracted = None   # Extracted[int]


@dataclass
class MinMaxStay:
    """EXIM's explicit '3/999 nights' min/max-stay clause — technically
    representable before only as untyped dict keys nothing validated; now
    a real, checked type (see invariant #7: min_nights <= max_nights)."""
    id: str = field(default_factory=_new_id)
    applies_to_rule_id: Optional[str] = None
    applies_to_rate_id: Optional[str] = None
    applies_to_contract_scope_id: Optional[str] = None
    min_nights: Extracted = None    # Extracted[int]
    max_nights: Extracted = None    # Extracted[int]


Restriction = Union[BlackoutPeriod, CombinabilityRule, ReleaseRule, MinMaxStay]


@dataclass
class CancellationRule:
    id: str = field(default_factory=_new_id)
    contract_scope_id: str = ""
    description: str = ""
    deadline_days_before_arrival: Optional[int] = None
    penalty_calculation: Optional[Expression] = None


@dataclass
class PaymentRule:
    id: str = field(default_factory=_new_id)
    contract_scope_id: str = ""
    trigger: PaymentTrigger = PaymentTrigger.BEFORE_CHECKOUT
    description: str = ""
    amount_calculation: Optional[Expression] = None
    deadline_date: Optional[date] = None


@dataclass
class ContractScope:
    """The root container for one contract. This is what an adapter
    ultimately produces, and what validation, expression_engine, and
    pricing_engine all consume.

    M0: supersedes_contract_id added — direct response to EXIM's own
    printed text, "This contract supersedes any previous versions of this
    contract reference." supplements/offers/child_policy_rules collapsed
    into the single pricing_rules list."""
    id: str = field(default_factory=_new_id)
    schema_version: str = "1.0.0"
    hotel: Hotel = None
    tour_operator: TourOperator = None
    valid_from: date = None
    valid_to: date = None
    currency: str = "USD"
    supersedes_contract_id: Optional[str] = None
    markets: list[Market] = field(default_factory=list)
    seasons: list[Season] = field(default_factory=list)
    room_types: list[RoomType] = field(default_factory=list)
    rates: list[Rate] = field(default_factory=list)
    pricing_rules: list[PricingRule] = field(default_factory=list)
    restrictions: list[Restriction] = field(default_factory=list)
    cancellation_rules: list[CancellationRule] = field(default_factory=list)
    payment_rules: list[PaymentRule] = field(default_factory=list)


# --- Generic traversal helper --------------------------------------------
#
# Both validation (LOW-confidence check) and confidence reporting need to
# walk every Extracted[T] field in a scope. One traversal function here
# avoids two independent, drifting copies of "where do Extracted values
# live in this model."

def iter_extracted(scope: ContractScope):
    """Yields (entity_id, field_name, Extracted) for every populated
    Extracted[T] field anywhere in the scope."""
    for season in scope.seasons:
        if season.start_date is not None:
            yield season.id, "start_date", season.start_date
        if season.end_date is not None:
            yield season.id, "end_date", season.end_date

    for room in scope.room_types:
        for occ in room.valid_occupancies:
            if occ.adults is not None:
                yield occ.id, "adults", occ.adults
            if occ.children is not None:
                yield occ.id, "children", occ.children
            if occ.infants is not None:
                yield occ.id, "infants", occ.infants

    for rate in scope.rates:
        if rate.amount is not None:
            yield rate.id, "amount", rate.amount

    for rule in scope.pricing_rules:
        if rule.calculation is not None:
            yield rule.id, "calculation", rule.calculation
        for condition in rule.applicability:
            if isinstance(condition, StayLengthCondition):
                if condition.min_nights is not None:
                    yield condition.id, "min_nights", condition.min_nights
                if condition.max_nights is not None:
                    yield condition.id, "max_nights", condition.max_nights
            elif isinstance(condition, BookingDateCondition):
                if condition.from_date is not None:
                    yield condition.id, "from_date", condition.from_date
                if condition.to_date is not None:
                    yield condition.id, "to_date", condition.to_date
            elif isinstance(condition, DaysBeforeArrivalCondition):
                if condition.min_days is not None:
                    yield condition.id, "min_days", condition.min_days
                if condition.max_days is not None:
                    yield condition.id, "max_days", condition.max_days
            elif isinstance(condition, AgeCondition):
                if condition.min_age is not None:
                    yield condition.id, "min_age", condition.min_age
                if condition.max_age is not None:
                    yield condition.id, "max_age", condition.max_age

    for restriction in scope.restrictions:
        if isinstance(restriction, BlackoutPeriod):
            if restriction.start_date is not None:
                yield restriction.id, "start_date", restriction.start_date
            if restriction.end_date is not None:
                yield restriction.id, "end_date", restriction.end_date
        elif isinstance(restriction, CombinabilityRule):
            if restriction.rule_ids is not None:
                yield restriction.id, "rule_ids", restriction.rule_ids
            if restriction.mode is not None:
                yield restriction.id, "mode", restriction.mode
        elif isinstance(restriction, ReleaseRule):
            if restriction.days_before_arrival is not None:
                yield restriction.id, "days_before_arrival", restriction.days_before_arrival
        elif isinstance(restriction, MinMaxStay):
            if restriction.min_nights is not None:
                yield restriction.id, "min_nights", restriction.min_nights
            if restriction.max_nights is not None:
                yield restriction.id, "max_nights", restriction.max_nights


def iter_low_confidence(scope: ContractScope):
    """The subset of iter_extracted() whose confidence is LOW -- the
    single shared definition of "which fields need review".

    Found by inspection, not assumed: this exact filter (iter_extracted()
    plus a confidence == LOW check) was independently written three
    times -- validation.confidence.assess() (counting), registry.store.
    commit_scope() (the commit gate's rejection decision), and
    review_ui.corrections.list_review_items() (what a human sees to
    correct). Three copies of the same decision logic is exactly the
    "two independent, drifting copies" risk iter_extracted's own
    docstring already warns about for "where do Extracted values live"
    -- here it's "what counts as needing review" instead, but the same
    risk: change the definition in one place (e.g. a future severity
    tier) and the other copies silently keep the old behavior. Consumers
    needing only a yes/no answer (not the field list) should still
    prefer validation.confidence.assess(scope).needs_review for that
    specific question -- this generator is for callers that need the
    actual fields, the same shape iter_extracted() already returns."""
    for entity_id, field_name, extracted in iter_extracted(scope):
        if extracted.confidence == ConfidenceLevel.LOW:
            yield entity_id, field_name, extracted
