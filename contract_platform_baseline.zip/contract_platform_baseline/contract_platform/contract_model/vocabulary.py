"""
The controlled vocabulary — the closed set of terms every Semantic Adapter
must translate a Tour Operator's language into.

This is the "ontology" in concrete form: not a separate schema to keep in
sync with entities.py, but the single source of truth for every closed
category the domain uses. If a concept needs a fixed set of allowed values,
it lives here as an Enum — never as a free string scattered across adapters.

An adapter is allowed to know that EXIM's "1C2A" means
RestrictionScope.CHILD_WITH_TWO_ADULTS. Nothing outside the adapter's own
vocabulary.py should ever need to know that "1C2A" exists.

M0 note: RestrictionType (a plain enum tag) has been removed. Restriction is
now a sealed set of typed dataclasses (see entities.py) — the Python type
itself is the discriminator, so a parallel enum would be a second, redundant
source of truth for the same distinction.
"""

from enum import Enum


class MealPlan(str, Enum):
    ROOM_ONLY = "room_only"
    BED_AND_BREAKFAST = "bed_and_breakfast"
    HALF_BOARD = "half_board"
    FULL_BOARD = "full_board"
    ALL_INCLUSIVE = "all_inclusive"


class RateBasis(str, Enum):
    """How a Rate's number should be interpreted."""
    PER_PERSON_PER_NIGHT = "per_person_per_night"
    SINGLE_OCCUPANCY_PER_NIGHT = "single_occupancy_per_night"
    PER_UNIT_PER_NIGHT = "per_unit_per_night"
    PER_UNIT_TOTAL = "per_unit_total"


class GuestType(str, Enum):
    ADULT = "adult"
    CHILD = "child"
    INFANT = "infant"


class CalculationUnit(str, Enum):
    """Every Constant in an Expression must declare its unit explicitly.
    A bare number with no unit is not allowed in this system — this is
    deliberate, and exists specifically to prevent the class of bug where
    a percentage gets treated as a flat amount or vice versa."""
    USD = "usd"
    EUR = "eur"
    EGP = "egp"
    PERCENT = "percent"
    NIGHTS = "nights"
    COUNT = "count"


class RoundMode(str, Enum):
    """Explicit rounding behavior for the Round expression node — never
    implicit. Closes the silent-rounding gap identified in the Phase 1
    critique."""
    NEAREST = "nearest"
    UP = "up"
    DOWN = "down"


class PaymentTrigger(str, Enum):
    BEFORE_CHECKOUT = "before_checkout"
    BEFORE_CHECKIN = "before_checkin"
    FIXED_DEADLINE = "fixed_deadline"
    ON_INVOICE = "on_invoice"


class RuleKind(str, Enum):
    """Distinguishes what a PricingRule represents, now that Offer,
    Supplement, and ChildPolicyRule have been merged into one entity
    (Phase 1 critique: the three-way split modeled the sequence of
    questions asked during design, not a real business distinction)."""
    CHILD_POLICY = "child_policy"
    SUPPLEMENT = "supplement"
    SPO_OFFER = "spo_offer"


class ConfidenceLevel(str, Enum):
    """Attached by adapters to every value they populate. Drives whether the
    Validation layer accepts a value automatically or routes it to review_ui."""
    HIGH = "high"        # e.g. read directly from a clean numeric table cell
    MEDIUM = "medium"     # e.g. matched against a known text pattern
    LOW = "low"           # e.g. best-effort guess, must be human-confirmed
