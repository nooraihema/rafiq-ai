"""
ContractScope <-> JSON, round-trip.

Part 7 of the original architecture ("the persistence layer"), referenced
but explicitly deferred throughout the codebase until now: invariants.py's
check_no_circular_supersession already anticipated "ContractScope objects
are in-memory/JSON"; registry/store.py's docstring named exactly this gap
("no serialization yet -- there is nothing to persist to a durable form
until something has decided what's committable"); ContractScope.
schema_version has carried a version string since M0 for exactly this
purpose. This module is the first thing that actually writes/reads that
JSON form.

Design: every encoded object is self-describing -- a JSON object with its
own "__type__" tag (the Python class name) -- rather than driven by
static field-type hints. Two reasons, both concrete: (1) entities.py uses
`from __future__ import annotations`, so dataclasses.fields()'s .type
values are unresolved strings, not type objects -- correctly resolving
every Union/Optional/Generic shape from those strings is real, avoidable
complexity; (2) a self-describing scheme means decoding never has to
guess or pre-know a field's expected type, the same "never silently
guess" discipline Part 5 already applies to adapter extraction, just
extended to this boundary. An unrecognized "__type__" tag is a loud,
immediate SerializationError, never a silent best-effort reconstruction.

dataclasses.fields() (reflection) drives the mechanical encode/decode of
every dataclass, rather than a hand-enumerated field list per class, the
way entities.iter_extracted() deliberately does. This is not a departure
from that file's house style: iter_extracted is a *filtering* walk making
a business judgment call (which fields matter for confidence review) --
explicitness matters there because a human is choosing what's meaningful.
This is a *preserving* walk with no judgment call to make (every field
must survive the round trip, always, regardless of what it means) --
reflection is the correct tool for "preserve everything, decide nothing".
The two registries this module does define explicitly (dataclass name ->
class, enum name -> class) are the same style of typed dispatch table
applicability.py's register_condition already uses.

Deliberately out of scope: writing to an actual file or database (the
in-memory registry from M5 Slice 1 is untouched by this module --
wiring serialize_scope/deserialize_scope into a durable store is a
separate, later slice, once evidence shows what that store should be);
cross-contract cycle detection for supersedes_contract_id (invariants.py
already named this as needing "other contracts loaded", explicitly
deferred, not attempted here either); schema migration across
schema_version values (schema_version is preserved faithfully through
the round trip, but no migration logic exists yet -- there is only one
real schema version in use by any adapter so far, so nothing forces that
design yet).
"""

from __future__ import annotations
import dataclasses
import json
from datetime import date
from enum import Enum

from contract_platform.contract_model import entities as _entities
from contract_platform.contract_model import expressions as _expressions
from contract_platform.contract_model import vocabulary as _vocabulary
from contract_platform.contract_model.entities import ContractScope


class SerializationError(Exception):
    """Raised on anything this module can't confidently encode or decode
    -- an unrecognized __type__ tag, an un-encodable value, or malformed
    JSON. Never silently guessed past."""


# Every dataclass this module knows how to round-trip, by class name.
# Explicit, not derived by scanning modules for "every dataclass defined
# here" -- the same discipline applicability.py's register_condition
# registry follows: what this module supports is a visible, auditable
# list, not implicit.
_DATACLASS_REGISTRY = {
    cls.__name__: cls
    for cls in [
        _entities.Provenance, _entities.Extracted, _entities.Hotel, _entities.TourOperator,
        _entities.Market, _entities.AgeBand, _entities.Occupancy, _entities.RoomType,
        _entities.Season, _entities.Rate, _entities.PricingRule,
        _entities.StayLengthCondition, _entities.BookingDateCondition,
        _entities.DaysBeforeArrivalCondition, _entities.AgeCondition,
        _entities.BlackoutPeriod, _entities.CombinabilityRule, _entities.ReleaseRule,
        _entities.MinMaxStay, _entities.CancellationRule, _entities.PaymentRule,
        _entities.ContractScope,
        _expressions.Constant, _expressions.RateRef, _expressions.Add, _expressions.Subtract,
        _expressions.Multiply, _expressions.PercentOf, _expressions.Conditional,
        _expressions.Compare, _expressions.Lookup, _expressions.Min, _expressions.Max,
        _expressions.Round,
    ]
}

_ENUM_REGISTRY = {
    cls.__name__: cls
    for cls in [
        _vocabulary.MealPlan, _vocabulary.RateBasis, _vocabulary.GuestType,
        _vocabulary.CalculationUnit, _vocabulary.RoundMode, _vocabulary.PaymentTrigger,
        _vocabulary.RuleKind, _vocabulary.ConfidenceLevel,
    ]
}

_DATE_TAG = "date"
_ENUM_TAG_PREFIX = "enum:"


def _encode(value):
    if value is None:
        return None
    if isinstance(value, Enum):  # checked before str/int, since str-Enum members are also str instances
        return {"__type__": f"{_ENUM_TAG_PREFIX}{type(value).__name__}", "value": value.value}
    if isinstance(value, date):
        return {"__type__": _DATE_TAG, "iso": value.isoformat()}
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_encode(item) for item in value]
    if dataclasses.is_dataclass(value):
        type_name = type(value).__name__
        if type_name not in _DATACLASS_REGISTRY:
            raise SerializationError(
                f"No serializer registered for dataclass {type_name!r} -- "
                f"add it to _DATACLASS_REGISTRY in contract_model/serialization.py."
            )
        return {
            "__type__": type_name,
            **{f.name: _encode(getattr(value, f.name)) for f in dataclasses.fields(value)},
        }
    raise SerializationError(f"Don't know how to serialize a value of type {type(value).__name__!r}: {value!r}")


def _decode(data):
    if data is None:
        return None
    if isinstance(data, list):
        return [_decode(item) for item in data]
    if isinstance(data, (str, int, float, bool)):
        return data
    if isinstance(data, dict):
        tag = data.get("__type__")
        if tag is None:
            raise SerializationError(f"Encoded object is missing its __type__ tag: {data!r}")
        if tag == _DATE_TAG:
            return date.fromisoformat(data["iso"])
        if tag.startswith(_ENUM_TAG_PREFIX):
            enum_name = tag[len(_ENUM_TAG_PREFIX):]
            if enum_name not in _ENUM_REGISTRY:
                raise SerializationError(f"Unrecognized enum type tag {enum_name!r}.")
            return _ENUM_REGISTRY[enum_name](data["value"])
        if tag not in _DATACLASS_REGISTRY:
            raise SerializationError(
                f"Unrecognized type tag {tag!r} -- refusing to guess what this was. "
                f"Known types: {sorted(_DATACLASS_REGISTRY)}."
            )
        cls = _DATACLASS_REGISTRY[tag]
        kwargs = {key: _decode(val) for key, val in data.items() if key != "__type__"}
        try:
            return cls(**kwargs)
        except TypeError as e:
            raise SerializationError(f"Could not reconstruct {tag} from decoded fields {sorted(kwargs)}: {e}")
    raise SerializationError(f"Don't know how to decode a JSON value of type {type(data).__name__!r}: {data!r}")


def serialize_scope(scope: ContractScope) -> str:
    """Encodes a ContractScope (and everything it transitively contains)
    to a JSON string. Every nested object is self-describing (its own
    "__type__" tag), so deserialize_scope never has to guess a field's
    expected type."""
    return json.dumps(_encode(scope), indent=2)


def deserialize_scope(raw: str) -> ContractScope:
    """The inverse of serialize_scope. Raises SerializationError on any
    unrecognized type tag or malformed structure -- never silently
    reconstructs the wrong thing."""
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise SerializationError(f"Not valid JSON: {e}")
    result = _decode(data)
    if not isinstance(result, ContractScope):
        raise SerializationError(f"Decoded a {type(result).__name__}, not a ContractScope.")
    return result
