"""
Explicit schema versioning — Invariant #5 from the architecture document.

A ContractScope extracted this year and one extracted after the schema has
evolved must both remain loadable and distinguishable. This module is
intentionally tiny: it exists so there is exactly one place that defines
"what version is current," rather than that knowledge being implicit or
scattered.
"""

CURRENT_SCHEMA_VERSION = "1.0.0"

# History of what changed at each version — append, never rewrite past entries.
# Still draft ("1.0.0") until M3's formal stop-and-confirm gate officially
# tags it stable, per roadmap Part 8. The M0 entry documents the shape
# change within the same draft version rather than bumping early.
CHANGELOG = {
    "1.0.0": (
        "Initial draft Universal Contract Model — Phase 1 foundation. "
        "M0 (Foundation Hardening) applied on top of this: Extracted[T] made "
        "generic with Provenance and applied to Season dates, Occupancy "
        "counts, and PricingRule calculations; AgeBand demoted to a value "
        "type; Offer/Supplement/ChildPolicyRule merged into PricingRule "
        "(RuleKind); Restriction converted from dict-typed detail to sealed "
        "typed subclasses (BlackoutPeriod, CombinabilityRule, ReleaseRule, "
        "MinMaxStay); ContractScope gained supersedes_contract_id; "
        "Min/Max/Round added to the Expression AST; evaluate() converted to "
        "registry dispatch. "
        "Foundation Hardening II (pre-M4, after EXIM/Anex/Alltours/TUI): "
        "PricingRule gained `applicability: list[ApplicabilityCondition]` — "
        "a new sealed typed union (StayLengthCondition, BookingDateCondition, "
        "DaysBeforeArrivalCondition, AgeCondition), same pattern as "
        "Restriction. Invariant #8 added (applicability range consistency). "
        "No changes to Expression, expression_engine, or any adapter's "
        "document_parser usage."
    ),
}
