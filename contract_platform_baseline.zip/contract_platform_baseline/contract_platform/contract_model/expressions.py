"""
The Expression AST — Phase 3 of the architecture discussion, now as real code.

Every calculation rule in the system, regardless of which Tour Operator it
came from or whether the source gave a number or a sentence, becomes one of
these node types. There is no other way for business logic to enter the
Contract Model — a raw string is only ever a *draft* value before an adapter
finishes translating it into one of these trees.

Design constraint: this module must never import anything from
semantic_adapters. It has no idea EXIM or Anex exist, and it never will.

M0 additions: Min, Max, Round — see architecture Part 3. Adding a new node
type here plus a matching @register_node function in expression_engine is
the entire extension story; evaluate() itself never needs to change.
"""

from __future__ import annotations
from dataclasses import dataclass
from contract_platform.contract_model.vocabulary import CalculationUnit, RoundMode


class Expression:
    """Base marker class. Every node type below is an Expression."""
    pass


@dataclass(frozen=True)
class Constant(Expression):
    """A literal number with an explicit, mandatory unit.
    Constant(50, CalculationUnit.PERCENT) — never a bare 50."""
    value: float
    unit: CalculationUnit


@dataclass(frozen=True)
class RateRef(Expression):
    """A reference to a specific Rate object elsewhere in the Contract Model,
    resolved at evaluation time against a booking context — never a copied
    number, so the two always stay consistent if the base Rate changes."""
    rate_id: str


@dataclass(frozen=True)
class Add(Expression):
    left: Expression
    right: Expression


@dataclass(frozen=True)
class Subtract(Expression):
    left: Expression
    right: Expression


@dataclass(frozen=True)
class Multiply(Expression):
    left: Expression
    right: Expression


@dataclass(frozen=True)
class PercentOf(Expression):
    """base * (pct / 100). Kept as its own node — rather than forcing every
    adapter to hand-build Multiply(base, Divide(pct, 100)) — because
    percentage-of-a-rate is by far the most common calculation shape we've
    seen in real contracts (both EXIM's numeric columns and Anex's prose
    formulas reduce to this)."""
    base: Expression
    percent: Constant


@dataclass(frozen=True)
class Conditional(Expression):
    """if condition then if_true else if_false.
    condition is itself an Expression that must evaluate to a boolean —
    see Compare below. Exists for rules like Anex's
    'if Single+2Child rate exceeds Double rate, use Double rate'."""
    condition: "Compare"
    if_true: Expression
    if_false: Expression


@dataclass(frozen=True)
class Compare(Expression):
    """left <op> right, where op is one of: '>', '<', '>=', '<=', '==' """
    left: Expression
    op: str
    right: Expression

    def __post_init__(self):
        allowed = (">", "<", ">=", "<=", "==")
        if self.op not in allowed:
            raise ValueError(f"Compare.op must be one of {allowed}, got {self.op!r}")


@dataclass(frozen=True)
class Lookup(Expression):
    """Looks up a value from a keyed table by evaluating key_expr against a
    booking context — used for age-band or occupancy-indexed values where
    the exact rate depends on which bracket a guest falls into."""
    table_ref: str
    key_expr: Expression


@dataclass(frozen=True)
class Min(Expression):
    """Direct response to the recurring real clause pattern 'IN CASE SINGLE
    + 2 CHILD RATE IS MORE THAN DOUBLE, DOUBLE RATE WILL BE APPLIED' — seen
    in two different forms already. Previously representable only as nested
    Conditional+Compare; common enough to deserve its own node."""
    left: Expression
    right: Expression


@dataclass(frozen=True)
class Max(Expression):
    left: Expression
    right: Expression


@dataclass(frozen=True)
class Round(Expression):
    """Closes the silent rounding gap identified in the Phase 1 critique.
    mode is an explicit RoundMode, never implicit float truncation."""
    expr: Expression
    mode: RoundMode
