"""
The HTTP API — the second transport over orchestration.py's shared
business logic (the first is cli.py). Built with Flask (already present
in this environment; no new dependency was added to make this decision).

Chosen as this project's next major milestone after a full re-assessment,
not because a slice mechanically pointed here. The concrete case: every
capability this project has built -- extraction, the commit gate, the
review loop, persistence, pricing -- was reachable only from a terminal
one operator controls directly. orchestration.py's functions were
already pure, transport-agnostic, and fully tested well before this
decision (a deliberate design choice from the CLI slices, not a
coincidence) -- which is exactly the concrete evidence that adding a
second transport was a natural, low-risk extension of the existing
architecture, not a speculative rewrite.

Every route here is thin: parse the request, call the same orchestration
function the CLI calls, shape the result into JSON. No business logic
lives here, the same "transport only" discipline cli.py has followed
since M6. HTTP status codes: 200 for any request that was well-formed
and fully processed, regardless of the business outcome (committed vs.
rejected, valid vs. invalid -- both are normal, expected outcomes, the
same way the CLI's own exit codes distinguish "ran successfully, here's
the result" from "the request itself couldn't be understood"); 404 when
a referenced scope/draft genuinely doesn't exist; 400 for any other
malformed request (bad adapter name, bad date format, a missing
required field).

Uses Flask's application-factory pattern (create_app()) rather than a
module-level app instance -- the standard, testable Flask convention,
and the only shape that lets api/tests import a fresh app per test
without global state leaking between them.

Authentication: every route requires a static API key sent as the
`X-API-Key` header, checked in a single `before_request` hook -- no
per-route duplication. The key is either passed explicitly to
create_app(api_key=...) (used by tests) or read from the
CONTRACT_PLATFORM_API_KEY environment variable in real deployment. If
neither is set, the app refuses to serve *any* request (503) rather than
silently running unprotected -- an unauthenticated contract-pricing API
is exactly the kind of thing that must fail closed, not open.
"""

from __future__ import annotations
import os
from datetime import date

from flask import Flask, request, jsonify

API_KEY_ENV_VAR = "CONTRACT_PLATFORM_API_KEY"
DATA_DIR_ENV_VAR = "CONTRACT_PLATFORM_DATA_DIR"
UPLOAD_DIR_ENV_VAR = "CONTRACT_PLATFORM_UPLOAD_DIR"


def _resolves_inside(base: str, candidate: str) -> bool:
    """True iff candidate's real path is base itself or somewhere under it.

    Blocks path traversal (`../../etc/passwd`) and absolute paths outside
    base, including via symlinks (realpath resolves both).
    """
    base_real = os.path.realpath(base)
    candidate_real = os.path.realpath(candidate)
    return candidate_real == base_real or candidate_real.startswith(base_real + os.sep)

from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.registry.store import list_committed_scope_ids
from contract_platform.orchestration import (
    run_ingest, run_review, run_correct, run_describe, run_price, KNOWN_ADAPTERS,
)


def _review_item_to_dict(item) -> dict:
    return {
        "entity_id": item.entity_id,
        "field_name": item.field_name,
        "current_value": item.current_value,
        "confidence": item.confidence.value,
        "source_note": item.source_note,
    }


def _ingest_result_to_dict(result) -> dict:
    return {
        "scope_id": result.scope_id,
        "committed": result.committed,
        "room_type_count": result.room_type_count,
        "rate_count": result.rate_count,
        "pricing_rule_count": result.pricing_rule_count,
        "validation_issue_count": result.validation_issue_count,
        "review_items": [_review_item_to_dict(i) for i in result.review_items],
    }


def _correct_result_to_dict(result) -> dict:
    return {
        "scope_id": result.scope_id,
        "applied": result.applied,
        "committed": result.committed,
        "remaining_review_items": [_review_item_to_dict(i) for i in result.remaining_review_items],
    }


def _room_type_summary_to_dict(rt) -> dict:
    return {
        "room_type_id": rt.room_type_id,
        "canonical_code": rt.canonical_code,
        "display_name": rt.display_name,
        "valid_occupancy_count": rt.valid_occupancy_count,
    }


def _validation_issue_to_dict(issue) -> dict:
    return {
        "severity": issue.severity.value,
        "code": issue.code,
        "message": issue.message,
        "entity_id": issue.entity_id,
    }


def _invoice_to_dict(invoice) -> dict:
    return {
        "room_type_id": invoice.room_type_id,
        "total": invoice.total,
        "currency": invoice.currency,
        "lines": [
            {
                "description": line.description, "rate_id": line.rate_id, "unit_rate": line.unit_rate,
                "nights": line.nights, "quantity": line.quantity, "line_total": line.line_total,
                "currency": line.currency,
            }
            for line in invoice.lines
        ],
    }


def _price_result_to_dict(result) -> dict:
    return {
        "scope_id": result.scope_id,
        "room_type_id": result.room_type_id,
        "valid": result.valid,
        "validation_issues": [_validation_issue_to_dict(i) for i in result.validation_issues],
        "invoice": _invoice_to_dict(result.invoice) if result.invoice is not None else None,
    }


def create_app(api_key: str | None = None, data_dir: str | None = None, upload_dir: str | None = None) -> Flask:
    app = Flask(__name__)
    configured_key = api_key if api_key is not None else os.environ.get(API_KEY_ENV_VAR)
    configured_data_dir = data_dir if data_dir is not None else os.environ.get(DATA_DIR_ENV_VAR)
    configured_upload_dir = upload_dir if upload_dir is not None else os.environ.get(UPLOAD_DIR_ENV_VAR)

    @app.before_request
    def _require_api_key():
        # The browser UI's own HTML page must load without a key -- the
        # key is only known client-side, entered into the page itself,
        # and attached to every *API* call the page's JS then makes.
        # Every /scopes* route still goes through the check below.
        if request.path == "/" or request.path.startswith("/static/"):
            return
        if configured_key is None:
            return jsonify({"error": "server misconfigured: no API key set"}), 503
        if request.headers.get("X-API-Key") != configured_key:
            return jsonify({"error": "unauthorized"}), 401

    @app.get("/")
    def ui():
        return app.send_static_file("index.html")

    @app.errorhandler(404)
    def _not_found(e):
        return jsonify({"error": "not found"}), 404

    @app.post("/scopes")
    def ingest():
        body = request.get_json(silent=True) or {}
        adapter = body.get("adapter")
        pdf_path = body.get("pdf_path")
        storage_dir = body.get("storage_dir")
        if not adapter or not pdf_path:
            return jsonify({"error": "adapter and pdf_path are required"}), 400
        if configured_upload_dir and not _resolves_inside(configured_upload_dir, pdf_path):
            return jsonify({"error": "pdf_path must be inside the configured upload directory"}), 400
        if configured_data_dir and storage_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400
        try:
            result = run_ingest(adapter, pdf_path, body.get("room_codes"), storage_dir)
        except (ValueError, FileNotFoundError) as e:
            return jsonify({"error": str(e)}), 400
        return jsonify(_ingest_result_to_dict(result)), 200

    @app.get("/scopes")
    def list_scopes():
        storage_dir = request.args.get("storage_dir")
        if configured_data_dir and storage_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400
        return jsonify({"scope_ids": list_committed_scope_ids(storage_dir)}), 200

    @app.get("/scopes/<scope_id>")
    def describe(scope_id):
        storage_dir = request.args.get("storage_dir")
        if configured_data_dir and storage_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400
        try:
            room_types = run_describe(scope_id, storage_dir)
        except ValueError as e:
            return jsonify({"error": str(e)}), 404
        return jsonify({"scope_id": scope_id, "room_types": [_room_type_summary_to_dict(rt) for rt in room_types]}), 200

    @app.get("/scopes/<scope_id>/review")
    def review(scope_id):
        storage_dir = request.args.get("storage_dir")
        if not storage_dir:
            return jsonify({"error": "storage_dir query parameter is required"}), 400
        if configured_data_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400
        try:
            items = run_review(scope_id, storage_dir)
        except ValueError as e:
            return jsonify({"error": str(e)}), 404
        return jsonify({"scope_id": scope_id, "review_items": [_review_item_to_dict(i) for i in items]}), 200

    @app.post("/scopes/<scope_id>/correct")
    def correct(scope_id):
        body = request.get_json(silent=True) or {}
        storage_dir = body.get("storage_dir")
        entity_id = body.get("entity_id")
        field_name = body.get("field_name")
        value = body.get("value")
        if not storage_dir or not entity_id or not field_name or value is None:
            return jsonify({"error": "storage_dir, entity_id, field_name, and value are all required"}), 400
        if configured_data_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400
        confidence = ConfidenceLevel.HIGH if body.get("confidence", "high") == "high" else ConfidenceLevel.MEDIUM
        try:
            result = run_correct(scope_id, storage_dir, entity_id, field_name, value, confidence)
        except ValueError as e:
            return jsonify({"error": str(e)}), 404
        return jsonify(_correct_result_to_dict(result)), 200

    @app.post("/scopes/<scope_id>/price")
    def price(scope_id):
        body = request.get_json(silent=True) or {}
        required = ["room_type_id", "check_in", "check_out", "adults"]
        missing = [f for f in required if body.get(f) is None]
        if missing:
            return jsonify({"error": f"missing required field(s): {', '.join(missing)}"}), 400
        storage_dir = body.get("storage_dir")
        if configured_data_dir and storage_dir and not _resolves_inside(configured_data_dir, storage_dir):
            return jsonify({"error": "storage_dir must be inside the configured data directory"}), 400

        try:
            check_in = date.fromisoformat(body["check_in"])
            check_out = date.fromisoformat(body["check_out"])
            booking_date = date.fromisoformat(body["booking_date"]) if body.get("booking_date") else None
        except ValueError as e:
            return jsonify({"error": f"invalid date: {e}"}), 400

        try:
            result = run_price(
                scope_id, storage_dir, body["room_type_id"], check_in, check_out,
                body["adults"], body.get("children", 0), body.get("infants", 0),
                child_ages=body.get("child_ages"), adult_ages=body.get("adult_ages"), booking_date=booking_date,
            )
        except ValueError as e:
            return jsonify({"error": str(e)}), 404
        return jsonify(_price_result_to_dict(result)), 200

    return app
