"""
Raw document reconstruction — zero business knowledge.

Reads a PDF and returns the text laid out on each page, exactly as it
appears. This module has no idea what a "Room", "PPPN", or "Tour Operator"
is — it doesn't even know this is a hotel contract. It would produce the
same kind of output for an invoice, a lease, or a menu. All meaning is
found downstream, in semantic_adapters.

M3 addition: some contracts arrive as scanned images with no embedded
text layer at all (confirmed against the real Alltours contract — every
page returns zero characters from pdfplumber's native extraction). Per
the roadmap's own scope for this module ("Raw grid reconstruction from
PDF/Excel/Word/**image**"), OCR fallback belongs here: it's still just
raw-pixels-to-text reconstruction, zero business knowledge, the same
category of operation as pdfplumber's native text extraction — not a new
capability requiring an architecture decision. When a page has no usable
native text layer, this module renders it to an image and OCRs it
automatically; semantic_adapters never needs to know or care which path a
given page took.

Only stdlib + pdfplumber-class libraries (+ pytesseract/PIL for the OCR
fallback, same category of tool). Never imports contract_model,
semantic_adapters, pricing_engine, or review_ui — the dependency-boundary
test enforces this mechanically.
"""

from __future__ import annotations
from dataclasses import dataclass
import os

import pdfplumber

try:
    import pytesseract
    from PIL import Image, ImageOps
    import tempfile
    _OCR_AVAILABLE = True
except ImportError:
    _OCR_AVAILABLE = False

# Below this many characters, a page's native text layer is treated as
# "not really there" (stray artifacts, not real content) and OCR is used
# instead.
_MIN_NATIVE_CHARS = 20
_OCR_RESOLUTION_DPI = 600

# Caches a page's extraction result by (absolute path, file mtime, page
# number). Deliberately in-memory/per-process only, not persisted to
# disk -- see this module's own caching test file for why. Keying on
# mtime (not just path) means a modified file never silently reuses a
# stale entry; a cache hit only ever saves time, it can never produce a
# wrong result, since the same (path, mtime, page) always extracts to
# the same text. Unbounded on purpose: this project's real fixtures
# amount to a handful of pages total, ever -- an eviction policy would
# be solving a scale problem nothing here actually has.
_PAGE_CACHE: dict[tuple[str, float, int], "RawPage"] = {}


@dataclass
class RawPage:
    """page_number is 1-indexed — matches what a human reading the PDF
    would call "page 3", which is also what Provenance downstream needs
    to point a reviewer back at the right page.

    extraction_method records which path produced this page's text
    ("native_text" or "ocr:tesseract") -- a property of the extraction
    itself, not business knowledge, and useful downstream since
    OCR'd text generally warrants more cautious confidence than a native
    text layer."""
    page_number: int
    text: str
    extraction_method: str = "native_text"


def _ocr_page(page) -> str:
    if not _OCR_AVAILABLE:
        raise RuntimeError(
            "This page has no native text layer and needs OCR, but pytesseract/PIL "
            "are not installed in this environment."
        )
    # Empirically, OCR accuracy on dense contract tables is measurably
    # better after a save-to-disk-and-reload round trip than using
    # pdfplumber's in-memory PageImage directly -- confirmed reproducibly
    # against the real Alltours contract (a date token misread without the
    # round trip, correct with it, consistent across repeated runs). The
    # cause looks like a resampling/antialiasing difference baked in by
    # the PNG round trip that happens to help tesseract's stroke
    # detection; whatever the mechanism, this is still purely
    # pixels-to-text reconstruction, zero business knowledge.
    rendered = page.to_image(resolution=_OCR_RESOLUTION_DPI)
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        rendered.save(tmp_path)
        image = Image.open(tmp_path).convert("L")
        image = ImageOps.autocontrast(image)
        return pytesseract.image_to_string(image, config="--psm 6")
    finally:
        os.remove(tmp_path)


def read_pdf_pages(pdf_path: str, page_numbers: list[int] | None = None) -> list[RawPage]:
    """page_numbers, if given, is a list of 1-indexed page numbers to read
    -- everything else is skipped entirely (no OCR cost paid for pages
    nobody asked for). Which pages a given contract's needed data lives on
    is adapter-level knowledge (e.g. "page 1 has everything this TO's
    rate table needs"), not something document_parser decides -- it only
    honors the range it's given. Default (None) reads every page, as before.

    Each page's result is cached (_PAGE_CACHE) by (path, mtime, page
    number) -- a second call for a page already read in this process
    (native or OCR) returns the cached RawPage without re-extracting or
    re-OCRing at all."""
    pages: list[RawPage] = []
    abspath = os.path.abspath(pdf_path)
    file_mtime = os.path.getmtime(pdf_path)
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages):
            page_number = i + 1
            if page_numbers is not None and page_number not in page_numbers:
                continue

            cache_key = (abspath, file_mtime, page_number)
            cached = _PAGE_CACHE.get(cache_key)
            if cached is not None:
                pages.append(cached)
                continue

            native_text = page.extract_text() or ""
            if len(native_text.strip()) >= _MIN_NATIVE_CHARS:
                raw_page = RawPage(page_number=page_number, text=native_text, extraction_method="native_text")
            else:
                ocr_text = _ocr_page(page)
                raw_page = RawPage(page_number=page_number, text=ocr_text, extraction_method="ocr:tesseract")
            _PAGE_CACHE[cache_key] = raw_page
            pages.append(raw_page)
    return pages
