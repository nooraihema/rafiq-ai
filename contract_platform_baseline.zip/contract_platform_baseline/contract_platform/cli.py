"""
The CLI — one of two transports over orchestration.py's shared business
logic (the other is api/app.py, the HTTP API). This module's only job is
turning argv into an orchestration.py call, and that call's result into
stdout text and an exit code — no business logic lives here.

History: cli.py originally held run_ingest/run_review/run_correct/
run_describe/run_price directly (M6 Slices 1-5). When the API layer was
built, those functions were extracted into orchestration.py so a second
transport wouldn't have to import this one (see orchestration.py's own
docstring for why that would have been backwards layering). Every
CLI-level test from that period still passes unchanged, updated only to
import from the new location -- the proof this was a pure move, not a
behavior change.
"""

from __future__ import annotations
import argparse
import sys
from datetime import date
from typing import Optional

from contract_platform.contract_model.vocabulary import ConfidenceLevel
from contract_platform.registry.store import list_committed_scope_ids
from contract_platform.validation.invariants import Severity
from contract_platform.orchestration import (
    KNOWN_ADAPTERS, run_ingest, run_review, run_correct, run_describe, run_price,
)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="contract_platform", description="Ingest and inspect real tour-operator contracts.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest_parser = subparsers.add_parser("ingest", help="Extract a contract PDF and attempt to commit it.")
    ingest_parser.add_argument("adapter", choices=KNOWN_ADAPTERS)
    ingest_parser.add_argument("pdf_path")
    ingest_parser.add_argument("--room-codes", nargs="*", default=None)
    ingest_parser.add_argument("--storage-dir", default=None)

    list_parser = subparsers.add_parser("list", help="List committed scope ids.")
    list_parser.add_argument("--storage-dir", default=None)

    review_parser = subparsers.add_parser("review", help="List review items for a rejected (draft) scope.")
    review_parser.add_argument("scope_id")
    review_parser.add_argument("--storage-dir", required=True)

    correct_parser = subparsers.add_parser(
        "correct", help="Apply one correction to a draft scope and attempt to re-commit it.")
    correct_parser.add_argument("scope_id")
    correct_parser.add_argument("--storage-dir", required=True)
    correct_parser.add_argument("--entity-id", required=True)
    correct_parser.add_argument("--field-name", required=True)
    correct_parser.add_argument("--value", type=int, required=True)
    correct_parser.add_argument("--confidence", choices=["high", "medium"], default="high")

    describe_parser = subparsers.add_parser("describe", help="Show a committed scope's room types.")
    describe_parser.add_argument("scope_id")
    describe_parser.add_argument("--storage-dir", default=None)

    price_parser = subparsers.add_parser("price", help="Price a booking against a committed scope.")
    price_parser.add_argument("scope_id")
    price_parser.add_argument("--storage-dir", default=None)
    price_parser.add_argument("--room-type-id", required=True)
    price_parser.add_argument("--check-in", required=True, help="YYYY-MM-DD")
    price_parser.add_argument("--check-out", required=True, help="YYYY-MM-DD")
    price_parser.add_argument("--adults", type=int, required=True)
    price_parser.add_argument("--children", type=int, default=0)
    price_parser.add_argument("--infants", type=int, default=0)
    price_parser.add_argument("--child-ages", type=int, nargs="*", default=None,
                               help="One age per identified child, e.g. --child-ages 4 9")
    price_parser.add_argument("--adult-ages", type=int, nargs="*", default=None,
                               help="One age per identified adult, e.g. --adult-ages 65 45")
    price_parser.add_argument("--booking-date", default=None, help="YYYY-MM-DD")

    args = parser.parse_args(argv)

    if args.command == "ingest":
        try:
            result = run_ingest(args.adapter, args.pdf_path, args.room_codes, args.storage_dir)
        except (ValueError, FileNotFoundError) as e:
            print(f"Error: {e}")
            return 2

        if result.committed:
            print(f"Committed scope {result.scope_id}")
            print(f"  {result.room_type_count} room type(s), {result.rate_count} rate(s), "
                  f"{result.pricing_rule_count} pricing rule(s)")
            return 0

        print(f"Rejected scope {result.scope_id}")
        print(f"  {result.validation_issue_count} validation issue(s), {len(result.review_items)} field(s) need review")
        for item in result.review_items:
            print(f"  - {item.entity_id}.{item.field_name}: {item.current_value!r} (confidence={item.confidence.value})")
        return 1

    if args.command == "list":
        ids = list_committed_scope_ids(args.storage_dir)
        if not ids:
            print("No committed scopes found.")
            return 0
        for scope_id in ids:
            print(scope_id)
        return 0

    if args.command == "review":
        try:
            items = run_review(args.scope_id, args.storage_dir)
        except ValueError as e:
            print(f"Error: {e}")
            return 2
        if not items:
            print(f"No fields need review for scope {args.scope_id}.")
            return 0
        print(f"{len(items)} field(s) need review for scope {args.scope_id}:")
        for item in items:
            print(f"  - {item.entity_id}.{item.field_name}: {item.current_value!r} (confidence={item.confidence.value})")
        return 0

    if args.command == "correct":
        confidence = ConfidenceLevel.HIGH if args.confidence == "high" else ConfidenceLevel.MEDIUM
        try:
            result = run_correct(args.scope_id, args.storage_dir, args.entity_id, args.field_name,
                                  args.value, confidence)
        except ValueError as e:
            print(f"Error: {e}")
            return 2

        if not result.applied:
            print(f"Error: no field {args.entity_id}.{args.field_name} found on scope {args.scope_id}.")
            return 2

        if result.committed:
            print(f"Correction applied. Scope {args.scope_id} committed successfully.")
            return 0

        print(f"Correction applied. Scope {args.scope_id} still needs review:")
        for item in result.remaining_review_items:
            print(f"  - {item.entity_id}.{item.field_name}: {item.current_value!r} (confidence={item.confidence.value})")
        return 1

    if args.command == "describe":
        try:
            room_types = run_describe(args.scope_id, args.storage_dir)
        except ValueError as e:
            print(f"Error: {e}")
            return 2
        if not room_types:
            print(f"Scope {args.scope_id} has no room types.")
            return 0
        print(f"Scope {args.scope_id} \u2014 {len(room_types)} room type(s):")
        for rt in room_types:
            print(f"  {rt.room_type_id}  {rt.canonical_code or '(no code)'}  {rt.display_name or '(no name)'}  "
                  f"({rt.valid_occupancy_count} occupancy combo(s))")
        return 0

    if args.command == "price":
        try:
            check_in = date.fromisoformat(args.check_in)
            check_out = date.fromisoformat(args.check_out)
            booking_date = date.fromisoformat(args.booking_date) if args.booking_date else None
        except ValueError as e:
            print(f"Error: invalid date \u2014 {e}")
            return 2

        try:
            result = run_price(args.scope_id, args.storage_dir, args.room_type_id, check_in, check_out,
                                args.adults, args.children, args.infants,
                                child_ages=args.child_ages, adult_ages=args.adult_ages, booking_date=booking_date)
        except ValueError as e:
            print(f"Error: {e}")
            return 2

        if not result.valid:
            print(f"Booking is invalid for scope {args.scope_id}:")
            for issue in result.validation_issues:
                if issue.severity == Severity.ERROR:
                    print(f"  - {issue.code}: {issue.message}")
            return 1

        warnings = [i for i in result.validation_issues if i.severity == Severity.WARNING]
        if warnings:
            print(f"Note: {len(warnings)} warning(s) for this booking:")
            for issue in warnings:
                print(f"  - {issue.code}: {issue.message}")

        invoice = result.invoice
        print(f"Invoice for scope {args.scope_id}, room {args.room_type_id}:")
        for line in invoice.lines:
            print(f"  {line.description}: {line.unit_rate:.2f} x {line.nights} night(s) x {line.quantity} "
                  f"= {line.line_total:.2f} {line.currency}")
        print(f"Total: {invoice.total:.2f} {invoice.currency}")
        return 0

    return 2  # unreachable: argparse's `required=True` on subparsers already rejects anything else


if __name__ == "__main__":
    sys.exit(main())
