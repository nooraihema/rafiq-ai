"""
The Pricing Engine — the one place in the system allowed to combine "a
contract" with "an actual stay someone is booking." semantic_adapters and
review_ui never see a booking; contract_model and expression_engine have
no idea what a booking even is structurally.

Per architecture Part 4: booking-time validation (checks that need an
actual booking in hand, not just the contract alone) lives here, not in
the validation package — that package only ever sees a ContractScope.

Forbidden to import semantic_adapters or document_parser — enforced by
test_dependency_boundaries.py.

Foundation Hardening II (pre-M4): price_booking() now prices a
CHILD_POLICY line per matching child, using PricingRule.applicability
(applicability.py) and, for however many rules end up applicable,
composition.py's ordering. This module stays a thin orchestrator: it
finds candidate rules and calls into those two independent modules; it
contains no eligibility logic and no ordering logic of its own.

BookingRequest deliberately stays small and stable: room, dates, party
size -- the core identity of a booking, unchanged since M1. Anything an
ApplicabilityCondition might need to check (booking date, guest ages)
lives in a separate, optional BookingApplicabilityContext, precisely so
future condition types extend that object instead of BookingRequest
growing one field per condition ever discovered.

Post-Odeon-review fixes (implementation gaps, not Model/Expression
changes):

1. Cross-period "Stay" pricing. Rate resolution is now per-night rather
   than "one Season must contain the whole stay." Evidence: multiple real
   contracts label their base-rate period columns "Stay" (Odeon's base
   price table itself, not just its offers -- verified before
   implementing, see the architectural review this followed), meaning a
   stay spanning a period boundary must be priced night-by-night from
   each night's own rate, not rejected or pinned to check-in's rate. A
   stay fully inside one Season (every case before this change) still
   resolves to exactly one segment -- confirmed byte-for-byte identical
   tie-breaking (first matching Rate by scope.rates order) against every
   existing test before this was implemented.
2. SOPN consumption. Rate.basis == SINGLE_OCCUPANCY_PER_NIGHT has been
   extracted by the EXIM adapter since M1 but was never selected by
   price_booking(), which only ever looked for PER_PERSON_PER_NIGHT.
   Booking.adults == 1 now prefers a SINGLE_OCCUPANCY_PER_NIGHT rate for
   the relevant night when the room/season defines one, falling back to
   PER_PERSON_PER_NIGHT when it doesn't (every room in every adapter
   except EXIM's DR01/SR01-style rows) -- so this is purely additive.

3. Market disambiguation. Anex's Promo Room has two Markets (East
   European, Russia & CIS) with overlapping-date Seasons that genuinely
   disagree in price (confirmed against real data: both give different
   July 2026 rates -- 74.00 vs. 68.00 -- for the same calendar nights).
   Before this fix, _rate_for_night had no way to prefer one over the
   other and resolved the ambiguity by scope.rates construction order --
   correct by coincidence wherever test data happened to tie, not by
   design. BookingRequest gained one new optional field, market_id: this
   is a core booking-identity fact (which market this booking is sold
   through), not an ApplicabilityCondition, so it lives on BookingRequest
   directly rather than BookingApplicabilityContext. Rates with
   market_id=None (every non-Anex adapter today) are always eligible
   regardless of the booking's market_id, so this is additive for every
   existing adapter; omitting market_id entirely reproduces the exact
   pre-fix (ambiguous-where-it-already-was) behavior.

M4 Slice 4: check_stay_length_within_min_max_stay enforces contract-level
MinMaxStay Restrictions (EXIM's real "3/999 nights" clause) as a
booking-time check, the same shape as the two checks already here --
a booking outside the range is a blocking ERROR, never silently priced.

M4 (Release Period slice): check_release_period enforces rate-scoped
ReleaseRule Restrictions (Anex's real "Release 5" column) as a
booking-time WARNING, not a blocking ERROR -- the contract doesn't state
what happens once a booking falls inside that window, so this doesn't
invent a stricter rule than what's printed. Only checked when the caller
supplies booking.context.booking_date; every booking that doesn't is
unaffected.
"""

from __future__ import annotations
from dataclasses import dataclass, field, replace
from datetime import date, timedelta
from typing import Optional

from contract_platform.contract_model.entities import ContractScope, MinMaxStay, AgeCondition, ReleaseRule
from contract_platform.contract_model.expressions import RateRef
from contract_platform.contract_model.vocabulary import RateBasis, RuleKind, GuestType
from contract_platform.expression_engine.evaluator import evaluate, EvaluationContext
from contract_platform.validation.invariants import ValidationIssue, Severity
from contract_platform.pricing_engine.applicability import rule_applies
from contract_platform.pricing_engine.composition import order_rules


class PricingError(Exception):
    pass


@dataclass(frozen=True)
class GuestAge:
    """One guest's role and age, for ApplicabilityCondition matching
    (AgeCondition). role uses the existing GuestType enum, so a Senior
    check and a child-band check are the same shape of fact."""
    role: GuestType
    age: float


@dataclass
class BookingApplicabilityContext:
    """Everything a PricingRule's ApplicabilityCondition might need to
    check, beyond BookingRequest's core identity (room, dates, party
    size). Kept as its own object specifically so BookingRequest doesn't
    accumulate one field per condition type as new applicability
    dimensions get discovered -- a future dimension extends this object,
    not BookingRequest itself. Optional and additive: omitting it entirely
    reproduces every pre-existing BookingRequest's exact behavior."""
    booking_date: Optional[date] = None
    guest_ages: list[GuestAge] = field(default_factory=list)


@dataclass
class BookingRequest:
    room_type_id: str
    check_in: date
    check_out: date
    adults: int
    children: int = 0
    infants: int = 0
    market_id: Optional[str] = None
    context: Optional[BookingApplicabilityContext] = None


@dataclass
class InvoiceLine:
    description: str
    rate_id: str
    unit_rate: float
    nights: int
    quantity: int
    line_total: float
    currency: str


@dataclass
class Invoice:
    room_type_id: str
    lines: list[InvoiceLine] = field(default_factory=list)
    total: float = 0.0
    currency: str = "USD"


def _nights(check_in: date, check_out: date) -> int:
    return (check_out - check_in).days


def _daterange(start: date, end: date):
    for i in range((end - start).days):
        yield start + timedelta(days=i)


# --- Per-night rate resolution ----------------------------------------------

def _rate_for_night(scope: ContractScope, room_id: str, night: date, adults: int, market_id: Optional[str] = None):
    """Finds the Rate covering one specific night for this room, preferring
    SINGLE_OCCUPANCY_PER_NIGHT when adults == 1 and the room/season
    defines one, falling back to PER_PERSON_PER_NIGHT otherwise.

    market_id disambiguates when multiple Markets have overlapping-date
    Seasons for the same room at different rates (confirmed real: Anex's
    Promo Room genuinely disagrees -- East European vs. Russia & CIS give
    different July rates for the same calendar nights). A Rate with
    market_id=None (every non-Anex adapter today) is treated as
    market-agnostic and always eligible. When booking.market_id is None
    (unspecified), behavior is unchanged from before this fix -- first
    match by scope.rates order, ambiguous only when it already was.

    Iterates scope.rates in its existing order so the tie-break rule
    (first match by construction order) is identical to what
    price_booking() already did before this and the prior change -- a
    stay fully inside one Season resolves to the same single Rate every
    night, matching prior behavior exactly."""
    bases_to_try = (
        [RateBasis.SINGLE_OCCUPANCY_PER_NIGHT, RateBasis.PER_PERSON_PER_NIGHT]
        if adults == 1 else [RateBasis.PER_PERSON_PER_NIGHT]
    )
    for basis in bases_to_try:
        for rate in scope.rates:
            if rate.room_type_id != room_id or rate.basis != basis:
                continue
            if market_id is not None and rate.market_id is not None and rate.market_id != market_id:
                continue  # a different, explicitly-specified market -- not eligible
            season = next((s for s in scope.seasons if s.id == rate.season_id), None)
            if season is not None and season.start_date.value <= night <= season.end_date.value:
                return rate, season
    return None, None


def _split_stay_into_segments(scope: ContractScope, room_id: str, check_in: date, check_out: date,
                               adults: int, market_id: Optional[str] = None):
    """Walks the stay night by night and groups consecutive nights that
    resolve to the same Rate into one segment -- implementing the 'Stay'
    convention (each night priced from its own period) while collapsing
    back to exactly one segment whenever the whole stay is covered by a
    single Rate, which is every case that existed before this change.
    Returns None if any night isn't covered by a priced Rate at all (a
    real gap, still a booking-time failure, not silently priced from
    whatever's nearby)."""
    segments = []
    current_rate = None
    current_season = None
    current_nights = 0

    for night in _daterange(check_in, check_out):
        rate, season = _rate_for_night(scope, room_id, night, adults, market_id)
        if rate is None:
            return None
        if current_rate is not None and rate.id == current_rate.id:
            current_nights += 1
        else:
            if current_rate is not None:
                segments.append((current_rate, current_season, current_nights))
            current_rate, current_season, current_nights = rate, season, 1

    if current_rate is not None:
        segments.append((current_rate, current_season, current_nights))
    return segments


# --- Booking-time validation (Part 4) ---------------------------------------

def check_occupancy_matches_room(scope: ContractScope, booking: BookingRequest) -> list[ValidationIssue]:
    room = next((r for r in scope.room_types if r.id == booking.room_type_id), None)
    if room is None:
        return [ValidationIssue(Severity.ERROR, "UNKNOWN_ROOM_TYPE",
                                 f"No RoomType {booking.room_type_id!r} in this scope.", booking.room_type_id)]

    for occ in room.valid_occupancies:
        if (occ.adults.value == booking.adults
                and occ.children.value == booking.children
                and occ.infants.value == booking.infants):
            return []

    return [ValidationIssue(
        Severity.ERROR, "OCCUPANCY_NOT_PERMITTED",
        f"{booking.adults} adult(s) + {booking.children} child(ren) + {booking.infants} infant(s) "
        f"is not a valid occupancy combination for RoomType {room.canonical_code}.",
        room.id,
    )]


def check_dates_within_a_season(scope: ContractScope, booking: BookingRequest) -> list[ValidationIssue]:
    """Now delegates to the same per-night segment split price_booking()
    uses, so validation and pricing can never disagree about whether a
    stay is coverable -- a stay is valid iff every night resolves to some
    Rate, whether that's one Season (unchanged case) or several
    contiguous ones (the new 'Stay' case)."""
    segments = _split_stay_into_segments(scope, booking.room_type_id, booking.check_in, booking.check_out,
                                          booking.adults, booking.market_id)
    if segments is not None:
        return []
    return [ValidationIssue(
        Severity.ERROR, "DATES_OUTSIDE_SEASON",
        f"Booking {booking.check_in}\u2013{booking.check_out} is not fully covered by any priced Season for this room.",
        booking.room_type_id,
    )]


def check_stay_length_within_min_max_stay(scope: ContractScope, booking: BookingRequest) -> list[ValidationIssue]:
    """MinMaxStay Restrictions scoped to the whole contract
    (applies_to_contract_scope_id) apply to every booking in that scope,
    regardless of room -- the real EXIM clause's own scope ("All", printed
    once for the contract, not per room). Restriction-level min/max-stay
    scoped instead to a specific PricingRule or Rate isn't evidenced in
    any real adapter yet (MinMaxStay's other two 'applies_to_*' fields,
    present since M0, remain unused by any real data), so isn't checked
    here -- built when real data forces that shape, not speculatively."""
    nights = _nights(booking.check_in, booking.check_out)
    issues = []
    for restriction in scope.restrictions:
        if not isinstance(restriction, MinMaxStay):
            continue
        if restriction.applies_to_contract_scope_id != scope.id:
            continue
        if not (restriction.min_nights.value <= nights <= restriction.max_nights.value):
            issues.append(ValidationIssue(
                Severity.ERROR, "STAY_LENGTH_OUTSIDE_MIN_MAX_STAY",
                f"Stay of {nights} night(s) is outside the contract's Min/Max Stay "
                f"({restriction.min_nights.value}-{restriction.max_nights.value} nights).",
                booking.room_type_id,
            ))
    return issues


def check_release_period(scope: ContractScope, booking: BookingRequest) -> list[ValidationIssue]:
    """ReleaseRule Restrictions scoped to a specific Rate
    (applies_to_rate_id -- e.g. Anex's real "Release 5" column, printed
    per rate row rather than once for the whole contract like EXIM's
    MinMaxStay) flag a booking made inside the release window as a
    WARNING, not a blocking ERROR. Unlike MinMaxStay's explicit,
    black-and-white "3/999 nights" printed rule, "Release 5" doesn't
    state what happens once a booking falls inside that window (rejected
    outright? subject to availability? flagged for manual confirmation?)
    -- real hotel contracts commonly still honor such bookings on
    request, so a hard ERROR would invent a stricter rule than the
    contract states. Only checked when the caller actually supplies
    booking.context.booking_date -- every booking that doesn't (every
    booking before this slice) is completely unaffected."""
    if booking.context is None or booking.context.booking_date is None:
        return []
    days_before = (booking.check_in - booking.context.booking_date).days
    issues = []
    for restriction in scope.restrictions:
        if not isinstance(restriction, ReleaseRule) or restriction.applies_to_rate_id is None:
            continue
        rate = next((r for r in scope.rates if r.id == restriction.applies_to_rate_id), None)
        if rate is None or rate.room_type_id != booking.room_type_id:
            continue
        season = next((s for s in scope.seasons if s.id == rate.season_id), None)
        if season is None or not (season.start_date.value <= booking.check_in <= season.end_date.value):
            continue
        if days_before < restriction.days_before_arrival.value:
            issues.append(ValidationIssue(
                Severity.WARNING, "BOOKING_INSIDE_RELEASE_PERIOD",
                f"Booking made {days_before} day(s) before arrival, inside the contract's "
                f"{restriction.days_before_arrival.value}-day release period -- availability may not be guaranteed.",
                booking.room_type_id,
            ))
    return issues


BOOKING_TIME_CHECKS = [
    check_occupancy_matches_room, check_dates_within_a_season,
    check_stay_length_within_min_max_stay, check_release_period,
]


def validate_booking(scope: ContractScope, booking: BookingRequest) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for check in BOOKING_TIME_CHECKS:
        issues.extend(check(scope, booking))
    return issues


# --- Pricing -----------------------------------------------------------------

def _rate_values_for_season(scope: ContractScope, season_id: str) -> dict:
    """A rule's calculation may reference any Rate scoped to the same
    Season (e.g. Anex's child-policy Expression references the room's
    base double rate). Building the full season's rate map, rather than
    guessing which single Rate a given rule needs, keeps this generic
    across whatever a rule's Expression actually references."""
    return {r.id: r.amount.value for r in scope.rates if r.season_id == season_id}


def _child_policy_lines(scope: ContractScope, booking: BookingRequest, room, season_id: str, nights: int) -> list:
    """Thin orchestration only: finds candidate CHILD_POLICY rules, asks
    applicability.rule_applies whether each applies to a given child, asks
    composition.order_rules for the order to try them in, and evaluates
    the first match's Expression through expression_engine. No eligibility
    or ordering logic lives here -- both come from the two independent
    modules this function calls.

    M4 Slice 3: children are now matched by *position* too, not just age.
    A child's position is its index (1-based) within
    booking.context.guest_ages, in party order -- the same positional
    convention _adult_lines already uses for adults (no per-guest identity
    beyond that order). A rule with applies_to_pax_number set (EXIM's
    1st/2nd-child CHILD_PCT rules) is only considered for the child at
    that exact position; position-agnostic rules (applies_to_pax_number is
    None -- every CHILD_POLICY rule before this slice, e.g. Anex's) are
    tried next if no positional rule matches. A party whose only
    candidate rules are position-agnostic resolves identically to before
    this change, regardless of guest order."""
    if booking.context is None:
        return []
    child_guests = [g for g in booking.context.guest_ages if g.role == GuestType.CHILD]
    if not child_guests:
        return []

    candidate_rules = [
        r for r in scope.pricing_rules
        if r.kind == RuleKind.CHILD_POLICY
        and r.season_id == season_id
        and (r.room_type_id is None or r.room_type_id == room.id)
    ]
    ordered_rules = order_rules(candidate_rules)
    rate_values = _rate_values_for_season(scope, season_id)

    lines = []
    for position, guest in enumerate(child_guests, start=1):
        # Applicability is asked per-guest (a singleton context) so a rule
        # scoped to one age band doesn't get credited for a different
        # child elsewhere in the party who happens to also be a CHILD.
        single_guest_booking = replace(booking, context=replace(booking.context, guest_ages=[guest]))
        positional_matches = (r for r in ordered_rules if r.applies_to_pax_number == position)
        generic_matches = (r for r in ordered_rules if r.applies_to_pax_number is None)
        matching_rule = next((r for r in positional_matches if rule_applies(r, single_guest_booking)), None)
        if matching_rule is None:
            matching_rule = next((r for r in generic_matches if rule_applies(r, single_guest_booking)), None)
        if matching_rule is None:
            continue

        ctx = EvaluationContext(rate_values=rate_values)
        unit_rate = evaluate(matching_rule.calculation.value, ctx)
        lines.append(InvoiceLine(
            description=f"Child (age {guest.age:g}) \u2014 {matching_rule.label}",
            rate_id=matching_rule.id, unit_rate=unit_rate, nights=nights, quantity=1,
            line_total=unit_rate * nights, currency="USD",
        ))
    return lines


def _adult_lines(scope: ContractScope, booking: BookingRequest, room, rate, season, nights: int) -> list:
    """Generalizes base-rate consumption beyond a flat unit_rate * nights *
    adults: real EXIM/Alltours data assigns a specific per-night amount to
    a numbered adult slot (PricingRule.applies_to_pax_number -- e.g.
    "3rd Adult Amount Reduction"), not to the booking as a whole. Adults
    not matched by any positional SUPPLEMENT rule for this room/season
    still price at the base Rate, in one combined line -- so a room with
    no positional rules at all (every room built before this change)
    produces exactly the same single line as before, byte-for-byte.

    This is the platform's first real non-CHILD_POLICY rule consumption
    (M4 checkpoint 1) -- the SUPPLEMENT lookup below is structurally the
    same shape as _child_policy_lines' CHILD_POLICY lookup, just keyed by
    pax position instead of by guest age.

    M4 (Longstay slice): a *non*-positional SUPPLEMENT rule
    (applies_to_pax_number is None) gated by real applicability -- e.g.
    Alltours' real "Longstay from 21 nights: 10% reduction" -- overrides
    the base per-person rate for every adult not otherwise matched by a
    positional rule. rule_applies() is checked against the whole booking
    (not a single guest slot, unlike CHILD_POLICY/positional SUPPLEMENT),
    since a Longstay-style reduction is a property of the booking itself,
    not of one numbered guest. Only one such rule is ever selected per
    booking (order_rules' existing first-match ordering) -- composition.py's
    own docstring already flagged "no real contract data yet has two
    PricingRules simultaneously applicable" as a deferred question;
    Alltours' real data has two Longstay tiers that could both match a
    30+-night stay, so only the unambiguous 21-night tier is built by the
    adapter (see its own comment) -- this function doesn't need to
    resolve a tie that doesn't exist yet in what it's given.

    M4 (Senior Discount slice): AgeCondition-gated non-positional
    SUPPLEMENT rules (e.g. Alltours' real "Senior from 60 years: 10%
    reduction") are deliberately NOT folded into the whole-booking
    override above -- age is a *per-guest* fact (unlike nights, a single
    booking-level fact), and AgeCondition's matcher has always used "any
    guest of this role/age" semantics (mirroring _child_policy_lines'
    per-single-guest evaluation for children). Applying it as a
    whole-booking override would silently discount every adult the
    moment *any* one of them qualifies -- wrong the moment a party mixes
    a senior with a non-senior adult. So AgeCondition-gated rules are
    excluded from overall_candidates and consumed separately, per
    identified ADULT guest in booking.context.guest_ages, exactly
    mirroring _child_policy_lines' per-guest loop. Only a guest explicitly
    identified by age can ever receive this discount -- a booking with no
    context, or ADULT entries never supplied (every pre-existing booking
    shape), is completely unaffected."""
    ctx = EvaluationContext(rate_values={rate.id: rate.amount.value})
    base_unit_rate = evaluate(RateRef(rate.id), ctx)
    basis_label = "SOPN" if rate.basis == RateBasis.SINGLE_OCCUPANCY_PER_NIGHT else "PPPN"
    description_suffix = ""

    overall_candidates = order_rules([
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT
        and r.applies_to_pax_number is None
        and r.season_id == season.id
        and (r.room_type_id is None or r.room_type_id == room.id)
        and not any(isinstance(c, AgeCondition) for c in r.applicability)
    ])
    overall_rule = next((r for r in overall_candidates if rule_applies(r, booking)), None)
    if overall_rule is not None:
        base_unit_rate = evaluate(overall_rule.calculation.value, ctx)
        description_suffix = f" \u2014 {overall_rule.label}"

    # Per-guest ADULT consumption (Senior Discount): only identified
    # adults (booking.context.guest_ages entries with role=ADULT) can
    # ever match -- an unidentified adult (the only kind that existed
    # before this slice) falls through to the standard/positional count
    # below, unaffected.
    age_gated_candidates = order_rules([
        r for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT
        and r.applies_to_pax_number is None
        and r.season_id == season.id
        and (r.room_type_id is None or r.room_type_id == room.id)
        and any(isinstance(c, AgeCondition) for c in r.applicability)
    ])
    adult_guests = [] if booking.context is None else [
        g for g in booking.context.guest_ages if g.role == GuestType.ADULT
    ]
    senior_lines = []
    identified_count = 0
    for guest in adult_guests:
        single_guest_booking = replace(booking, context=replace(booking.context, guest_ages=[guest]))
        matching_rule = next((r for r in age_gated_candidates if rule_applies(r, single_guest_booking)), None)
        if matching_rule is None:
            continue
        identified_count += 1
        senior_unit_rate = evaluate(matching_rule.calculation.value, ctx)
        senior_lines.append(InvoiceLine(
            description=f"{room.display_name} \u2014 {matching_rule.label} (age {guest.age:g})",
            rate_id=matching_rule.id, unit_rate=senior_unit_rate, nights=nights, quantity=1,
            line_total=senior_unit_rate * nights, currency=rate.currency,
        ))
    remaining_adults = booking.adults - identified_count

    # Known limitation, not yet evidenced by any real booking: positional
    # rules (e.g. a 3rd/4th Adult Reduction) below are indexed over
    # remaining_adults (party size after removing identified seniors),
    # not the adult's original position in the full party. No real
    # booking has combined a positional SUPPLEMENT rule with an
    # identified senior guest yet -- flagged here rather than solved
    # speculatively.
    positional_rules = {
        r.applies_to_pax_number: r
        for r in scope.pricing_rules
        if r.kind == RuleKind.SUPPLEMENT
        and r.applies_to_pax_number is not None
        and r.season_id == season.id
        and (r.room_type_id is None or r.room_type_id == room.id)
    }

    if not positional_rules:
        lines = []
        if remaining_adults:
            lines.append(InvoiceLine(
                description=f"{room.display_name} \u2014 {rate.meal_plan.value.replace('_', ' ').title()}, {basis_label}{description_suffix}",
                rate_id=rate.id, unit_rate=base_unit_rate, nights=nights, quantity=remaining_adults,
                line_total=base_unit_rate * nights * remaining_adults, currency=rate.currency,
            ))
        return lines + senior_lines

    rate_values = _rate_values_for_season(scope, season.id)
    lines = []
    standard_count = sum(1 for pax in range(1, remaining_adults + 1) if pax not in positional_rules)
    if standard_count:
        lines.append(InvoiceLine(
            description=f"{room.display_name} \u2014 {rate.meal_plan.value.replace('_', ' ').title()}, {basis_label}{description_suffix}",
            rate_id=rate.id, unit_rate=base_unit_rate, nights=nights, quantity=standard_count,
            line_total=base_unit_rate * nights * standard_count, currency=rate.currency,
        ))
    for pax in range(1, remaining_adults + 1):
        rule = positional_rules.get(pax)
        if rule is None:
            continue
        ctx = EvaluationContext(rate_values=rate_values)
        positional_unit_rate = evaluate(rule.calculation.value, ctx)
        lines.append(InvoiceLine(
            description=f"{room.display_name} \u2014 {rule.label}",
            rate_id=rule.id, unit_rate=positional_unit_rate, nights=nights, quantity=1,
            line_total=positional_unit_rate * nights, currency=rate.currency,
        ))
    return lines + senior_lines


def price_booking(scope: ContractScope, booking: BookingRequest) -> Invoice:
    """Splits the stay into per-Rate segments (one segment for the common
    case of a stay fully inside one Season, several for a stay spanning a
    period boundary priced per the 'Stay' convention), evaluates each
    segment's Rate through expression_engine (a RateRef Expression, never
    a raw float), and adds one CHILD_POLICY line per matching child and
    any positional SUPPLEMENT lines per segment. With a single-Season
    stay, no booking.context/children, and no positional rules for the
    room, behavior is byte-for-byte identical to before this change."""
    issues = validate_booking(scope, booking)
    blocking = [i for i in issues if i.severity == Severity.ERROR]
    if blocking:
        raise PricingError(f"Booking failed validation: {blocking}")

    room = next(r for r in scope.room_types if r.id == booking.room_type_id)
    total_nights = _nights(booking.check_in, booking.check_out)
    if total_nights <= 0:
        raise PricingError("check_out must be after check_in.")

    segments = _split_stay_into_segments(scope, room.id, booking.check_in, booking.check_out,
                                          booking.adults, booking.market_id)
    if segments is None:
        raise PricingError(f"No Rate found for room {room.canonical_code} covering the requested dates.")

    lines = []
    for rate, season, seg_nights in segments:
        lines.extend(_adult_lines(scope, booking, room, rate, season, seg_nights))
        lines.extend(_child_policy_lines(scope, booking, room, season.id, seg_nights))

    total = sum(l.line_total for l in lines)
    currency = lines[0].currency if lines else "USD"
    return Invoice(room_type_id=room.id, lines=lines, total=total, currency=currency)
