"""
Applicability — decides whether a single PricingRule applies to a single
booking. Nothing else. This module never looks at more than one rule at a
time and never decides how multiple applicable rules combine — that's
composition.py's job, deliberately kept separate (Foundation Hardening II,
Concern 2: "Applicability and Composition remain independent concepts").

Dispatch is a registry (CONDITION_MATCHERS + @register_condition),
mirroring expression_engine/evaluator.py's NODE_EVALUATORS pattern exactly
-- this module hit the identical dispatch problem M0 already solved once
(an isinstance chain that means editing one central function for every
new type), so it follows the same fix rather than reintroducing the
problem. A fifth condition type is one new dataclass in entities.py plus
one @register_condition function here — zero lines changed in this
file's existing code.

Deliberately NOT sharing a generic registry utility with evaluator.py:
the two dispatchers have opposite failure philosophies on a miss --
evaluator.py raises (a missing Expression node must fail loudly), this
module returns False (a missing/unknown condition must fail *safely*,
never silently letting a rule apply when its eligibility can't be
verified). Unifying them would need a parameter just to configure that
difference, which is more complexity than the ~5 lines of duplicated
dict-plus-decorator infrastructure it would save.

A rule with an empty `applicability` list always applies — the correct
default, and the reason existing rules (e.g. Anex's CHILD_POLICY rule)
need zero modification to keep working exactly as before.
"""

from __future__ import annotations
from typing import Callable

from contract_platform.contract_model.entities import (
    PricingRule, StayLengthCondition, BookingDateCondition,
    DaysBeforeArrivalCondition, AgeCondition,
)

# --- Registry dispatch -------------------------------------------------
#
# CONDITION_MATCHERS maps an ApplicabilityCondition subclass to the
# function that knows how to check it against a booking. condition_matches()
# is just a lookup; it never grows a new branch when a new condition type
# is added.

CONDITION_MATCHERS: dict[type, Callable[[object, object], bool]] = {}


def register_condition(condition_type):
    def decorator(fn):
        CONDITION_MATCHERS[condition_type] = fn
        return fn
    return decorator


def condition_matches(condition, booking) -> bool:
    """booking is a pricing_engine.calculator.BookingRequest. Typed as a
    plain parameter (not imported) to avoid a circular import between
    this module and calculator.py, which imports rule_applies."""
    matcher = CONDITION_MATCHERS.get(type(condition))
    if matcher is None:
        # An ApplicabilityCondition subtype this registry doesn't know
        # about -- fail safe rather than silently let the rule apply.
        return False
    return matcher(condition, booking)


def rule_applies(rule: PricingRule, booking) -> bool:
    if not rule.applicability:
        return True
    return all(condition_matches(condition, booking) for condition in rule.applicability)


@register_condition(StayLengthCondition)
def _match_stay_length(condition: StayLengthCondition, booking) -> bool:
    """max_nights is Optional in the Model; real data can print only a
    floor with no ceiling (Alltours' "Longstay from 21 nights", no upper
    bound stated anywhere in the source) -- None means open-ended, the
    same Optional-field idiom used everywhere else in this codebase, not
    a new modeling concept."""
    nights = (booking.check_out - booking.check_in).days
    if nights < condition.min_nights.value:
        return False
    if condition.max_nights is not None and nights > condition.max_nights.value:
        return False
    return True


@register_condition(BookingDateCondition)
def _match_booking_date(condition: BookingDateCondition, booking) -> bool:
    if booking.context is None or booking.context.booking_date is None:
        return False
    return condition.from_date.value <= booking.context.booking_date <= condition.to_date.value


@register_condition(DaysBeforeArrivalCondition)
def _match_days_before_arrival(condition: DaysBeforeArrivalCondition, booking) -> bool:
    if booking.context is None or booking.context.booking_date is None:
        return False
    days_before = (booking.check_in - booking.context.booking_date).days
    return condition.min_days.value <= days_before <= condition.max_days.value


@register_condition(AgeCondition)
def _match_age(condition: AgeCondition, booking) -> bool:
    """max_age is Optional in the Model; real data can print only a floor
    with no ceiling (Alltours' "Senior from 60 years", no upper bound
    stated anywhere in the source) -- None means open-ended, the same
    idiom _match_stay_length already uses for max_nights=None."""
    if booking.context is None:
        return False
    for guest in booking.context.guest_ages:
        if guest.role != condition.role:
            continue
        if guest.age < condition.min_age.value:
            continue
        if condition.max_age is not None and guest.age > condition.max_age.value:
            continue
        return True
    return False
