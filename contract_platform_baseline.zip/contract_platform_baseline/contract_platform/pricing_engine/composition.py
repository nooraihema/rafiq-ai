"""
Composition — decides in what order multiple already-applicable
PricingRules combine when pricing one booking. Independent of
applicability (applicability.py): this module never asks "does this rule
apply" — it only orders rules that have already passed that check.

Evidence for today's only ordering policy: TUI's "Combinable with Free
Night" clause states explicitly that child/occupancy adjustments compute
first and become the new base that other discounts (Early Bird, Free
Night) are then calculated against. DEFAULT_COMPOSITION_ORDER encodes
exactly that sequence.

Deliberate design choice: this ordering is expressed as an explicit, named
data structure here, not as an implicit property of RuleKind's declaration
order in vocabulary.py. RuleKind stays a pure classification enum with no
precedence meaning of its own -- if a future contract needs a different
order (or a fundamentally different composition strategy: weighted
stacking, mutual exclusivity, etc.), only this module changes; nothing
about what RuleKind *means* has to move.

Honest limitation: no real contract data yet has two PricingRules
simultaneously applicable to the same booking (Anex's is the only real
PricingRule in the system, and it's alone). order_rules() is implemented
and unit-tested against synthetic multi-rule cases, but calculator.py's
actual pricing path only exercises the single-rule case end-to-end today.
Full multi-rule threading through an invoice is deferred until a real
contract forces the shape of that decision.
"""

from __future__ import annotations

from contract_platform.contract_model.entities import PricingRule
from contract_platform.contract_model.vocabulary import RuleKind

DEFAULT_COMPOSITION_ORDER: list[RuleKind] = [
    RuleKind.CHILD_POLICY,
    RuleKind.SUPPLEMENT,
    RuleKind.SPO_OFFER,
]


def order_rules(rules: list[PricingRule], order: list[RuleKind] | None = None) -> list[PricingRule]:
    """Returns `rules` sorted per `order` (default: DEFAULT_COMPOSITION_ORDER).
    A rule whose kind isn't in `order` sorts after every rule that is,
    preserving relative order among unlisted kinds (stable sort)."""
    effective_order = order if order is not None else DEFAULT_COMPOSITION_ORDER

    def _position(rule: PricingRule) -> int:
        try:
            return effective_order.index(rule.kind)
        except ValueError:
            return len(effective_order)

    return sorted(rules, key=_position)
