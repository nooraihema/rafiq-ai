"""
The commit gate — the first piece of the end-to-end product workflow
(PDF -> extraction -> validation -> review -> pricing).

Extracted's own docstring (contract_model/entities.py) has stated this
rule since M0: "A value with LOW confidence is legal to exist in a
*draft* Contract Model, but the Validation layer must never let one
through to a persisted Model." Nothing enforced that rule until this
module — every adapter test up to this point built a scope and priced
against it directly, bypassing the draft/persisted distinction.

commit_scope() is deliberately thin orchestration only, the same
discipline pricing_engine's booking-time checks already follow: it calls
validation.invariants.validate() (structural correctness) and
entities.iter_low_confidence() for LOW-confidence fields (per-field
extraction quality) — both already exist and are already proven correct
by every prior adapter slice's tests. No new validation or confidence
logic lives here.

A scope is committed only if it has zero blocking ValidationIssues
(Severity.ERROR) AND zero LOW-confidence Extracted fields. A scope
failing either check is rejected outright — not partially committed,
not committed-with-a-warning-flag. This is the intended hook for a
future review_ui: a rejected scope's CommitResult already carries enough
detail (which fields are LOW-confidence, which invariants failed) to
route a human to exactly what needs correcting, without this module
knowing anything about how that correction happens.

M5 Slice 5: storage is now an in-memory dict backed by an optional
on-disk mirror, using contract_model/serialization.py (M5 Slice 4).
Both commit_scope() and get_committed_scope() take an optional
storage_dir; omitting it (every pre-existing call site) reproduces M5
Slice 1's exact in-memory-only behavior, unchanged — this is additive,
not a breaking change. Passing storage_dir makes a successful commit
also write <storage_dir>/<scope_id>.json via serialize_scope(), and
makes a cache-miss on get_committed_scope() fall back to reading that
file via deserialize_scope() — the real "survives a process restart"
case. No default location is hardcoded anywhere here: storage_dir is
always caller-supplied, since nothing in this codebase gives evidence
for what a "right" default would be, and guessing one would be the same
silent invention Part 5 forbids adapters from doing to contract data,
applied to infrastructure instead. A rejected scope is still never
written to disk, the same way it was never added to the in-memory
cache — persistence only ever applies to what already passed the gate.

Re-committing an already-committed scope's id simply replaces the
stored version (both the in-memory entry and, if storage_dir is given,
the on-disk file) — the ordinary behavior a dict-backed store and a
plain file write already give for free, not new logic.

M6 Slice 2: list_committed_scope_ids() adds enumeration, needed by the
CLI's `list` command — a fresh process's in-memory cache starts empty,
so a CLI invocation needs a real way to see what's already committed on
disk, not just what it happens to commit in the same run. Same
storage_dir discipline as everything else here: omitting it only
reflects the in-memory cache, never silently falls back to disk.

M6 Slice 3: save_draft_scope()/load_draft_scope()/discard_draft_scope()
close the real gap Slice 2 surfaced: a rejected scope, before this, only
existed in the caller's own process memory — lost the moment that
process exited, making a CLI-driven review/correct loop across separate
invocations impossible. commit_scope() now saves a draft on rejection
(storage_dir given) and discards it on a later successful commit.
Deliberately kept in a drafts/ subdirectory, separate from committed
scopes' <scope_id>.json files — "committed" and "draft" must never be
confused by filename alone. Every rejection now produces a draft, not
just LOW-confidence-field rejections, including a pure blocking-
validation-error rejection review_ui can't actually act on (its
review_ui.list_review_items() only surfaces LOW-confidence fields) — a
deliberate, honest choice: the CLI's review command will show "0 fields
need review" alongside the real validation issue count in that case,
never hiding that the scope was still rejected for a different reason.

Engineering Infrastructure Slice: every write to disk (a committed
scope's file, a draft's file) now goes through _atomic_write() --
write to a temp file in the same directory, then os.replace() into
place. This was this project's own full assessment's top-flagged risk,
deferred twice in favor of product features (M6 Slices 4-5) since
nothing had exercised it yet -- addressed now under the same
"inspect the whole project, find the highest real value" mandate that
led to the PDF page cache. Before this, a write used a plain open(path,
"w"): a crash or an interrupted process mid-write could leave a
truncated, corrupt JSON file behind, and a reader (this process or a
genuinely different one) could observe that partial file. os.replace()
is atomic on the same filesystem (POSIX and Windows both) -- a reader
now only ever sees the complete previous version or the complete new
version, never an in-between state. Deliberately scoped to atomicity
only, not full write-write mutual exclusion (a lock file, timeout
handling): two genuinely concurrent commits to the same scope id still
resolve last-write-wins, which is a real, smaller, separate design
question -- not attempted here without more specific evidence of the
exact concurrency pattern to design against, the same restraint this
project has applied to every other unevidenced shape.
"""

from __future__ import annotations
import contextlib
import os
import tempfile
import threading
from dataclasses import dataclass, field
from typing import Optional

try:
    import fcntl
    _HAS_FCNTL = True
except ImportError:  # Windows has no fcntl; documented limitation below
    _HAS_FCNTL = False

from contract_platform.contract_model.entities import ContractScope, iter_low_confidence
from contract_platform.contract_model.serialization import serialize_scope, deserialize_scope
from contract_platform.validation.invariants import validate, has_blocking_errors, ValidationIssue


def _atomic_write(path: str, content: str) -> None:
    """Writes content to path atomically: writes to a temp file in the
    same directory first, then os.replace()s it into place. A reader (in
    this process or a genuinely different one) can never observe a
    partially written file — it sees either the complete previous
    version or the complete new one, never a truncated intermediate
    state. Same-directory placement matters: os.replace() is only
    atomic when source and destination are on the same filesystem, which
    a same-directory temp file guarantees without needing to know
    anything about the caller's filesystem layout."""
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp_path, path)
    except BaseException:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


_process_locks: dict[str, threading.Lock] = {}
_process_locks_guard = threading.Lock()


def _get_process_lock(key: str) -> threading.Lock:
    with _process_locks_guard:
        if key not in _process_locks:
            _process_locks[key] = threading.Lock()
        return _process_locks[key]


@contextlib.contextmanager
def scope_lock(scope_id: str, storage_dir: Optional[str] = None):
    """Serializes every read-modify-write against one scope id.

    The exact gap the atomic-writes slice's own docstring named and
    deliberately left open: two genuinely concurrent corrections to the
    same scope_id -- both load the same draft, apply *different* edits,
    then both call commit_scope(). _atomic_write() alone guarantees each
    individual write lands whole, but says nothing about which write
    happens last; whichever commit wins overwrites the other's edit,
    and that caller's own request still reports success -- a silently
    lost correction, not a crash.

    Two layers, because the process model differs by how this runs:
    - A threading.Lock, keyed by (storage_dir, scope_id), covers
      same-process concurrency: multiple threads inside one gunicorn
      worker, or two callers in the same test process.
    - If storage_dir is given, an flock() on a per-scope lock file
      under <storage_dir>/.locks/ additionally covers cross-process
      concurrency: gunicorn's default multi-worker model, or two
      separate CLI invocations racing on the same on-disk scope. A
      threading.Lock alone is invisible across process boundaries and
      would not protect that case, which is exactly the deployed
      shape this project now runs in (see api/app.py).

    Without storage_dir (in-memory-only mode, the CLI's own long-
    standing default), only the threading layer applies -- there is no
    file to lock, and no cross-process case is possible without
    persisted state to race over in the first place.

    fcntl is POSIX-only; on a platform without it (Windows), the
    cross-process layer is skipped and only same-process protection
    holds -- documented here rather than silently degraded, since this
    project's only real deployment target (the Dockerfile) is Linux.
    """
    key = f"{storage_dir or ''}:{scope_id}"
    proc_lock = _get_process_lock(key)
    proc_lock.acquire()
    try:
        if storage_dir is not None and _HAS_FCNTL:
            lock_dir = os.path.join(storage_dir, ".locks")
            os.makedirs(lock_dir, exist_ok=True)
            lock_path = os.path.join(lock_dir, f"{scope_id}.lock")
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
        else:
            yield
    finally:
        proc_lock.release()


@dataclass
class CommitResult:
    committed: bool
    scope_id: str
    validation_issues: list[ValidationIssue] = field(default_factory=list)
    low_confidence_fields: list[tuple[str, str]] = field(default_factory=list)  # (entity_id, field_name)


_COMMITTED_SCOPES: dict[str, ContractScope] = {}


def _scope_file_path(storage_dir: str, scope_id: str) -> str:
    return os.path.join(storage_dir, f"{scope_id}.json")


def _draft_file_path(storage_dir: str, scope_id: str) -> str:
    return os.path.join(storage_dir, "drafts", f"{scope_id}.json")


def save_draft_scope(scope: ContractScope, storage_dir: str) -> None:
    """Persists a rejected (not-yet-committable) scope, so a caller can
    come back later -- in a different process, e.g. a fresh CLI
    invocation -- and act on its review items. Kept in a drafts/
    subdirectory under storage_dir, deliberately separate from committed
    scopes' <scope_id>.json files, so "is this id committed?" and "is
    this id a pending draft?" can never be confused by filename alone."""
    path = _draft_file_path(storage_dir, scope.id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    _atomic_write(path, serialize_scope(scope))


def load_draft_scope(scope_id: str, storage_dir: str) -> Optional[ContractScope]:
    """Returns the saved draft for this id, if any. No in-memory cache
    for drafts (unlike committed scopes) -- a draft only exists to be
    corrected and re-committed, not queried repeatedly, so there's no
    evidenced need for one."""
    path = _draft_file_path(storage_dir, scope_id)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return deserialize_scope(f.read())


def discard_draft_scope(scope_id: str, storage_dir: str) -> None:
    """Removes a saved draft, if any. Safe to call on an id with no
    draft (a no-op) -- callers don't need to check existence first."""
    path = _draft_file_path(storage_dir, scope_id)
    if os.path.exists(path):
        os.remove(path)


def commit_scope(scope: ContractScope, storage_dir: Optional[str] = None) -> CommitResult:
    """Attempts to commit a draft ContractScope. Rejects if either check
    fails; only stores the scope (in memory, and on disk if storage_dir
    is given) if both pass.

    On rejection, if storage_dir is given, the scope is saved as a draft
    (save_draft_scope) — the real mechanism a CLI review/correct loop
    needs, since a rejected scope was previously only held in the
    caller's own process memory and lost the moment that process exited.
    On success, any stale draft for this scope id is discarded — once
    committed, it's no longer a pending draft.

    Uses entities.iter_low_confidence() (not an inline confidence ==
    LOW filter) so the commit gate's rejection decision can never
    silently drift from review_ui.list_review_items()'s definition of
    "which fields need review" — both now read the one shared
    definition."""
    issues = validate(scope)
    low_confidence_fields = [
        (entity_id, field_name)
        for entity_id, field_name, extracted in iter_low_confidence(scope)
    ]

    if has_blocking_errors(issues) or low_confidence_fields:
        if storage_dir is not None:
            save_draft_scope(scope, storage_dir)
        return CommitResult(
            committed=False, scope_id=scope.id,
            validation_issues=issues, low_confidence_fields=low_confidence_fields,
        )

    _COMMITTED_SCOPES[scope.id] = scope
    if storage_dir is not None:
        os.makedirs(storage_dir, exist_ok=True)
        _atomic_write(_scope_file_path(storage_dir, scope.id), serialize_scope(scope))
        discard_draft_scope(scope.id, storage_dir)

    return CommitResult(committed=True, scope_id=scope.id, validation_issues=issues, low_confidence_fields=[])


def get_committed_scope(scope_id: str, storage_dir: Optional[str] = None) -> Optional[ContractScope]:
    """Returns the committed scope for this id, if any. Checks the
    in-memory cache first; if storage_dir is given and the id isn't in
    the cache, falls back to reading <storage_dir>/<scope_id>.json — the
    real recovery path after a process restart, where the in-memory
    cache starts empty. Without storage_dir, a cache miss is always
    None; this never silently reads from an implicit default location."""
    if scope_id in _COMMITTED_SCOPES:
        return _COMMITTED_SCOPES[scope_id]

    if storage_dir is not None:
        path = _scope_file_path(storage_dir, scope_id)
        if os.path.exists(path):
            with open(path) as f:
                scope = deserialize_scope(f.read())
            _COMMITTED_SCOPES[scope_id] = scope  # repopulate the cache
            return scope

    return None


def list_committed_scope_ids(storage_dir: Optional[str] = None) -> list[str]:
    """Every currently-committed scope id: the in-memory cache's keys,
    unioned with (if storage_dir is given) every <scope_id>.json file
    found there — the real "what's out there" view a fresh process (an
    empty in-memory cache) needs, the same reasoning get_committed_scope's
    disk fallback already follows. Without storage_dir, this never
    silently reflects disk-only entries, same as get_committed_scope.
    Sorted for stable, predictable output."""
    ids = set(_COMMITTED_SCOPES.keys())
    if storage_dir is not None and os.path.isdir(storage_dir):
        for filename in os.listdir(storage_dir):
            if filename.endswith(".json"):
                ids.add(filename[: -len(".json")])
    return sorted(ids)
