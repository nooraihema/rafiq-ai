"""
The Anex Semantic Adapter — translates Anex/DMCC raw page text (from
document_parser) into a draft ContractScope.

M2 exists to prove the architecture survives a structurally different TO
than EXIM: Anex keys its base rates off date ranges *within a market*
(Market is a first-class entity precisely because of this East European vs.
Russia/CIS split), expresses room categories as Supplements layered on one
"Promo Room" base, and writes its child pricing as prose ("Double Room
Rate + 50 % P.P IN DBL") instead of numeric table columns.

Per architecture Part 5, same discipline as the EXIM adapter: every value
carries ConfidenceLevel + Provenance, Calculation values are built as
Expression trees, ambiguity is surfaced rather than resolved, and this
module never imports pricing_engine or review_ui.

M2 scope: builds a draft ContractScope containing only the "Promo Room"
product (base double-occupancy pricing) across every date range in both
markets, plus the one Children Policy clause the roadmap calls out
explicitly: "02 Adult + 02 Children (06-12.99): Double Room Rate + 50 %
P.P IN DBL". Standard/Superior/Deluxe/Family/Suite supplements, the other
10 Children Policy rows, and the Min-node "single+2child capped at double"
clause (which needs a modeled Single Room to compare against) are real,
parseable data -- deferred to M4 (full coverage), not this walking
skeleton's job.

Foundation Hardening II update: the CHILD_POLICY rule below now carries a
structured AgeCondition (06-12.99) instead of only living in the
free-text label -- this resolves the specific gap the original M2 note
flagged (PricingRule had no structured age-band field).

M4 (post-Slice-4): Triple Reduction / 04th Room Reduction Per Person
columns (real per-adult-slot amounts, parsed since M2 alongside PPPN but
never built) are now real SUPPLEMENT PricingRules, reusing the exact
applies_to_pax_number mechanism EXIM Slice 2 built -- zero pricing_engine
or Contract Model changes. Single Supplement is deliberately still not
modeled as a PricingRule -- see the comment at its call site in
build_contract_scope for why (a real semantic mismatch with what
applies_to_pax_number means for the other two, not an oversight).

M4 (Release Period slice): the real "release" column (already matched
by RATE_ROW_RE since M2, never carried past the match) is now a real
ReleaseRule Restriction per rate row -- a Model type present since M0
that no adapter had built until now. Scoped per-Rate
(applies_to_rate_id), not contract-wide like EXIM's MinMaxStay, since
the value is printed on every individual rate row. The "rooms"
allocation count in the same column is deliberately not built -- no
Model concept exists for room allocation counts yet.
"""

from __future__ import annotations
from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, Market, RoomType, Occupancy, Season, Rate,
    PricingRule, AgeCondition, ContractScope, Extracted, Provenance, ReleaseRule,
)
from contract_platform.contract_model.expressions import RateRef, Add, Subtract, PercentOf, Constant
from contract_platform.contract_model.vocabulary import (
    ConfidenceLevel, RateBasis, MealPlan, RuleKind, CalculationUnit, GuestType,
)
from contract_platform.document_parser.pdf_reader import RawPage, read_pdf_pages
from contract_platform.semantic_adapters.anex import vocabulary as vocab


class AnexAdapterError(Exception):
    pass


def _hi(value, page_number: int, raw_text: str, method: str, note: str = "") -> Extracted:
    return Extracted(
        value=value,
        confidence=ConfidenceLevel.HIGH,
        provenance=Provenance(page_number=page_number, raw_text=raw_text, extraction_method=method),
        source_note=note or None,
    )


def parse_hotel_and_tour_operator(pages: list[RawPage]) -> tuple[str, str]:
    import re
    for page in pages:
        to_m = re.search(r'FIRST PARTY:\s*(.+?)\.', page.text)
        hotel_m = re.search(r'HOTEL NAME:\s*(.+?)\s+Official Category', page.text)
        if to_m and hotel_m:
            return hotel_m.group(1).strip(), to_m.group(1).strip()
    raise AnexAdapterError("Could not find hotel name / tour operator identity on page 1.")


def parse_contract_validity(pages: list[RawPage]) -> tuple[date, date, int]:
    for page in pages:
        m = vocab.CONTRACT_VALIDITY_RE.search(page.text)
        if m:
            return (
                vocab.parse_anex_date(m.group("start")),
                vocab.parse_anex_date(m.group("end")),
                page.page_number,
            )
    raise AnexAdapterError("Could not find 'The Contract Validity' clause.")


def parse_room_rate_rows(pages: list[RawPage]) -> list[dict]:
    """Walks every page looking for market-header transitions and rate-date
    rows, in document order, carrying the 'current market' across a page
    boundary -- the Russia & CIS table's rows continue onto the next page
    without repeating their own header, which is exactly why this can't be
    done per-page in isolation."""
    rows: list[dict] = []
    current_market: str | None = None

    for page in pages:
        events = []
        for m in vocab.MARKET_HEADER_RE.finditer(page.text):
            events.append((m.start(), "header", m.group(0)))
        for m in vocab.RATE_ROW_RE.finditer(page.text):
            events.append((m.start(), "row", m))
        events.sort(key=lambda e: e[0])

        for _, kind, payload in events:
            if kind == "header":
                current_market = vocab.MARKET_NAME_MAP.get(payload, payload)
            else:
                if current_market is None:
                    continue  # a rate row before any market header is unattributable; skip
                m = payload
                rows.append({
                    "market": current_market,
                    "start_date": vocab.parse_anex_date(m.group("start")),
                    "end_date": vocab.parse_anex_date(m.group("end")),
                    "pppn": float(m.group("pppn")),
                    "single_supp_pct": float(m.group("single_supp_pct")),
                    "triple_reduction": float(m.group("triple_reduction")),
                    "fourth_reduction": float(m.group("fourth_reduction")),
                    "release": int(m.group("release")),
                    "page_number": page.page_number,
                    "raw_text": m.group(0),
                })
    if not rows:
        raise AnexAdapterError("No Room Rates rows found.")
    return rows


def parse_promo_room_occupancy(pages: list[RawPage]) -> tuple[list[tuple[int, int]], int, str]:
    """Returns ([(adults, children), ...], page_number, raw_line) for the
    'Promo Room' row of the Room Type/Supplement table. Only the combos
    explicitly printed in the Maximum Occupancy cell are modeled -- Anex's
    Minimum Occupancy column (single-adult / no-child cases) is not
    auto-expanded into additional combos here; that would be inventing
    data the document doesn't spell out, which Part 5 forbids adapters
    from doing."""
    for page in pages:
        m = vocab.PROMO_ROOM_ROW_RE.search(page.text)
        if m:
            combos = []
            for token in m.group("combo").split(" OR "):
                cm = vocab.OCCUPANCY_COMBO_TOKEN_RE.search(token)
                if cm:
                    adults = int(cm.group("adults"))
                    children = int(cm.group("children")) if cm.group("children") else 0
                    combos.append((adults, children))
            return combos, page.page_number, m.group(0)
    raise AnexAdapterError("Could not find the 'Promo Room' row in the Room Type/Supplement table.")


def parse_double_room_plus_child_clause(pages: list[RawPage]) -> tuple[dict, int]:
    """Locates specifically the '02 Adult + 02 Children (06-12.99): Double
    Room Rate + 50% P.P IN DBL' row -- the one clause M2 targets. Every
    other Children Policy row is real, parseable data (proven by the
    exhaustive regex test against all 11 rows) but out of scope for the
    RoomTypes M2 models; deferred to M4."""
    for page in pages:
        for m in vocab.CHILDREN_POLICY_ROW_RE.finditer(page.text):
            if m.group("room_type") != "Double Room":
                continue
            calc_m = vocab.CALCULATION_PHRASE_RE.match(m.group("calculation"))
            if not calc_m or not calc_m.group("plus_50"):
                continue
            if "06" not in m.group("ages"):
                continue
            return m.groupdict(), page.page_number
    raise AnexAdapterError("Could not find the 'Double Room Rate + 50% P.P IN DBL' clause.")


def build_contract_scope(pdf_path: str) -> ContractScope:
    """The adapter's main entry point: PDF path in, draft ContractScope out.

    Models the 'Promo Room' product only (M2 scope) across every date
    range in both markets, plus one PricingRule instance per season for
    the '2 Adult + 2 Children (06-12.99): Double Room Rate + 50% P.P IN
    DBL' clause -- the calculation necessarily needs one instance per
    season because its Expression references that season's specific Rate
    id, not because of any Anex-specific reason."""
    pages = read_pdf_pages(pdf_path)

    hotel_name, to_name = parse_hotel_and_tour_operator(pages)
    contract_start, contract_end, validity_page = parse_contract_validity(pages)
    rate_rows = parse_room_rate_rows(pages)
    occupancy_combos, occ_page, occ_raw = parse_promo_room_occupancy(pages)
    child_clause, child_clause_page = parse_double_room_plus_child_clause(pages)

    hotel = Hotel(name=hotel_name, location="Marsa Alam, Red Sea")
    tour_operator = TourOperator(name=to_name)

    scope = ContractScope(
        hotel=hotel, tour_operator=tour_operator,
        valid_from=contract_start, valid_to=contract_end, currency="USD",
    )

    markets_by_name = {}
    for market_name in sorted({row["market"] for row in rate_rows}):
        market = Market(name=market_name)
        markets_by_name[market_name] = market
        scope.markets.append(market)

    promo_room = RoomType(
        hotel_id=hotel.id, canonical_code="PROMO", display_name="Promo Room",
        aliases=["Promo Room"],
    )
    for adults, children in occupancy_combos:
        promo_room.valid_occupancies.append(Occupancy(
            adults=_hi(adults, occ_page, occ_raw, "regex.anex_promo_room_row"),
            children=_hi(children, occ_page, occ_raw, "regex.anex_promo_room_row"),
            infants=_hi(0, occ_page, occ_raw, "regex.anex_promo_room_row",
                        "Infants priced free 0-1.99 additional to all room types; not part of the occupancy combo grid."),
        ))
    scope.room_types.append(promo_room)

    for row in rate_rows:
        market = markets_by_name[row["market"]]
        season = Season(
            label=f"{row['market']} {row['start_date'].isoformat()}\u2013{row['end_date'].isoformat()}",
            start_date=_hi(row["start_date"], row["page_number"], row["raw_text"], "regex.anex_rate_row"),
            end_date=_hi(row["end_date"], row["page_number"], row["raw_text"], "regex.anex_rate_row"),
            market_id=market.id,
        )
        scope.seasons.append(season)

        rate = Rate(
            room_type_id=promo_room.id, season_id=season.id, market_id=market.id,
            meal_plan=MealPlan.ALL_INCLUSIVE, basis=RateBasis.PER_PERSON_PER_NIGHT, currency="USD",
            amount=_hi(row["pppn"], row["page_number"], row["raw_text"], "regex.anex_rate_row",
                       f"Per Person in DBL column, {row['market']} market"),
        )
        scope.rates.append(rate)

        # Real, already-regex-matched data (RATE_ROW_RE's own "release"
        # group, e.g. "15 rooms 05 release"), never carried past the
        # match until now. Maps directly onto ReleaseRule -- a
        # Restriction type present since M0 (alongside MinMaxStay) that
        # no adapter has built until this slice. Scoped to this specific
        # Rate (applies_to_rate_id), since the value is printed per rate
        # row, not once for the whole contract (unlike EXIM's contract-
        # wide MinMaxStay clause). The "rooms" allocation count in the
        # same column (15/10) is deliberately not built -- there is no
        # Model concept for room allocation/allotment counts, and adding
        # one would be a real Contract Model change with no evidence yet
        # forcing its shape.
        scope.restrictions.append(ReleaseRule(
            applies_to_rate_id=rate.id,
            days_before_arrival=_hi(row["release"], row["page_number"], row["raw_text"], "regex.anex_rate_row",
                                     f"Release column, {row['market']} market."),
        ))

        # Next M4 slice after Slice 4: Triple Reduction Per Person and 04th
        # Room Reduction Per Person are structurally identical to EXIM's
        # real AMR columns (M4 Slice 2) -- a flat per-night amount off the
        # base per-person rate for a specific numbered adult slot, true
        # regardless of party size as long as the party has that many
        # adults. Reuses PricingRule.applies_to_pax_number and
        # pricing_engine's existing positional consumption in
        # _adult_lines directly -- zero pricing_engine or Contract Model
        # changes.
        #
        # Single Supplement (60%) is real, parseable data (row["single_
        # supp_pct"], captured above) but deliberately NOT built as a
        # PricingRule here: applies_to_pax_number's established meaning
        # (proven by AMR and by triple/4th reduction above) is "this
        # numbered slot always gets this treatment regardless of total
        # party size." A single-occupancy supplement doesn't fit that
        # shape -- it only applies when the *entire* booking is 1 adult,
        # not "the booking's 1st adult in a party of any size." Modeling
        # it as applies_to_pax_number=1 would silently misapply it to the
        # first adult of a 3-adult booking. Flagged here rather than
        # forced into a field whose semantics don't actually match, per
        # the same discipline as every other "flagged, not acted on" note
        # in this README. (In today's real data this is moot in
        # practice -- Promo Room's valid_occupancies never include a
        # single-adult combo -- but the rule would still be wrong on
        # paper, so it isn't built.)
        scope.pricing_rules.append(PricingRule(
            kind=RuleKind.SUPPLEMENT, room_type_id=promo_room.id, season_id=season.id,
            label="3rd Adult Triple Reduction Per Person",
            applies_to_pax_number=3,
            calculation=Extracted(
                value=Subtract(RateRef(rate.id), Constant(row["triple_reduction"], CalculationUnit.USD)),
                confidence=ConfidenceLevel.HIGH,
                provenance=Provenance(page_number=row["page_number"], raw_text=row["raw_text"], extraction_method="regex.anex_rate_row"),
                source_note=f"Triple Reduction Per Person column, {row['market']} market.",
            ),
        ))
        scope.pricing_rules.append(PricingRule(
            kind=RuleKind.SUPPLEMENT, room_type_id=promo_room.id, season_id=season.id,
            label="4th Adult Room Reduction Per Person",
            applies_to_pax_number=4,
            calculation=Extracted(
                value=Subtract(RateRef(rate.id), Constant(row["fourth_reduction"], CalculationUnit.USD)),
                confidence=ConfidenceLevel.HIGH,
                provenance=Provenance(page_number=row["page_number"], raw_text=row["raw_text"], extraction_method="regex.anex_rate_row"),
                source_note=f"04th Room Reduction Per Person column, {row['market']} market.",
            ),
        ))

        calculation = Add(
            RateRef(rate.id),
            PercentOf(RateRef(rate.id), Constant(50, CalculationUnit.PERCENT)),
        )
        rule = PricingRule(
            kind=RuleKind.CHILD_POLICY, room_type_id=promo_room.id, season_id=season.id,
            label="02 Adult + 02 Children (06\u201312.99): Double Room Rate + 50 % P.P IN DBL",
            calculation=Extracted(
                value=calculation, confidence=ConfidenceLevel.HIGH,
                provenance=Provenance(page_number=child_clause_page, raw_text=str(child_clause), extraction_method="regex.anex_children_policy_row"),
                source_note="Children Policy & Family Plan table, Double Room row, '+ 50 % P.P IN DBL' clause.",
            ),
            # Foundation Hardening II: the clause is explicitly scoped to
            # children aged 06-12.99 ("2nd age range") -- previously real
            # but unrepresented data (see the M2 architectural note this
            # replaces); now expressed as a structural condition instead
            # of only living in the free-text label.
            applicability=[AgeCondition(
                role=GuestType.CHILD,
                min_age=Extracted(
                    value=6.0, confidence=ConfidenceLevel.HIGH,
                    provenance=Provenance(page_number=child_clause_page, raw_text=str(child_clause), extraction_method="regex.anex_children_policy_row"),
                    source_note="Children Policy & Family Plan table, age range '(06 \u2013 12.99)'.",
                ),
                max_age=Extracted(
                    value=12.99, confidence=ConfidenceLevel.HIGH,
                    provenance=Provenance(page_number=child_clause_page, raw_text=str(child_clause), extraction_method="regex.anex_children_policy_row"),
                    source_note="Children Policy & Family Plan table, age range '(06 \u2013 12.99)'.",
                ),
            )],
        )
        scope.pricing_rules.append(rule)

    return scope
