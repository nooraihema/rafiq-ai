"""
Anex's own vocabulary — structurally different from EXIM's (proving that
difference is the entire point of M2). Where EXIM keys everything off a
fixed room-code table, Anex keys its base rates off *date ranges within a
market*, expresses room categories as supplements layered on top of one
"Promo Room" base product, and writes its child pricing as prose sentences
("Double Room Rate + 50 % P.P IN DBL") rather than numeric columns.

Nothing here is general platform knowledge; none of it belongs in
document_parser or contract_model.
"""

from __future__ import annotations
import re
from datetime import date

# --- Contract-level validity --------------------------------------------

CONTRACT_VALIDITY_RE = re.compile(
    r'The Contract Validity\s*:\s*From\s+(?P<start>\d{2}\.\d{2}\.\d{4})\s+Till\s+(?P<end>\d{2}\.\d{2}\.\d{4})'
)

# --- Room Rates section ---------------------------------------------------
#
# Two markets, each with its own table of date-range rows:
# "01.05.2026 20.05.2026 68.00 USD 60% 2.00 USD 3.00 USD 15 rooms 05"
#  start        end       PPPN      single% triple-red  4th-red   rooms release

MARKET_HEADER_RE = re.compile(r'East market|Russia\s*&\s*CIS market')

RATE_ROW_RE = re.compile(
    r'^(?P<start>\d{2}\.\d{2}\.\d{4})\s+(?P<end>\d{2}\.\d{2}\.\d{4})\s+'
    r'(?P<pppn>[\d.]+)\s*USD\s+(?P<single_supp_pct>\d+)%\s+'
    r'(?P<triple_reduction>[\d.]+)\s*USD\s+(?P<fourth_reduction>[\d.]+)\s*USD\s+'
    r'(?P<rooms>\d+)\s*rooms\s+(?P<release>\d+)$',
    re.MULTILINE,
)

MARKET_NAME_MAP = {
    "East market": "East European",
    "Russia & CIS market": "Russia & CIS",
}

# --- Room Type / Supplement table -----------------------------------------
#
# "Promo Room - - - 01 2 ADL+2CHD OR 03ADL 2 2"
#  name         (no supplement)  min_occ  max-occupancy combos      cis east

PROMO_ROOM_ROW_RE = re.compile(
    r'^Promo Room\s+-\s+-\s+-\s+(?P<min_occ>\d+)\s+(?P<combo>.+?)\s+(?P<cis>\d+)\s+(?P<east>\d+)$',
    re.MULTILINE,
)

# One combo token: "2 ADL+2CHD" or "03ADL" (children part optional).
OCCUPANCY_COMBO_TOKEN_RE = re.compile(r'(?P<adults>\d+)\s*ADL(?:\+(?P<children>\d+)\s*CHD)?')

# --- Children Policy & Family Plan table -----------------------------------
#
# "02 Adult + 02 Children (06 – 12.99) Double Room Double Room Rate + 50 % P.P IN DBL"
#
# room_type is matched non-greedily up to the first literal "Room" token,
# which is exactly where the room-type label ends in every row of this
# table (verified against all 11 real rows, including multi-word labels
# like "Family Quadruple Room").

CHILDREN_POLICY_ROW_RE = re.compile(
    r'^(?P<adults>\d+)\s+Adult(?:s)?\s+\+\s+(?P<children>\d+)\s+Child(?:ren)?\s*'
    r'\(\s*(?P<ages>[^)]+)\)\s+(?P<room_type>.+?\bRoom)\s+(?P<calculation>.+)$',
    re.MULTILINE,
)

# Recognizes "<Label> Room Rate" or "<Label> Room Rate + 50 % P.P IN DBL".
# Anything else in the Calculation column is intentionally left unresolved
# (Part 5: adapters never silently resolve what they can't confidently parse).
CALCULATION_PHRASE_RE = re.compile(
    r'^(?P<base_label>.+?) Rate(?P<plus_50>\s*\+\s*50\s*%\s*P\.P\s*IN\s*DBL)?$'
)


def parse_anex_date(raw: str) -> date:
    """Anex dates are DD.MM.YYYY."""
    day, month, year = raw.split(".")
    return date(int(year), int(month), int(day))
