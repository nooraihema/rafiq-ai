"""
The EXIM Semantic Adapter — translates EXIM/DER-Touristik/RMF-template raw
page text (from document_parser) into a draft ContractScope.

This module is where all EXIM-specific interpretation lives: which text
pattern means "PPPN", how "1/3" splits into an adult range, how "//" joins
occupancy segments. document_parser has already handed us plain page text
with zero business meaning attached; contract_model has no idea EXIM
exists. This file is the only bridge between the two.

Per architecture Part 5:
  - Every value we produce carries a ConfidenceLevel and Provenance.
  - We build Calculation values as Expression trees directly, never strings.
  - We never resolve an ambiguity ourselves — anything we can't parse
    cleanly becomes a LOW-confidence value with a source_note, for a human
    to resolve via review_ui.
  - We never import pricing_engine or review_ui.

M1 scope: builds a draft ContractScope containing only the RoomType(s)
named in `room_codes` (default: just DR01), plus their PPPN/SOPN Rates,
their resolved Occupancy combinations, and the contract-level Season/dates.

M4 Slice 2: AMR ("3A AmR pN" / "4A AmR pN") columns are now built into
real SUPPLEMENT PricingRules — the platform's first real non-CHILD_POLICY
rule, and the trigger for calculator.py's rule-consumption generalization.

M4 Slice 3: CHILD_PCT ("1C2A 1R %R PN" / "1C2A 2R %R PN" / "2C2A ...")
columns are now built into real CHILD_POLICY PricingRules — position
(1st/2nd child, `child_n`) reuses `PricingRule.applies_to_pax_number`
(added in Slice 2 for adults; no new Model field needed), and age band
(`age_range_n`, 1 or 2) becomes an `AgeCondition` sourced from the
Units row's `age_band_1`/`age_band_2` columns.

M4 Slice 4: the contract-level Min/Max Stay clause (page 5: "3/999
nights") is now built into a real MinMaxStay Restriction, scoped to the
whole ContractScope (the clause's own real scope -- printed once, "All",
not per room), and enforced as a booking-time check in pricing_engine.

M4 (Deposit Payments slice): page 6's real deposit schedule ("The Tour
Operator will pay to the Supplier a deposit of X USD at latest on Y",
4 lines) is now built into real PaymentRule entries -- a Model type
present since M0 that no adapter had built. B2B contract-financial
metadata, not customer-booking-facing, so unlike every other Restriction
built so far this has no pricing_engine consumption path.
"""

from __future__ import annotations
from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, RoomType, Occupancy, Season, Rate, PricingRule,
    ContractScope, Extracted, Provenance, AgeCondition, MinMaxStay, PaymentRule,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel, RateBasis, RuleKind, CalculationUnit, GuestType, PaymentTrigger
from contract_platform.contract_model.expressions import RateRef, Subtract, Constant, PercentOf
from contract_platform.document_parser.pdf_reader import RawPage, read_pdf_pages
from contract_platform.semantic_adapters.exim import vocabulary as vocab


class EximAdapterError(Exception):
    """Raised when a document doesn't match EXIM's expected shape closely
    enough to proceed at all — as opposed to a single ambiguous value,
    which becomes a LOW-confidence Extracted instead of an exception."""
    pass


def _hi(value, page_number: int, raw_text: str, method: str, note: str = "") -> Extracted:
    return Extracted(
        value=value,
        confidence=ConfidenceLevel.HIGH,
        provenance=Provenance(page_number=page_number, raw_text=raw_text, extraction_method=method),
        source_note=note or None,
    )


def find_units_page(pages: list[RawPage]) -> RawPage:
    for page in pages:
        if "Units" in page.text and "Room Description" in page.text:
            return page
    raise EximAdapterError("No page found containing the Units table.")


def parse_units_rows(units_page: RawPage) -> dict[str, dict]:
    """Returns {room_code: {parsed fields}} for every row in the Units table."""
    rows: dict[str, dict] = {}
    for m in vocab.UNITS_ROW_RE.finditer(units_page.text):
        code = m.group("code")
        rows[code] = {
            "item_no": m.group("item_no"),
            "code": code,
            "name": m.group("name"),
            "meal": m.group("meal"),
            "adult_min": int(m.group("adult_min")),
            "adult_max": int(m.group("adult_max")),
            "child_min": int(m.group("child_min")),
            "child_max": int(m.group("child_max")),
            "age_band_1": m.group("age_band_1"),
            "age_band_2": m.group("age_band_2"),
            "raw_line": m.group(0),
        }
    return rows


def parse_room_occupancy_combos(units_page: RawPage) -> dict[str, list[tuple[int, int]]]:
    """Parses the free-text 'Room Occupancy:' block into
    {room_code: [(adults, children), ...]}. A room code can appear in more
    than one segment in the source text; later segments win, matching a
    human reading top-to-bottom."""
    text = units_page.text
    start = text.find("Room Occupancy:")
    if start == -1:
        return {}
    end = text.find("Allocation & Release", start)
    if end == -1:
        end = len(text)
    block = text[start + len("Room Occupancy:"):end].replace("\n", " ")

    result: dict[str, list[tuple[int, int]]] = {}
    for segment in block.split("//"):
        segment = segment.strip()
        if not segment:
            continue
        m = vocab.ROOM_OCCUPANCY_SEGMENT_RE.match(segment)
        if not m:
            continue
        codes = [c.strip() for c in m.group("codes").split("/")]
        combos = []
        for combo in m.group("combos").split(","):
            combo = combo.strip()
            if "+" not in combo:
                continue
            adults_s, children_s = combo.split("+")
            combos.append((int(adults_s), int(children_s)))
        for code in codes:
            result[code] = combos
    return result


def parse_min_max_stay(pages: list[RawPage]) -> dict | None:
    """Locates and parses EXIM's contract-level 'Min/Max Stay' clause
    (real data, page 5: 'Start Date End Date Days Min/Max Arrival Days
    Departure Days' followed by one data row, e.g. '01.05.26 31.10.26 All
    3/999 ...'). The clause is printed once for the whole contract ('All'
    -- not per room), so this is called once in build_contract_scope,
    independent of room_codes, not per room.

    Reuses RATE_DATA_LINE_RE (a generic date/date/days/rest line shape,
    not rate-specific) against the data row, then MIN_MAX_STAY_RE (defined
    since M1, unused until now) against the 'rest' field -- both patterns
    this file already knows, rather than a new special-purpose regex for
    a shape it can already parse. Returns None if the section isn't
    present -- a real absence, not a parse failure."""
    for page in pages:
        idx = page.text.find("Min/Max Stay")
        if idx == -1:
            continue
        for line in page.text[idx:].split("\n"):
            data_m = vocab.RATE_DATA_LINE_RE.match(line.strip())
            if not data_m:
                continue
            mm_m = vocab.MIN_MAX_STAY_RE.search(data_m.group("rest"))
            if not mm_m:
                continue
            return {
                "min_nights": int(mm_m.group("min")),
                "max_nights": int(mm_m.group("max")),
                "page_number": page.page_number,
                "raw_text": line.strip(),
            }
    return None


def parse_deposit_payments(pages: list[RawPage]) -> list[dict]:
    """Locates EXIM's real page-6 deposit schedule ('The Tour Operator
    will pay to the Supplier a deposit of <amount> USD at latest on
    <date>' -- 4 identically-shaped lines in the Turnover Guarantee
    Conditions box). Printed once for the whole contract, not per room,
    so this is called once in build_contract_scope, independent of
    room_codes. Amounts use European-style thousands separators
    ("1.000.000" = 1,000,000) -- stripped here, not treated as a decimal
    point. Returns an empty list if the section isn't present -- a real
    absence, not a parse failure."""
    payments = []
    for page in pages:
        for m in vocab.DEPOSIT_PAYMENT_RE.finditer(page.text):
            day, month, year = m.group("date").split(".")
            payments.append({
                "amount": float(m.group("amount").replace(".", "")),
                "deadline_date": date(int(year), int(month), int(day)),
                "page_number": page.page_number,
                "raw_text": m.group(0),
            })
    return payments


def find_rate_block_for_room(pages: list[RawPage], room_code: str) -> tuple[RawPage, str]:
    """Locates the Rates sub-block for one room code, searching every page.

    Real-data correction (found extending EXIM to full room coverage,
    M4), in two parts:

    1. The room-code header line ("N. CODE - description") also appears,
       unchanged, in the Units, Facilities, and Allocation sections --
       ROOM_RATE_HEADER_RE is intentionally loose (it has to match all of
       these, since the adapter reuses it for the Units table too via a
       different function) and cannot on its own tell a Rates-section
       occurrence from any other. Every candidate block is therefore
       checked for PPPN/SOPN content before being accepted -- a real
       rate block always has one, no other section does.
    2. A page-level pre-filter that used to gate this search by the
       literal substring "Rates" silently skipped continuation pages
       (verified: the Rates table continues from page 3 onto page 4 in
       the real contract, e.g. FR04's row, without re-printing that
       section header). Removed entirely, superseded by the
       content-based check in (1), which doesn't depend on page-level
       text at all."""
    for page in pages:
        headers = list(vocab.ROOM_RATE_HEADER_RE.finditer(page.text))
        for i, h in enumerate(headers):
            if h.group("code") != room_code:
                continue
            block_start = h.end()
            block_end = headers[i + 1].start() if i + 1 < len(headers) else len(page.text)
            block = page.text[block_start:block_end].strip()
            if "PPPN" in block or "SOPN" in block:
                return page, block
    raise EximAdapterError(f"No Rates block found for room code {room_code!r}.")


def parse_rate_block(block: str) -> dict:
    """Parses one room's Rates block text into start/end dates, days, and a
    list of (column_code, value) pairs. column_code is one of:
    ('PPPN', None), ('SOPN', None), ('AMR', n), ('CHILD_PCT', (child_n, min_adults, age_range))."""
    lines = [ln for ln in block.split("\n") if ln.strip()]
    header_line = next((ln for ln in lines if "PPPN" in ln or "SOPN" in ln), None)
    data_line = next((ln for ln in lines if vocab.RATE_DATA_LINE_RE.match(ln)), None)
    if header_line is None or data_line is None:
        raise EximAdapterError(f"Could not locate header/data lines in rate block: {block!r}")

    codes = []
    for m in vocab.RATE_COLUMN_CODE_RE.finditer(header_line):
        if m.group("pppn"):
            codes.append(("PPPN", None))
        elif m.group("sopn"):
            codes.append(("SOPN", None))
        elif m.group("amr"):
            codes.append(("AMR", int(m.group("amr_n"))))
        elif m.group("childpct"):
            codes.append(("CHILD_PCT", (int(m.group("child_n")), int(m.group("child_adults")), int(m.group("child_range")))))

    data_m = vocab.RATE_DATA_LINE_RE.match(data_line)
    values_raw = data_m.group("rest").split()
    values = [float(v.replace(",", ".")) for v in values_raw]

    if len(values) != len(codes):
        raise EximAdapterError(
            f"Rate column/value count mismatch in block {block!r}: "
            f"{len(codes)} column codes vs {len(values)} values."
        )

    return {
        "start_date": vocab.parse_exim_date(data_m.group("start")),
        "end_date": vocab.parse_exim_date(data_m.group("end")),
        "days": data_m.group("days"),
        "columns": list(zip(codes, values)),
        "raw_header": header_line,
        "raw_data": data_line,
    }


def build_contract_scope(pdf_path: str, room_codes: list[str] | None = None) -> ContractScope:
    """The adapter's main entry point: PDF path in, draft ContractScope out.
    room_codes restricts which RoomTypes get built (default: DR01 only —
    the M1 walking-skeleton scope). Full-coverage extraction across every
    room in the contract is M4's job, not this one."""
    if room_codes is None:
        room_codes = ["DR01"]

    pages = read_pdf_pages(pdf_path)
    units_page = find_units_page(pages)
    units_rows = parse_units_rows(units_page)
    occupancy_combos = parse_room_occupancy_combos(units_page)

    hotel_name = "Amarina Jannah Resort & Aqua Park"
    contract_start, contract_end = None, None
    for page in pages:
        m = vocab.FOOTER_RE.search(page.text)
        if m:
            hotel_name = m.group("hotel").strip()
            contract_start = vocab.parse_exim_date(m.group("start"))
            contract_end = vocab.parse_exim_date(m.group("end"))
            break

    hotel = Hotel(name=hotel_name, location="Marsa Alam - North")
    tour_operator = TourOperator(name="EXIM S.A.")

    scope = ContractScope(
        hotel=hotel,
        tour_operator=tour_operator,
        valid_from=contract_start,
        valid_to=contract_end,
        currency="USD",
    )

    min_max_stay = parse_min_max_stay(pages)
    if min_max_stay is not None:
        scope.restrictions.append(MinMaxStay(
            applies_to_contract_scope_id=scope.id,
            min_nights=_hi(min_max_stay["min_nights"], min_max_stay["page_number"], min_max_stay["raw_text"],
                           "regex.exim_min_max_stay"),
            max_nights=_hi(min_max_stay["max_nights"], min_max_stay["page_number"], min_max_stay["raw_text"],
                           "regex.exim_min_max_stay"),
        ))

    # Real, cleanly-matched B2B contract metadata (the deposit schedule,
    # page 6) -- not a customer-booking-facing fact, so unlike every
    # other Restriction built so far, this has no pricing_engine
    # consumption path. PaymentRule.amount_calculation/deadline_date have
    # no Extracted wrapper in the Model (unlike every other field built
    # so far) -- built exactly as the dataclass is shaped, not embellished.
    for payment in parse_deposit_payments(pages):
        scope.payment_rules.append(PaymentRule(
            contract_scope_id=scope.id,
            trigger=PaymentTrigger.FIXED_DEADLINE,
            description=f"Deposit of {payment['amount']:,.0f} USD due {payment['deadline_date'].isoformat()}",
            amount_calculation=Constant(payment["amount"], CalculationUnit.USD),
            deadline_date=payment["deadline_date"],
        ))

    for room_code in room_codes:
        if room_code not in units_rows:
            raise EximAdapterError(f"Room code {room_code!r} not found in Units table.")
        units_row = units_rows[room_code]

        rate_page, rate_block = find_rate_block_for_room(pages, room_code)
        parsed_rates = parse_rate_block(rate_block)

        season = Season(
            label=f"{room_code} contract period",
            start_date=_hi(parsed_rates["start_date"], rate_page.page_number, parsed_rates["raw_data"], "regex.exim_rate_block"),
            end_date=_hi(parsed_rates["end_date"], rate_page.page_number, parsed_rates["raw_data"], "regex.exim_rate_block"),
        )
        scope.seasons.append(season)

        room = RoomType(
            hotel_id=hotel.id,
            canonical_code=room_code,
            display_name=units_row["name"],
            aliases=[units_row["name"]],  # EXIM's own room description text, verbatim
        )

        combos = occupancy_combos.get(room_code)
        if combos:
            for adults, children in combos:
                room.valid_occupancies.append(Occupancy(
                    adults=_hi(adults, units_page.page_number, units_row["raw_line"], "regex.exim_room_occupancy"),
                    children=_hi(children, units_page.page_number, units_row["raw_line"], "regex.exim_room_occupancy"),
                    infants=_hi(0, units_page.page_number, units_row["raw_line"], "regex.exim_room_occupancy",
                                "Infants not counted in the Room Occupancy combo grid; EXIM prices infants free 0-1.99 separately."),
                ))
        else:
            # Fall back to the Units row's adult/child min-max range if the
            # free-text combo block didn't cover this room — flagged LOW so
            # a human confirms exactly which combos are valid, per Part 5
            # ("never silently default a missing or unclear value").
            room.valid_occupancies.append(Occupancy(
                adults=Extracted(
                    value=units_row["adult_min"], confidence=ConfidenceLevel.LOW,
                    provenance=Provenance(page_number=units_page.page_number, raw_text=units_row["raw_line"], extraction_method="fallback.units_row_range"),
                    source_note="No explicit Room Occupancy combo list found for this room; derived only from the Adult/Child range column.",
                ),
                children=Extracted(
                    value=units_row["child_min"], confidence=ConfidenceLevel.LOW,
                    provenance=Provenance(page_number=units_page.page_number, raw_text=units_row["raw_line"], extraction_method="fallback.units_row_range"),
                    source_note="No explicit Room Occupancy combo list found for this room; derived only from the Adult/Child range column.",
                ),
                infants=_hi(0, units_page.page_number, units_row["raw_line"], "fallback.units_row_range"),
            ))

        scope.room_types.append(room)

        meal_plan = vocab.MEAL_BASIS_MAP[units_row["meal"]]
        pppn_rate = None
        for (col_code, col_detail), value in parsed_rates["columns"]:
            if col_code == "PPPN":
                pppn_rate = Rate(
                    room_type_id=room.id, season_id=season.id, meal_plan=meal_plan,
                    basis=RateBasis.PER_PERSON_PER_NIGHT, currency="USD",
                    amount=_hi(value, rate_page.page_number, parsed_rates["raw_data"], "regex.exim_rate_block",
                               f"PPPN column, header: {parsed_rates['raw_header']!r}"),
                )
                scope.rates.append(pppn_rate)
            elif col_code == "SOPN":
                scope.rates.append(Rate(
                    room_type_id=room.id, season_id=season.id, meal_plan=meal_plan,
                    basis=RateBasis.SINGLE_OCCUPANCY_PER_NIGHT, currency="USD",
                    amount=_hi(value, rate_page.page_number, parsed_rates["raw_data"], "regex.exim_rate_block",
                               f"SOPN column, header: {parsed_rates['raw_header']!r}"),
                ))
            elif col_code == "AMR":
                # M4 Slice 2: "3A AmR pN" / "4A AmR pN" -- a flat per-night
                # amount subtracted from PPPN, specifically for the
                # col_detail-th adult in the party (e.g. col_detail=3 means
                # this is the rate reduction for the 3rd adult, not a
                # discount on the whole booking). Requires the PPPN Rate
                # for this room/season, which the "PPPN" branch above
                # always builds first in the real data (confirmed: PPPN is
                # always the first column in every row parsed so far).
                if pppn_rate is None:
                    raise EximAdapterError(
                        f"AMR column found for room {room_code!r} before its PPPN column -- "
                        f"cannot build the reduction Expression without a base Rate to reference."
                    )
                nth_adult = col_detail
                ordinal = {1: "1st", 2: "2nd", 3: "3rd"}.get(nth_adult, f"{nth_adult}th")
                calculation = Subtract(RateRef(pppn_rate.id), Constant(value, CalculationUnit.USD))
                scope.pricing_rules.append(PricingRule(
                    kind=RuleKind.SUPPLEMENT, room_type_id=room.id, season_id=season.id,
                    label=f"{ordinal} Adult Amount Reduction",
                    applies_to_pax_number=nth_adult,
                    calculation=Extracted(
                        value=calculation, confidence=ConfidenceLevel.HIGH,
                        provenance=Provenance(page_number=rate_page.page_number, raw_text=parsed_rates["raw_data"],
                                               extraction_method="regex.exim_rate_block"),
                        source_note=f"{nth_adult}A AmR pN column, header: {parsed_rates['raw_header']!r}",
                    ),
                ))
            # CHILD_PCT columns are parsed (proven above) but not yet
            # modeled as PricingRule -- next M4 slice.
            elif col_code == "CHILD_PCT":
                # M4 Slice 3: "1C2A 1R %R PN" / "2C2A 2R %R PN" etc. --
                # child_n is the child's position in the party (1st/2nd
                # child), reusing the same applies_to_pax_number field
                # Slice 2 added for adults (no new Model field). age_range_n
                # (1 or 2) selects which Units-row age band this specific
                # rule targets -- the Units table already gives the age
                # bands for this room (age_band_1/age_band_2), so this
                # reuses that source rather than re-deriving it here.
                if pppn_rate is None:
                    raise EximAdapterError(
                        f"CHILD_PCT column found for room {room_code!r} before its PPPN column -- "
                        f"cannot build the reduction Expression without a base Rate to reference."
                    )
                child_n, child_adults, age_range_n = col_detail
                age_band_raw = units_row["age_band_1"] if age_range_n == 1 else units_row["age_band_2"]
                band_min_s, band_max_s = age_band_raw.split("-")
                ordinal = {1: "1st", 2: "2nd"}.get(child_n, f"{child_n}th")
                calculation = Subtract(
                    RateRef(pppn_rate.id),
                    PercentOf(RateRef(pppn_rate.id), Constant(value, CalculationUnit.PERCENT)),
                )
                scope.pricing_rules.append(PricingRule(
                    kind=RuleKind.CHILD_POLICY, room_type_id=room.id, season_id=season.id,
                    label=f"{ordinal} Child ({age_band_raw}): {value:g}% Reduction Per Night",
                    applies_to_pax_number=child_n,
                    calculation=Extracted(
                        value=calculation, confidence=ConfidenceLevel.HIGH,
                        provenance=Provenance(page_number=rate_page.page_number, raw_text=parsed_rates["raw_data"],
                                               extraction_method="regex.exim_rate_block"),
                        source_note=f"{child_n}C{child_adults}A {age_range_n}R %R PN column, header: {parsed_rates['raw_header']!r}",
                    ),
                    applicability=[AgeCondition(
                        role=GuestType.CHILD,
                        min_age=Extracted(
                            value=float(band_min_s), confidence=ConfidenceLevel.HIGH,
                            provenance=Provenance(page_number=units_page.page_number, raw_text=units_row["raw_line"],
                                                   extraction_method="regex.exim_units_row"),
                            source_note=f"Units table age band {age_range_n}: {age_band_raw!r}.",
                        ),
                        max_age=Extracted(
                            value=float(band_max_s), confidence=ConfidenceLevel.HIGH,
                            provenance=Provenance(page_number=units_page.page_number, raw_text=units_row["raw_line"],
                                                   extraction_method="regex.exim_units_row"),
                            source_note=f"Units table age band {age_range_n}: {age_band_raw!r}.",
                        ),
                    )],
                ))

    return scope
