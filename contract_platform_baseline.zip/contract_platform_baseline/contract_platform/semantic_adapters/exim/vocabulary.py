"""
EXIM's own vocabulary — the patterns and codes specific to how this one
Tour Operator's contracts (via DER Touristik / RMF templates) lay out
their Units and Rates tables. Nothing here is general platform knowledge;
none of it belongs in document_parser or contract_model.

If a second EXIM-family contract uses slightly different wording, this is
the only file that should need to change.
"""

from __future__ import annotations
import re
from datetime import date

from contract_platform.contract_model.vocabulary import MealPlan

# --- Units table -----------------------------------------------------------
#
# One row looks like:
# "1. DR01 - Double Room Garden View All Inclusive 1 2 1/3 0/2 Over Max Occ 2-6 7-14"
#  item  code  display name              meal      maxrdn ffpp adult child inf  age1 age2

UNITS_ROW_RE = re.compile(
    r'^(?P<item_no>\d+)\.\s+(?P<code>\S+)\s+-\s+(?P<name>.+?)\s+'
    r'(?P<meal>All Inclusive|Full Board|Half Board|Bed & Breakfast|Room Only)\s+'
    r'(?P<max_rdn>\d+)\s+(?P<ffpp>\d+)\s+'
    r'(?P<adult_min>\d+)/(?P<adult_max>\d+)\s+(?P<child_min>\d+)/(?P<child_max>\d+)\s+'
    r'(?P<infants>\S.*?)\s+(?P<age_band_1>\d+-\d+)\s+(?P<age_band_2>\d+-\d+)$',
    re.MULTILINE,
)

MEAL_BASIS_MAP = {
    "All Inclusive": MealPlan.ALL_INCLUSIVE,
    "Full Board": MealPlan.FULL_BOARD,
    "Half Board": MealPlan.HALF_BOARD,
    "Bed & Breakfast": MealPlan.BED_AND_BREAKFAST,
    "Room Only": MealPlan.ROOM_ONLY,
}

# --- Room Occupancy free-text block -----------------------------------------
#
# "Double rooms (DR01/DR09): 1+0, 1+1, 1+2, 2+0, 2+1, 2+2, 3+0 // Double rooms
#  superior & deluxe (DR05/DR07/DR08/DR09): 1+0, ... // ..."
# Segments are separated by "//"; each segment names the room codes it
# applies to in parentheses, followed by a comma list of adult+child combos.

ROOM_OCCUPANCY_SEGMENT_RE = re.compile(r'^(?P<label>.*?)\((?P<codes>[^)]+)\):\s*(?P<combos>.+)$')

# --- Rates block per room ----------------------------------------------------
#
# "Start Date End Date Days PPPN SOPN 3A AmR pN 1C2A 1R %R PN 1C2A 2R %R PN
#  (2-6) (7-14)
#  01.05.26 31.10.26 All 46,00 73,60 6,00 100,00 100,00"
#
# The age-band continuation line ("(2-6) (7-14)") is intentionally not
# parsed here — the Units table already gives the age bands for this room,
# and re-deriving them from position in the continuation line would be a
# second, weaker source of the same fact.

ROOM_RATE_HEADER_RE = re.compile(r'^\d+\.\s+(?P<code>\S+)\s+-\s+.+$', re.MULTILINE)

RATE_DATA_LINE_RE = re.compile(
    r'^(?P<start>\d{2}\.\d{2}\.\d{2})\s+(?P<end>\d{2}\.\d{2}\.\d{2})\s+(?P<days>\S+)\s+(?P<rest>.*)$'
)

RATE_COLUMN_CODE_RE = re.compile(
    r'(?P<pppn>PPPN)'
    r'|(?P<sopn>SOPN)'
    r'|(?P<amr>(?P<amr_n>\d+)A AmR pN)'
    r'|(?P<childpct>(?P<child_n>\d+)C(?P<child_adults>\d+)A (?P<child_range>\d+)R %R [Pp]N)'
)

# --- Contract-level header ----------------------------------------------------

PERIOD_RE = re.compile(r'Period\s+(?P<start>\d{2}\.\d{2}\.\d{2})-(?P<end>\d{2}\.\d{2}\.\d{2})')
MIN_MAX_STAY_RE = re.compile(r'(?P<min>\d+)/(?P<max>\d+)')

# "The Tour Operator will pay to the Supplier a deposit of 1.000.000 USD
# at latest on 30.09.2025" -- 4 real, identically-shaped lines on page 6
# (Turnover Guarantee Conditions box). Amounts use European-style
# thousands separators ("1.000.000" = 1,000,000; "500.000" = 500,000),
# handled by the adapter (strip "." before int()), not here.
DEPOSIT_PAYMENT_RE = re.compile(
    r'The Tour Operator will pay to the Supplier a deposit of '
    r'(?P<amount>[\d.]+)\s*USD\s*at latest on\s*(?P<date>\d{2}\.\d{2}\.\d{4})',
)

# The footer repeats on every page and is far more reliably formatted than
# the wrapped header block at the top of page 1 (where "Amarina Jannah
# Resort & Aqua" and "Park" land on different physical lines due to layout
# wrapping around the logo). Real EXIM/RMF contracts print this exact
# footer shape, so it's the more robust place to read hotel name + contract
# reference from.
FOOTER_RE = re.compile(
    r'^(?P<hotel>.+?)\s+(?P<contract_ref>\S+)\s+(?P<internal_ref>\S+)\s+'
    r'(?P<start>\d{2}\.\d{2}\.\d{2})-(?P<end>\d{2}\.\d{2}\.\d{2})\s+Print on\s*:'
    r'(?P<print_date>\d{2}\.\d{2}\.\d{4})\s+Page\s+\d+\s+of\s+\d+$',
    re.MULTILINE,
)


def parse_exim_date(raw: str) -> date:
    """EXIM dates are DD.MM.YY, always 20xx."""
    day, month, year = raw.split(".")
    return date(2000 + int(year), int(month), int(day))
