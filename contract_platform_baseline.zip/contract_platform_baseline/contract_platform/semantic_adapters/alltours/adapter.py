"""
The Alltours Semantic Adapter — translates Alltours's raw OCR'd page text
(from document_parser) into a draft ContractScope.

M3 exists to prove the architecture survives a scanned, non-native-text
source. Structurally the room-rate table (fixed room codes x 3 periods) is
closer to EXIM's shape than Anex's, so the real pressure this milestone
puts on the platform is at the document_parser/adapter boundary: every
value here is one OCR pass removed from the source pixels, not a clean
text layer.

Confidence policy for this adapter specifically: values read from an
OCR'd page (RawPage.extraction_method == "ocr:tesseract") default to
MEDIUM confidence, not HIGH -- a systematic policy, not a per-field
judgment call, reflecting that OCR is inherently less reliable than a
native text layer even when a value looks clean. Values the adapter
genuinely cannot parse (the stacked min/max occupancy cells -- OCR
scrambles this specific region too unreliably to trust) become LOW
confidence with a source_note, per Part 5: never invent, never silently
default.

Per architecture Part 5: Calculation values are built as Expression trees,
ambiguity is surfaced rather than resolved, and this module never imports
pricing_engine or review_ui.

M3 scope: builds a draft ContractScope containing only the DZP room
(double room pool view) across its 3 real periods -- the same "thinnest
slice, one room, real numbers" scope M1 used for EXIM's DR01. Full
10-room coverage, the precise occupancy stack, early-booking SPOs, child
discount, senior/longstay reductions are real, confirmed-present data,
deferred to M4.

M4 (post-Anex-Triple-Reduction slice): the real "for 3rd. adult reductlon
for all rooms" Supplements row (6.00/6.00/6.00 EUR, Periods I/II/III) is
now a real SUPPLEMENT PricingRule per season -- the exact line
PricingRule.applies_to_pax_number's own docstring already cited as
founding evidence for that field (M4 Slice 2). Unlike the per-room rate
table (blocked on real OCR corruption -- see README), this line reads
cleanly; built with room_type_id=None (hotel-wide, per the real "for all
rooms" scope), not narrowed to DZP.

M4 (Longstay slice): the real "Longstay from 21. nights reduction for
all rooms" Special Reduction row (10%/10%/10%, Periods I/II/III) is now a
real SUPPLEMENT PricingRule per season, gated by a real StayLengthCondition
(the platform's first real adapter use of that condition type). Also
room_type_id=None, but applies_to_pax_number=None too -- a whole-party
reduction, not a numbered slot. The second real tier in the same section
("from 29 nights ... 12%") is deliberately not built -- see the comment
at the call site in build_contract_scope for the real, evidenced reason
(an unresolved overlap the source itself doesn't clarify).

M4 (Senior Discount slice): the real "Senior from 60 years reduction for
allrooms" row (10%/10%/10%, same section as Longstay) is now a real
SUPPLEMENT PricingRule per season, gated by a real AgeCondition
(role=ADULT). Unlike Longstay, age is a per-guest fact, not a
booking-level one -- consumed per identified ADULT guest in
pricing_engine.calculator._adult_lines, not as a whole-booking override
(see that function's own docstring for why folding it into the Longstay
mechanism would have been wrong).

M4 (Cancellation Policy slice): the real customer cancellation policy
(page 3, "Cancellations by Customers / Cancellation Fees" -- the first
page beyond page 1 this adapter has ever read) is now a real
CancellationRule: a 1-night fee for cancellations within 6 days of
arrival. The real 3-night no-show charge in the same clause is
deliberately not built -- see build_contract_scope's own comment at the
call site (a no-show is not a cancellation, by the contract's own
wording).
"""

from __future__ import annotations
from datetime import date

from contract_platform.contract_model.entities import (
    Hotel, TourOperator, RoomType, Occupancy, Season, Rate, PricingRule,
    ContractScope, Extracted, Provenance, StayLengthCondition, AgeCondition, CancellationRule,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel, RateBasis, MealPlan, RuleKind, CalculationUnit, GuestType
from contract_platform.contract_model.expressions import RateRef, Subtract, PercentOf, Constant
from contract_platform.document_parser.pdf_reader import RawPage, read_pdf_pages
from contract_platform.semantic_adapters.alltours import vocabulary as vocab


class AlltoursAdapterError(Exception):
    pass


def _extracted(value, page: RawPage, raw_text: str, method: str, note: str = "",
                confidence: ConfidenceLevel = None) -> Extracted:
    if confidence is None:
        confidence = ConfidenceLevel.HIGH if page.extraction_method == "native_text" else ConfidenceLevel.MEDIUM
    return Extracted(
        value=value, confidence=confidence,
        provenance=Provenance(page_number=page.page_number, raw_text=raw_text, extraction_method=method),
        source_note=note or None,
    )


def parse_hotel_and_tour_operator(pages: list[RawPage]) -> tuple[str, str, RawPage]:
    for page in pages:
        hotel_m = vocab.HOTEL_NAME_RE.search(page.text)
        to_m = vocab.TOUR_OPERATOR_RE.search(page.text)
        if hotel_m and to_m:
            return hotel_m.group("name").strip(), to_m.group("name").strip(), page
    raise AlltoursAdapterError("Could not find hotel name / tour operator identity.")


def parse_contract_validity(pages: list[RawPage]) -> tuple[date, date, RawPage]:
    for page in pages:
        m = vocab.CONTRACT_VALIDITY_RE.search(page.text)
        if m:
            return (
                vocab.parse_full_date(m.group("start")),
                vocab.parse_full_date(m.group("end")),
                page,
            )
    raise AlltoursAdapterError("Could not find the contract validity dates.")


def parse_period_date_ranges(pages: list[RawPage], year: int) -> tuple[list[tuple[date, date]], list, RawPage]:
    """Returns [(start,end) for Period I range A, Period II, Period III,
    Period I range B]. Period I is genuinely split across two disjoint
    calendar ranges in the source (low season on both ends of summer) --
    the adapter models this as two Season objects sharing the same label,
    exactly like M1 handled EXIM's contract-level period; no Model change."""
    for page in pages:
        landmarks = list(vocab.PERIOD_LANDMARK_RE.finditer(page.text))
        if not landmarks:
            continue
        window_start = landmarks[-1].end()
        window = page.text[window_start:window_start + 600]
        tokens = vocab.DATE_TOKEN_RE.findall(window)
        if len(tokens) < 8:
            continue
        tokens = tokens[:8]
        dates = [vocab.parse_alltours_date(t, year) for t in tokens]
        ranges = [
            (dates[0], dates[1]),  # Period I, range A
            (dates[2], dates[3]),  # Period II
            (dates[4], dates[5]),  # Period III
            (dates[6], dates[7]),  # Period I, range B
        ]
        return ranges, tokens, page
    raise AlltoursAdapterError("Could not locate the Period I/II/III date-range header.")


def parse_room_rate_row(pages: list[RawPage], room_code: str) -> tuple[list[float], RawPage, str]:
    """Finds the line containing the given room code (tolerating known,
    reproducible OCR misreads for that specific code -- see
    vocabulary.ROOM_CODE_OCR_ALIASES) and reads the last 3 decimal numbers
    on it as Period I/II/III rates -- the row always ends with exactly
    those 3 values before trailing OCR noise. Raises rather than guessing
    if fewer than 3 clean decimals are found, since a misread digit here
    (confirmed against real OCR output: '85.00' can come back as 'B5.00')
    must fail loudly, not silently ship a wrong price."""
    search_terms = vocab.room_code_search_terms(room_code)
    for page in pages:
        for line in page.text.splitlines():
            if not any(term in line for term in search_terms):
                continue
            decimals = vocab.DECIMAL_RE.findall(line)
            if len(decimals) < 3:
                continue  # this occurrence didn't OCR cleanly enough; keep looking
            values = [float(d.replace(",", ".")) for d in decimals[-3:]]
            return values, page, line.strip()
    raise AlltoursAdapterError(
        f"Could not find a cleanly OCR'd rate row for room code {room_code!r}. "
        f"This row may need manual review before it can be extracted."
    )


def parse_third_adult_reduction(pages: list[RawPage]) -> tuple[dict, RawPage, str]:
    """Locates Alltours' real 'for 3rd. adult reductlon for all rooms'
    Supplements row (page 1: 6.00 / 6.00 / 6.00 for Periods I/II/III).
    Unlike the per-room rate table, this line reads cleanly with zero OCR
    corruption -- confirmed by inspection, no alias/tolerance handling
    needed beyond the one word misread this document reproducibly makes
    ("reductlon", handled in the regex itself)."""
    for page in pages:
        m = vocab.THIRD_ADULT_REDUCTION_RE.search(page.text)
        if m:
            values = {
                "Period I": float(m.group("p1").replace(",", ".")),
                "Period II": float(m.group("p2").replace(",", ".")),
                "Period III": float(m.group("p3").replace(",", ".")),
            }
            return values, page, m.group(0)
    raise AlltoursAdapterError("Could not find the '3rd adult reduction for all rooms' Supplements row.")


def parse_longstay_21_nights(pages: list[RawPage]) -> tuple[dict, RawPage, str]:
    """Locates Alltours' real 'Longstay from 21. nights reduction for all
    rooms' Special Reduction row (page 1: 10% / 10% / 10% for Periods
    I/II/III). Reads cleanly with zero OCR corruption -- confirmed by
    inspection. Deliberately does NOT parse the second real tier ('from
    29 nights ... 12%') in the same section -- see build_contract_scope's
    own comment at the call site for why."""
    for page in pages:
        m = vocab.LONGSTAY_21_NIGHTS_RE.search(page.text)
        if m:
            values = {
                "Period I": float(m.group("p1")),
                "Period II": float(m.group("p2")),
                "Period III": float(m.group("p3")),
            }
            return values, page, m.group(0)
    raise AlltoursAdapterError("Could not find the 'Longstay from 21 nights' Special Reduction row.")


def parse_senior_60_years(pages: list[RawPage]) -> tuple[dict, RawPage, str]:
    """Locates Alltours' real 'Senior from 60 years reduction for
    allrooms' Special Reduction row (page 1: 10% / 10% / 10% for Periods
    I/II/III). Reads cleanly with zero OCR corruption -- confirmed by
    inspection. Note: 'Senior' also appears twice elsewhere on this page
    as a job title ('Senior Contracting Manager') -- the regex only
    matches when immediately followed by 'from 60 years reduction', so it
    can't accidentally latch onto those."""
    for page in pages:
        m = vocab.SENIOR_60_YEARS_RE.search(page.text)
        if m:
            values = {
                "Period I": float(m.group("p1")),
                "Period II": float(m.group("p2")),
                "Period III": float(m.group("p3")),
            }
            return values, page, m.group(0)
    raise AlltoursAdapterError("Could not find the 'Senior from 60 years' Special Reduction row.")


def parse_cancellation_policy(pages: list[RawPage]) -> tuple[dict, RawPage, str] | None:
    """Locates Alltours' real customer cancellation policy (page 3,
    section '11. Cancellations by Customers / Cancellation Fees'): a
    1-night fee for cancellations "from 6 days before arrival until the
    day of arrival". This page's two-column OCR layout interleaves
    unrelated text from the other column between "the organizer" and
    "will pay the equivalent of 1 night", so the two real fragments are
    matched independently (both required on the same page) rather than
    with one pattern requiring adjacency. Returns None if the section
    isn't present -- a real absence, not a parse failure."""
    for page in pages:
        days_m = vocab.CANCELLATION_DAYS_RE.search(page.text)
        fee_m = vocab.CANCELLATION_FEE_RE.search(page.text)
        if days_m and fee_m:
            return (
                {"deadline_days_before_arrival": int(days_m.group("days")), "penalty_nights": int(fee_m.group("nights"))},
                page,
                f"{days_m.group(0)} ... {fee_m.group(0)}",
            )
    return None


def build_contract_scope(pdf_path: str, room_codes: list[str] | None = None) -> ContractScope:
    """The adapter's main entry point: PDF path in, draft ContractScope out.
    room_codes restricts which RoomTypes get built (default: DZP only --
    the M3 walking-skeleton scope, mirroring M1's DR01-only decision).
    Only page 1 is read: the header, contract validity, period date
    header, and every room's rate row all live there in this contract's
    layout -- confirmed by inspection, not assumed -- and OCR is the
    expensive part of this pipeline, so there's no reason to pay for
    pages this milestone's scope never reads."""
    if room_codes is None:
        room_codes = ["DZP"]

    pages = read_pdf_pages(pdf_path, page_numbers=[1])
    cancellation_pages = read_pdf_pages(pdf_path, page_numbers=[3])

    hotel_name, to_name, header_page = parse_hotel_and_tour_operator(pages)
    contract_start, contract_end, validity_page = parse_contract_validity(pages)
    period_ranges, period_tokens, period_page = parse_period_date_ranges(pages, contract_start.year)
    third_adult_values, third_adult_page, third_adult_raw = parse_third_adult_reduction(pages)
    longstay_values, longstay_page, longstay_raw = parse_longstay_21_nights(pages)
    senior_values, senior_page, senior_raw = parse_senior_60_years(pages)

    hotel = Hotel(name=hotel_name, location="Marsa Alam, Red Sea")
    tour_operator = TourOperator(name=to_name)

    scope = ContractScope(
        hotel=hotel, tour_operator=tour_operator,
        valid_from=contract_start, valid_to=contract_end, currency="EUR",
    )

    # Real, cleanly-matched customer policy (page 3, "Cancellations by
    # Customers / Cancellation Fees" -- the first page beyond page 1 this
    # adapter has ever read). Only the 6-day/1-night tier is built: free
    # cancellation 7+ days out is the implicit absence of any penalty
    # rule (not a separate entry), and the real 3-night no-show charge in
    # the same clause is deliberately NOT built as a CancellationRule --
    # a no-show is, by the contract's own wording, a distinct thing from
    # a cancellation (the customer never canceled; they simply didn't
    # arrive). Forcing it into deadline_days_before_arrival would
    # misrepresent that real distinction. penalty_calculation is
    # expressed in CalculationUnit.NIGHTS, not an invented currency
    # amount -- the source states "the equivalent of 1 night", not a
    # dollar figure, and this contract-wide clause doesn't reference any
    # specific room's rate.
    cancellation_policy = parse_cancellation_policy(cancellation_pages)
    if cancellation_policy is not None:
        values, cancellation_page, cancellation_raw = cancellation_policy
        scope.cancellation_rules.append(CancellationRule(
            contract_scope_id=scope.id,
            description=(
                f"Cancellation fee of {values['penalty_nights']} night(s) equivalent for cancellations "
                f"within {values['deadline_days_before_arrival']} days of arrival."
            ),
            deadline_days_before_arrival=values["deadline_days_before_arrival"],
            penalty_calculation=Constant(values["penalty_nights"], CalculationUnit.NIGHTS),
        ))

    period_i_a, period_ii, period_iii, period_i_b = period_ranges
    period_defs = [
        ("Period I", period_i_a),
        ("Period I", period_i_b),
        ("Period II", period_ii),
        ("Period III", period_iii),
    ]

    for room_code in room_codes:
        rates, rate_page, raw_line = parse_room_rate_row(pages, room_code)
        if len(rates) != 3:
            raise AlltoursAdapterError(f"Expected 3 period rates for {room_code!r}, found {len(rates)}.")
        period_i_val, period_ii_val, period_iii_val = rates
        period_values = {"Period I": period_i_val, "Period II": period_ii_val, "Period III": period_iii_val}

        room = RoomType(
            hotel_id=hotel.id, canonical_code=room_code, display_name=room_code,
            aliases=[room_code],
        )
        # The stacked min/max occupancy cell for this row doesn't OCR
        # reliably enough to trust (verified against multiple rows) --
        # flagged LOW rather than guessed, per Part 5.
        room.valid_occupancies.append(Occupancy(
            adults=Extracted(
                value=2, confidence=ConfidenceLevel.LOW,
                provenance=Provenance(page_number=rate_page.page_number, raw_text=raw_line, extraction_method="ocr:tesseract"),
                source_note="Stacked min/max occupancy cell did not OCR reliably enough to parse the full combination "
                            "set; only a plausible minimum (2 adults) is recorded here. Needs manual confirmation "
                            "against the source document before this RoomType is used for real bookings.",
            ),
            children=Extracted(
                value=0, confidence=ConfidenceLevel.LOW,
                provenance=Provenance(page_number=rate_page.page_number, raw_text=raw_line, extraction_method="ocr:tesseract"),
                source_note="See adults field note -- occupancy stack not reliably OCR'd.",
            ),
            infants=_extracted(0, rate_page, raw_line, "ocr:tesseract", confidence=ConfidenceLevel.MEDIUM),
        ))
        scope.room_types.append(room)

        for label, (start, end) in period_defs:
            season = Season(
                label=f"{label} ({start.isoformat()}\u2013{end.isoformat()})",
                start_date=_extracted(start, period_page, " ".join(period_tokens), "regex.alltours_period_header"),
                end_date=_extracted(end, period_page, " ".join(period_tokens), "regex.alltours_period_header"),
            )
            scope.seasons.append(season)

            scope.rates.append(Rate(
                room_type_id=room.id, season_id=season.id, meal_plan=MealPlan.ALL_INCLUSIVE,
                basis=RateBasis.PER_PERSON_PER_NIGHT, currency="EUR",
                amount=_extracted(period_values[label], rate_page, raw_line, "regex.alltours_rate_row",
                                   f"{label} column, room {room_code}"),
            ))

            # Real, cleanly-OCR'd data ("for 3rd. adult reductlon for all
            # rooms"): room_type_id=None, PricingRule's own documented
            # "hotel-wide" meaning (present since M0), to faithfully carry
            # the real scope rather than narrowing it to this one room.
            # Structurally identical to EXIM's AMR and Anex's Triple
            # Reduction (both already built) -- a flat per-night amount
            # off the base rate for the 3rd adult slot.
            scope.pricing_rules.append(PricingRule(
                kind=RuleKind.SUPPLEMENT, room_type_id=None, season_id=season.id,
                label="3rd Adult Reduction (all rooms)",
                applies_to_pax_number=3,
                calculation=_extracted(
                    Subtract(RateRef(scope.rates[-1].id), Constant(third_adult_values[label], CalculationUnit.EUR)),
                    third_adult_page, third_adult_raw, "regex.alltours_third_adult_reduction",
                    f"{label} column, Supplements section.",
                ),
            ))

            # Real, cleanly-OCR'd data ("Longstay from 21. nights
            # reduction for all rooms"): room_type_id=None (same "hotel-
            # wide" scope as the 3rd Adult Reduction above), but
            # applies_to_pax_number=None too -- this reduces the base
            # rate for the whole party, not one numbered slot, gated by a
            # real StayLengthCondition rather than always applying.
            # Deliberately does NOT build the second real tier ("from 29
            # nights ... 12%") in the same section -- see this function's
            # module docstring and the parser's own docstring for why
            # (an unevidenced tie-break the source doesn't resolve).
            scope.pricing_rules.append(PricingRule(
                kind=RuleKind.SUPPLEMENT, room_type_id=None, season_id=season.id,
                label="Longstay Reduction (21+ nights, all rooms)",
                applicability=[StayLengthCondition(
                    min_nights=_extracted(21, longstay_page, longstay_raw, "regex.alltours_longstay_21_nights",
                                           "'Longstay from 21. nights' -- no printed ceiling, so max_nights is left unset (open-ended)."),
                    max_nights=None,
                )],
                calculation=_extracted(
                    Subtract(RateRef(scope.rates[-1].id),
                             PercentOf(RateRef(scope.rates[-1].id), Constant(longstay_values[label], CalculationUnit.PERCENT))),
                    longstay_page, longstay_raw, "regex.alltours_longstay_21_nights",
                    f"{label} column, Special Reduction section.",
                ),
            ))

            # Real, cleanly-OCR'd data ("Senior from 60 years reduction
            # for allrooms"): room_type_id=None (same "hotel-wide" scope
            # as the two rules above), applies_to_pax_number=None -- but
            # unlike Longstay, this is a *per-guest* fact (age varies per
            # adult, unlike nights which is a single booking-level fact),
            # so it's consumed per identified ADULT guest in
            # booking.context.guest_ages (pricing_engine.calculator.
            # _adult_lines), not as a whole-booking override. Only an
            # adult explicitly identified by age (role=ADULT in
            # guest_ages) can ever receive this discount -- every booking
            # that doesn't supply adult ages (every real booking before
            # this slice) is unaffected.
            scope.pricing_rules.append(PricingRule(
                kind=RuleKind.SUPPLEMENT, room_type_id=None, season_id=season.id,
                label="Senior Discount (60+, all rooms)",
                applicability=[AgeCondition(
                    role=GuestType.ADULT,
                    min_age=_extracted(60, senior_page, senior_raw, "regex.alltours_senior_60_years",
                                        "'Senior from 60 years' -- no printed ceiling, so max_age is left unset (open-ended)."),
                    max_age=None,
                )],
                calculation=_extracted(
                    Subtract(RateRef(scope.rates[-1].id),
                             PercentOf(RateRef(scope.rates[-1].id), Constant(senior_values[label], CalculationUnit.PERCENT))),
                    senior_page, senior_raw, "regex.alltours_senior_60_years",
                    f"{label} column, Special Reduction section.",
                ),
            ))

    return scope
