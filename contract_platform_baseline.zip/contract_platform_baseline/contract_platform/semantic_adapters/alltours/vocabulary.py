"""
Alltours's own vocabulary.

Structurally this contract is closer to EXIM (a fixed room-code table with
period columns) than to Anex's date-range/market split. The real
difference M3 exists to prove the architecture survives is at the
document_parser level, not the model level: this PDF has zero embedded
text (confirmed against the real file) and must be OCR'd, so every value
this adapter reads is one OCR pass removed from the source pixels, not a
clean text layer. That uncertainty is handled by confidence calibration
(see adapter.py's _ocr() helper), not by inventing structure the document
doesn't give us.

Nothing here is general platform knowledge; none of it belongs in
document_parser or contract_model.
"""

from __future__ import annotations
import re
from datetime import date

# --- Header -----------------------------------------------------------------

HOTEL_NAME_RE = re.compile(r'^Hotel\s+(?P<name>[A-Za-z][A-Za-z ]+?)\s*\.', re.MULTILINE)
TOUR_OPERATOR_RE = re.compile(r'^(?P<name>alltours flugreisen gmbh\s*/\s*byebye gmbh)', re.MULTILINE | re.IGNORECASE)

# "01.05.2026 31,10.2026" -- OCR sometimes reads the second date's decimal
# point as a comma; tolerate both.
CONTRACT_VALIDITY_RE = re.compile(
    r'(?P<start>\d{2}\.\d{2}\.\d{4})\s+(?P<end>\d{2}[.,]\d{2}\.\d{4})'
)

# --- Room rate rows -----------------------------------------------------------
#
# Known room codes from the Roomtype table (position column 3 in the
# source). Hardcoded because they're a closed, small set specific to how
# Alltours labels Amarina Jannah's room categories in this contract --
# exactly the kind of TO-specific vocabulary that belongs here, not in
# contract_model.
KNOWN_ROOM_CODES = ["DZP", "EZP", "GO", "DZG", "DP", "DSP", "DZD", "DJM", "DZB", "FZB"]

# Confirmed reproducible OCR misreads for specific codes in this scanned
# document's font (e.g. "DZP" -> "pzp": the capital D's stroke shape gets
# read as a lowercase p at this resolution). This is a workaround for one
# specific document's OCR behavior, not a general text-matching strategy —
# it belongs here in Alltours's own vocabulary, not in document_parser.
ROOM_CODE_OCR_ALIASES: dict[str, list[str]] = {
    "DZP": ["DZP", "pzp"],
}


def room_code_search_terms(room_code: str) -> list[str]:
    return ROOM_CODE_OCR_ALIASES.get(room_code.upper(), [room_code])

ROOM_CODE_LINE_RE = re.compile(
    r'\b(?P<code>' + "|".join(KNOWN_ROOM_CODES) + r')\b', re.IGNORECASE
)

# A decimal amount, tolerating OCR's occasional comma-for-period swap
# ("115.20." or "71,00").
DECIMAL_RE = re.compile(r'(?P<num>\d+[.,]\d{2})')

# --- Season / Period date header --------------------------------------------
#
# The header row spells out three periods' date ranges, but OCR scatters
# them across two ragged lines with inconsistent '.'/',' separators:
#   "1.5 | 20,5 | 21.5 | 28.6 | 29.6 ; 31.8"
#   "1.9 | 31.10!"
# Rather than anchor on exact punctuation (which OCR doesn't preserve
# reliably), this locates the "Period" landmark and reads the next 8
# date-like tokens in document order -- verified against the real OCR
# output to land in exactly this sequence:
#   [Period I start, Period I mid-end, Period II start, Period II end,
#    Period III start, Period III end, Period I 2nd-range start, Period I 2nd-range end]
PERIOD_LANDMARK_RE = re.compile(r'Period')
DATE_TOKEN_RE = re.compile(r'\d{1,2}[.,]\d{1,2}')


# --- Supplements section --------------------------------------------------
#
# "for 3rd. adult reductlon for all rooms | 6.00 6.00 6.00" (Periods
# I/II/III). The one populated row in an otherwise-blank "5. Supplements"
# table -- every other "supplement for" row in the real document has no
# values at all. Reads cleanly with zero OCR corruption (confirmed by
# inspection); "reductlon" tolerates the specific OCR misread of this
# word in this document (the 'i' in "reduction" reads as 'l').
THIRD_ADULT_REDUCTION_RE = re.compile(
    r'3rd\.?\s*adult\s*reduc(?:tion|tlon)\s*for\s*all\s*rooms\D*'
    r'(?P<p1>[\d.,]+)\s+(?P<p2>[\d.,]+)\s+(?P<p3>[\d.,]+)',
    re.IGNORECASE,
)


# --- Special Reduction section ---------------------------------------------
#
# "Longstay from 21. nights reduction for all rooms ... 10% | 10% | 10%"
# (Periods I/II/III). Reads cleanly with zero OCR corruption (confirmed by
# inspection). A second real tier exists in the same section ("Longstay
# from 29nights* reduction ... 12% | 12% | 12%") -- deliberately not
# parsed here. It's real, equally clean data, but building it would force
# an unevidenced tie-break: a 30+-night stay genuinely satisfies both
# tiers' StayLengthCondition, and the source states no explicit
# supersession/exclusivity between them (no "the higher tier replaces the
# lower" language, no footnote resolving the overlap found on
# inspection). See the adapter's own comment at the call site.
# "Senior from 60 years reduction for allrooms ... 10% | 10% | 10%"
# (Periods I/II/III). Same Special Reduction section as Longstay, reads
# cleanly with zero OCR corruption -- confirmed by inspection. Tolerates
# a stray OCR character after the first "%" (this document renders it as
# "10%°"), same defensive gap-matching as the Longstay regex.
SENIOR_60_YEARS_RE = re.compile(
    r'Senior\s*from\s*60\s*years\s*reduction[^\n%]*?'
    r'(?P<p1>\d+)%\s*\S?\s*\|?\s*(?P<p2>\d+)%\s*\|?\s*(?P<p3>\d+)%',
    re.IGNORECASE,
)
LONGSTAY_21_NIGHTS_RE = re.compile(
    r'Longstay\s*from\s*21\.?\s*nights?\s*reduction[^\n%]*?'
    r'(?P<p1>\d+)%\s*\|?\s*(?P<p2>\d+)%\s*\|?\s*(?P<p3>\d+)%',
    re.IGNORECASE,
)


# --- Cancellations by Customers / Cancellation Fees (section 11, page 3)
#
# "For cancellations fram 6 days befare arrival until the day of
# arrival, the organizer\nwill pay the equivalent of 1 night as a
# cancellation fee" -- real text, but this page's two-column OCR layout
# interleaves unrelated text from the other column between "the
# organizer" and "will pay ...", so the two halves are matched as
# separate, independent fragments (both required on the same page),
# not one pattern requiring adjacency. Tolerates this document's own
# reproducible OCR misreads ("fram" for "from", "befare" for "before").
CANCELLATION_DAYS_RE = re.compile(
    r'cancellations\s*(?:fram|from)\s*(?P<days>\d+)\s*days?\s*(?:befare|before)\s*arrival\s*'
    r'until\s*the\s*day\s*of\s*arrival',
    re.IGNORECASE,
)
CANCELLATION_FEE_RE = re.compile(
    r'will\s*pay\s*the\s*equivalent\s*of\s*(?P<nights>\d+)\s*nights?\s*as\s*a\s*cancellation\s*fee',
    re.IGNORECASE,
)


def parse_alltours_date(raw: str, year: int) -> date:
    """Dates in the period header are day.month with no year (e.g. '1.5',
    '31.10'); the contract's own validity year is used. Tolerates a
    comma-for-period OCR swap."""
    raw = raw.replace(",", ".")
    day_s, month_s = raw.split(".")[:2]
    return date(year, int(month_s), int(day_s))


def parse_full_date(raw: str) -> date:
    raw = raw.replace(",", ".")
    day, month, year = raw.split(".")
    return date(int(year), int(month), int(day))
