"""
Orchestration — the transport-agnostic business logic both the CLI
(cli.py) and the HTTP API (api/app.py) call into.

Extracted from cli.py as part of building the API layer, not written
fresh: every function here already existed in cli.py exactly as
written, already proven by every CLI test in this project's history.
This is a pure "where does this code live" move, not a behavior change
— cli.py's own tests (updated only to import from here) are the proof
that nothing about what these functions do was touched.

Why this module exists at all, rather than having api/app.py import
straight from cli.py: cli.py is itself a transport (argparse in,
stdout/exit-codes out), the same way api/app.py is a transport (JSON in,
JSON/HTTP-status out). Having one transport module import another would
be backwards layering — every business decision (what counts as a valid
adapter name, how a correction gets applied, how a booking gets priced)
belongs in one shared place both transports call into symmetrically,
not owned by whichever transport was built first.

Every function here is exactly what it was in cli.py: thin orchestration
over already-tested functions (build_contract_scope(), commit_scope(),
list_review_items(), apply_correction(), validate_booking(),
price_booking()) — no new business logic was written to support having
two transports. A transport's only job is turning its own protocol
(argv / HTTP request) into a call here, and this module's result objects
into its own protocol's response shape.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

from contract_platform.contract_model.entities import ContractScope
from contract_platform.contract_model.vocabulary import ConfidenceLevel, GuestType
from contract_platform.semantic_adapters.exim.adapter import build_contract_scope as _build_exim_scope
from contract_platform.semantic_adapters.anex.adapter import build_contract_scope as _build_anex_scope
from contract_platform.semantic_adapters.alltours.adapter import build_contract_scope as _build_alltours_scope
from contract_platform.registry.store import commit_scope, list_committed_scope_ids, load_draft_scope, get_committed_scope, scope_lock
from contract_platform.review_ui.corrections import list_review_items, apply_correction, ReviewItem
from contract_platform.validation.invariants import Severity, ValidationIssue
from contract_platform.pricing_engine.calculator import (
    BookingRequest, BookingApplicabilityContext, GuestAge, validate_booking, price_booking, Invoice,
)

KNOWN_ADAPTERS = ("exim", "anex", "alltours")


@dataclass
class IngestResult:
    scope_id: str
    committed: bool
    room_type_count: int
    rate_count: int
    pricing_rule_count: int
    validation_issue_count: int
    review_items: list[ReviewItem] = field(default_factory=list)


def _build_scope(adapter_name: str, pdf_path: str, room_codes: Optional[list[str]]) -> ContractScope:
    """A real, inspected signature difference, handled explicitly rather
    than assumed away: exim/alltours' build_contract_scope both accept
    an optional room_codes list; anex's does not -- it always builds the
    single real Promo Room product (M2's own documented scope)."""
    if adapter_name == "exim":
        return _build_exim_scope(pdf_path, room_codes=room_codes) if room_codes else _build_exim_scope(pdf_path)
    if adapter_name == "alltours":
        return _build_alltours_scope(pdf_path, room_codes=room_codes) if room_codes else _build_alltours_scope(pdf_path)
    if adapter_name == "anex":
        if room_codes:
            raise ValueError(
                "The anex adapter does not accept room_codes -- it always builds the "
                "single real Promo Room product, and has no per-room-code selection."
            )
        return _build_anex_scope(pdf_path)
    raise ValueError(f"Unknown adapter {adapter_name!r}. Known adapters: {', '.join(KNOWN_ADAPTERS)}.")


def run_ingest(adapter_name: str, pdf_path: str, room_codes: Optional[list[str]] = None,
                storage_dir: Optional[str] = None) -> IngestResult:
    """Runs a real PDF through extraction and the commit gate. On
    rejection, also surfaces the real review items a human would need to
    act on next.

    Locked on the built scope's own id: two concurrent ingests that
    happen to produce the same scope_id (e.g. the same contract PDF
    submitted twice at once) must not race each other's commit/draft
    write the same way two concurrent corrections must not."""
    scope = _build_scope(adapter_name, pdf_path, room_codes)
    with scope_lock(scope.id, storage_dir):
        result = commit_scope(scope, storage_dir=storage_dir)
    return IngestResult(
        scope_id=scope.id,
        committed=result.committed,
        room_type_count=len(scope.room_types),
        rate_count=len(scope.rates),
        pricing_rule_count=len(scope.pricing_rules),
        validation_issue_count=len(result.validation_issues),
        review_items=[] if result.committed else list_review_items(scope),
    )


@dataclass
class CorrectResult:
    scope_id: str
    applied: bool
    committed: bool
    remaining_review_items: list[ReviewItem] = field(default_factory=list)


def run_review(scope_id: str, storage_dir: str) -> list[ReviewItem]:
    """Loads a rejected scope's saved draft and lists its review items.
    Raises ValueError if no draft exists for this id in this
    storage_dir -- never returns an empty list to mean both "nothing
    needs review" and "this scope doesn't exist"."""
    draft = load_draft_scope(scope_id, storage_dir)
    if draft is None:
        raise ValueError(f"No draft scope found for id {scope_id!r} in {storage_dir!r}.")
    return list_review_items(draft)


def run_correct(scope_id: str, storage_dir: str, entity_id: str, field_name: str,
                 value: int, confidence: ConfidenceLevel) -> CorrectResult:
    """Loads a rejected scope's saved draft, applies one correction, and
    attempts to re-commit it. One field per call, matching how a human
    actually works through a review list.

    The entire load -> apply -> commit sequence runs under one
    scope_lock: without it, two concurrent corrections to the same
    scope_id could each load the same draft, apply their own edit, and
    race to commit -- one edit silently overwriting the other even
    though both callers see a success response. Locking only the final
    write (inside commit_scope) would not close this gap, since the
    stale read already happened before that point."""
    with scope_lock(scope_id, storage_dir):
        draft = load_draft_scope(scope_id, storage_dir)
        if draft is None:
            raise ValueError(f"No draft scope found for id {scope_id!r} in {storage_dir!r}.")

        applied = apply_correction(draft, entity_id, field_name, value, confidence)
        if not applied:
            return CorrectResult(scope_id=scope_id, applied=False, committed=False,
                                  remaining_review_items=list_review_items(draft))

        result = commit_scope(draft, storage_dir=storage_dir)
        return CorrectResult(
            scope_id=scope_id, applied=True, committed=result.committed,
            remaining_review_items=[] if result.committed else list_review_items(draft),
        )


@dataclass
class RoomTypeSummary:
    room_type_id: str
    canonical_code: str
    display_name: str
    valid_occupancy_count: int


def run_describe(scope_id: str, storage_dir: Optional[str] = None) -> list[RoomTypeSummary]:
    """Lists a committed scope's room types — specifically to surface
    the real room_type_id a subsequent price call needs."""
    scope = get_committed_scope(scope_id, storage_dir=storage_dir)
    if scope is None:
        raise ValueError(f"No committed scope found for id {scope_id!r}"
                          + (f" in {storage_dir!r}." if storage_dir else " (no storage_dir given)."))
    return [
        RoomTypeSummary(
            room_type_id=rt.id, canonical_code=rt.canonical_code, display_name=rt.display_name,
            valid_occupancy_count=len(rt.valid_occupancies),
        )
        for rt in scope.room_types
    ]


@dataclass
class PriceResult:
    scope_id: str
    room_type_id: str
    valid: bool
    validation_issues: list[ValidationIssue] = field(default_factory=list)
    invoice: Optional[Invoice] = None


def run_price(scope_id: str, storage_dir: Optional[str], room_type_id: str, check_in: date, check_out: date,
              adults: int, children: int = 0, infants: int = 0,
              child_ages: Optional[list[int]] = None, adult_ages: Optional[list[int]] = None,
              booking_date: Optional[date] = None) -> PriceResult:
    """Prices a real booking against a committed scope.

    child_ages/adult_ages/booking_date are wired straight through to a
    BookingApplicabilityContext, exactly the object every AgeCondition-
    and DaysBeforeArrivalCondition-gated PricingRule already expects —
    no new engine logic."""
    scope = get_committed_scope(scope_id, storage_dir=storage_dir)
    if scope is None:
        raise ValueError(f"No committed scope found for id {scope_id!r}"
                          + (f" in {storage_dir!r}." if storage_dir else " (no storage_dir given)."))

    guest_ages = [GuestAge(role=GuestType.CHILD, age=a) for a in (child_ages or [])]
    guest_ages += [GuestAge(role=GuestType.ADULT, age=a) for a in (adult_ages or [])]
    context = BookingApplicabilityContext(guest_ages=guest_ages, booking_date=booking_date) \
        if (guest_ages or booking_date) else None

    booking = BookingRequest(room_type_id=room_type_id, check_in=check_in, check_out=check_out,
                              adults=adults, children=children, infants=infants, context=context)
    issues = validate_booking(scope, booking)
    if any(i.severity == Severity.ERROR for i in issues):
        return PriceResult(scope_id=scope_id, room_type_id=room_type_id, valid=False, validation_issues=issues)

    invoice = price_booking(scope, booking)
    return PriceResult(scope_id=scope_id, room_type_id=room_type_id, valid=True,
                        validation_issues=issues, invoice=invoice)
