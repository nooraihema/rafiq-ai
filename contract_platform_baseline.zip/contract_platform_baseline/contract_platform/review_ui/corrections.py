"""
review_ui's first slice — closing the loop the Commit Gate (registry/
store.py) opened. CommitResult.low_confidence_fields already carries
enough detail to route a human to what needs correcting; this module is
what lets that human actually act on it.

list_review_items() is a thin wrapper around entities.iter_low_confidence()
— the single shared definition of "which fields need review", also used
by registry.commit_scope()'s rejection decision, so the two can never
silently drift on what counts as needing review (found by inspection:
this filter used to be written independently in both places). apply_correction()
still uses entities.iter_extracted() directly, not iter_low_confidence()
-- it's deliberately general (it enforces nothing about which field a
caller corrects, the same way commit_scope() enforces nothing about how
a ContractScope was built), so it needs the full walk, not the
LOW-confidence-only subset. No new traversal logic lives here, and no
Contract Model change: Extracted is already a plain, mutable dataclass,
so a correction is a direct in-place mutation of the exact object
iter_extracted() yields, not a new field, a new entity, or a
rebuild-and-replace.

Deliberately does not attempt: a real user interface (this is the
capability a UI would call, not the UI itself); recording who reviewed a
field or when (Extracted has no reviewed_by/reviewed_at field, and
adding one without a real UI or workflow driving that requirement would
be a speculative Contract Model change this project has consistently
avoided); resolving *which* value is correct (apply_correction accepts
whatever value the caller supplies — it enforces nothing about where
that value came from, the same way commit_scope() enforces nothing
about how a ContractScope was built).
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional

from contract_platform.contract_model.entities import ContractScope, Provenance, iter_extracted, iter_low_confidence
from contract_platform.contract_model.vocabulary import ConfidenceLevel


@dataclass
class ReviewItem:
    entity_id: str
    field_name: str
    current_value: Any
    confidence: ConfidenceLevel
    provenance: Optional[Provenance]
    source_note: Optional[str]


def list_review_items(scope: ContractScope) -> list[ReviewItem]:
    """Every LOW-confidence Extracted field currently in the scope,
    formatted for a human reviewer. HIGH/MEDIUM fields are never
    surfaced here -- this is specifically the commit gate's rejection
    list, not a general-purpose field browser."""
    return [
        ReviewItem(
            entity_id=entity_id, field_name=field_name, current_value=extracted.value,
            confidence=extracted.confidence, provenance=extracted.provenance,
            source_note=extracted.source_note,
        )
        for entity_id, field_name, extracted in iter_low_confidence(scope)
    ]


def apply_correction(scope: ContractScope, entity_id: str, field_name: str,
                      value: Any, confidence: ConfidenceLevel) -> bool:
    """Locates the (entity_id, field_name) pair via iter_extracted() and
    replaces that Extracted's value and confidence in place. Returns
    True if a matching field was found and updated, False otherwise --
    a stale or wrong reference fails loudly rather than silently
    no-oping or mutating the wrong field."""
    for eid, fname, extracted in iter_extracted(scope):
        if eid == entity_id and fname == field_name:
            extracted.value = value
            extracted.confidence = confidence
            return True
    return False
