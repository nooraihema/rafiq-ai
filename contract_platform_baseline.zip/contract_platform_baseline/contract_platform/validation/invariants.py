"""
The Validation layer — the gate described in the architecture document.
Every function here checks one invariant from the domain design and
returns a list of ValidationIssue objects. An empty list means the
ContractScope may proceed toward persistence; a non-empty list means it
must be routed to review_ui, never silently accepted or silently repaired.

This module imports only from contract_model. It has no idea semantic
adapters, PDFs, or Tour Operators exist — the same discipline the
architecture document insists on everywhere else.

M0 additions (roadmap Part 2, "Invariants (final set)"):
  5. No circular supersedes_rule_id / supersedes_contract_id chains.
  6. No Restriction references a PricingRule/Rate/ContractScope id that
     doesn't exist in this scope.
  7. MinMaxStay.min_nights <= MinMaxStay.max_nights.

The old LOW-confidence check only scanned Rate.amount. Now that
Extracted[T] is applied across the model, it walks every Extracted field
via entities.iter_extracted() — one traversal, shared with confidence.py,
rather than two independently-maintained lists of "where do Extracted
values live."
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

from contract_platform.contract_model.entities import (
    ContractScope, BlackoutPeriod, CombinabilityRule, ReleaseRule, MinMaxStay,
    StayLengthCondition, BookingDateCondition, DaysBeforeArrivalCondition, AgeCondition,
    iter_extracted,
)
from contract_platform.contract_model.vocabulary import ConfidenceLevel


class Severity(str, Enum):
    ERROR = "error"      # must block persistence
    WARNING = "warning"  # should be reviewed, doesn't block by itself


@dataclass
class ValidationIssue:
    severity: Severity
    code: str
    message: str
    entity_id: str = ""


def check_every_room_has_a_base_rate(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #1: every RoomType must have at least one Rate before a
    contract can be marked valid."""
    issues = []
    room_ids_with_rate = {r.room_type_id for r in scope.rates}
    for room in scope.room_types:
        if room.id not in room_ids_with_rate:
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="MISSING_BASE_RATE",
                message=f"RoomType '{room.display_name}' ({room.canonical_code}) has no Rate.",
                entity_id=room.id,
            ))
    return issues


def check_no_overlapping_rates(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #2: no two Rates for the same RoomType + Season + Market +
    Basis may exist without an explicit supersession relationship.

    `basis` is part of the key deliberately: a PPPN Rate and a SOPN Rate for
    the same room/season/market are not duplicates, they're two different
    pricing bases that legitimately coexist — that's exactly what
    Rate.basis exists to distinguish (confirmed against the real EXIM
    contract during M1: DR01 carries both PPPN=46.00 and SOPN=73.60 for the
    same room/season). Two Rates sharing all four is the real ambiguity
    this check exists to catch."""
    issues = []
    seen = {}
    for rate in scope.rates:
        key = (rate.room_type_id, rate.season_id, rate.market_id, rate.basis)
        if key in seen:
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="DUPLICATE_RATE",
                message=(
                    f"More than one Rate exists for the same RoomType/Season/Market "
                    f"combination with no supersession — ambiguous which applies."
                ),
                entity_id=rate.id,
            ))
        else:
            seen[key] = rate.id
    return issues


def check_occupancies_are_closed(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #3: every RoomType must have at least one valid Occupancy
    combination defined. A RoomType with zero occupancy combinations means
    an adapter left the '2 ADL+2CHD OR...' string unresolved."""
    issues = []
    for room in scope.room_types:
        if not room.valid_occupancies:
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="UNRESOLVED_OCCUPANCY",
                message=f"RoomType '{room.display_name}' has no resolved Occupancy combinations.",
                entity_id=room.id,
            ))
    return issues


def check_no_low_confidence_values_in_final_model(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #4: any Extracted value still marked LOW confidence must be
    reviewed before this ContractScope is treated as final — it may exist
    in a draft, never in a persisted Model. M0: now checks every Extracted
    field in the model (Season dates, Occupancy counts, Rate amounts,
    PricingRule calculations, Restriction values), not just Rate.amount."""
    issues = []
    for entity_id, field_name, extracted in iter_extracted(scope):
        if extracted.confidence == ConfidenceLevel.LOW:
            issues.append(ValidationIssue(
                severity=Severity.WARNING,
                code="LOW_CONFIDENCE_VALUE",
                message=(
                    f"{field_name} on entity {entity_id} was extracted with "
                    f"LOW confidence: {extracted.source_note}"
                ),
                entity_id=entity_id,
            ))
    return issues


def check_no_circular_supersession(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #5. Walks each PricingRule's supersedes_rule_id chain
    looking for a cycle. Also guards the trivial ContractScope
    self-reference case. Full cross-contract cycle detection for
    supersedes_contract_id needs other contracts loaded, which requires a
    persistence layer — deliberately deferred per Part 7; not this
    invariant's job while ContractScope objects are in-memory/JSON."""
    issues = []
    rule_by_id = {r.id: r for r in scope.pricing_rules}
    already_flagged: set[str] = set()

    for rule in scope.pricing_rules:
        if rule.id in already_flagged:
            continue
        chain_ids = [rule.id]
        current = rule
        while current.supersedes_rule_id:
            next_id = current.supersedes_rule_id
            if next_id in chain_ids:
                already_flagged.update(chain_ids)
                issues.append(ValidationIssue(
                    severity=Severity.ERROR,
                    code="CIRCULAR_SUPERSESSION",
                    message=(
                        f"PricingRule supersession chain starting at {rule.id} "
                        f"forms a cycle back to {next_id}."
                    ),
                    entity_id=rule.id,
                ))
                break
            next_rule = rule_by_id.get(next_id)
            if next_rule is None:
                break  # dangling supersedes_rule_id — not a cycle, not this check's concern
            chain_ids.append(next_id)
            current = next_rule

    if scope.supersedes_contract_id == scope.id:
        issues.append(ValidationIssue(
            severity=Severity.ERROR,
            code="CIRCULAR_SUPERSESSION",
            message="ContractScope.supersedes_contract_id references itself.",
            entity_id=scope.id,
        ))
    return issues


def check_no_dangling_restriction_references(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #6: a Restriction must point at a PricingRule, Rate, or
    ContractScope that actually exists in this scope."""
    issues = []
    rule_ids = {r.id for r in scope.pricing_rules}
    rate_ids = {r.id for r in scope.rates}

    for restriction in scope.restrictions:
        if restriction.applies_to_rule_id and restriction.applies_to_rule_id not in rule_ids:
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="DANGLING_RESTRICTION_REFERENCE",
                message=(
                    f"Restriction {restriction.id} references PricingRule "
                    f"{restriction.applies_to_rule_id!r}, which does not exist in this scope."
                ),
                entity_id=restriction.id,
            ))
        if restriction.applies_to_rate_id and restriction.applies_to_rate_id not in rate_ids:
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="DANGLING_RESTRICTION_REFERENCE",
                message=(
                    f"Restriction {restriction.id} references Rate "
                    f"{restriction.applies_to_rate_id!r}, which does not exist in this scope."
                ),
                entity_id=restriction.id,
            ))
        if (restriction.applies_to_contract_scope_id
                and restriction.applies_to_contract_scope_id != scope.id):
            issues.append(ValidationIssue(
                severity=Severity.ERROR,
                code="DANGLING_RESTRICTION_REFERENCE",
                message=(
                    f"Restriction {restriction.id} references ContractScope "
                    f"{restriction.applies_to_contract_scope_id!r}, which is not this scope."
                ),
                entity_id=restriction.id,
            ))
    return issues


def check_min_max_stay_is_valid(scope: ContractScope) -> list[ValidationIssue]:
    """Invariant #7: MinMaxStay.min_nights <= MinMaxStay.max_nights."""
    issues = []
    for restriction in scope.restrictions:
        if isinstance(restriction, MinMaxStay):
            if restriction.min_nights is None or restriction.max_nights is None:
                continue
            if restriction.min_nights.value > restriction.max_nights.value:
                issues.append(ValidationIssue(
                    severity=Severity.ERROR,
                    code="INVALID_MIN_MAX_STAY",
                    message=(
                        f"MinMaxStay {restriction.id} has min_nights "
                        f"({restriction.min_nights.value}) > max_nights "
                        f"({restriction.max_nights.value})."
                    ),
                    entity_id=restriction.id,
                ))
    return issues


def check_applicability_condition_ranges_are_valid(scope: ContractScope) -> list[ValidationIssue]:
    """Foundation Hardening II, invariant #8: every ApplicabilityCondition
    range must be internally consistent (min <= max), same shape as
    invariant #7 for MinMaxStay."""
    issues = []
    for rule in scope.pricing_rules:
        for condition in rule.applicability:
            if isinstance(condition, StayLengthCondition):
                if condition.min_nights is not None and condition.max_nights is not None:
                    if condition.min_nights.value > condition.max_nights.value:
                        issues.append(ValidationIssue(
                            severity=Severity.ERROR, code="INVALID_APPLICABILITY_RANGE",
                            message=(
                                f"StayLengthCondition {condition.id} on PricingRule {rule.id} has "
                                f"min_nights ({condition.min_nights.value}) > max_nights ({condition.max_nights.value})."
                            ),
                            entity_id=condition.id,
                        ))
            elif isinstance(condition, BookingDateCondition):
                if condition.from_date is not None and condition.to_date is not None:
                    if condition.from_date.value > condition.to_date.value:
                        issues.append(ValidationIssue(
                            severity=Severity.ERROR, code="INVALID_APPLICABILITY_RANGE",
                            message=(
                                f"BookingDateCondition {condition.id} on PricingRule {rule.id} has "
                                f"from_date ({condition.from_date.value}) > to_date ({condition.to_date.value})."
                            ),
                            entity_id=condition.id,
                        ))
            elif isinstance(condition, DaysBeforeArrivalCondition):
                if condition.min_days is not None and condition.max_days is not None:
                    if condition.min_days.value > condition.max_days.value:
                        issues.append(ValidationIssue(
                            severity=Severity.ERROR, code="INVALID_APPLICABILITY_RANGE",
                            message=(
                                f"DaysBeforeArrivalCondition {condition.id} on PricingRule {rule.id} has "
                                f"min_days ({condition.min_days.value}) > max_days ({condition.max_days.value})."
                            ),
                            entity_id=condition.id,
                        ))
            elif isinstance(condition, AgeCondition):
                if condition.min_age is not None and condition.max_age is not None:
                    if condition.min_age.value > condition.max_age.value:
                        issues.append(ValidationIssue(
                            severity=Severity.ERROR, code="INVALID_APPLICABILITY_RANGE",
                            message=(
                                f"AgeCondition {condition.id} on PricingRule {rule.id} has "
                                f"min_age ({condition.min_age.value}) > max_age ({condition.max_age.value})."
                            ),
                            entity_id=condition.id,
                        ))
    return issues


ALL_CHECKS = [
    check_every_room_has_a_base_rate,
    check_no_overlapping_rates,
    check_occupancies_are_closed,
    check_no_low_confidence_values_in_final_model,
    check_no_circular_supersession,
    check_no_dangling_restriction_references,
    check_min_max_stay_is_valid,
    check_applicability_condition_ranges_are_valid,
]


def validate(scope: ContractScope) -> list[ValidationIssue]:
    """Runs every registered invariant check and returns the combined issue
    list. Adding a new invariant means adding one function above and
    registering it in ALL_CHECKS — nothing else in the system needs to change."""
    issues: list[ValidationIssue] = []
    for check in ALL_CHECKS:
        issues.extend(check(scope))
    return issues


def has_blocking_errors(issues: list[ValidationIssue]) -> bool:
    return any(i.severity == Severity.ERROR for i in issues)
