"""
Aggregates per-field confidence into a single picture of how trustworthy a
draft ContractScope is, before deciding whether it's ready for validation
or needs review_ui first. Kept separate from invariants.py deliberately:
invariants are pass/fail structural rules, confidence is a continuous
signal about extraction quality — different kinds of checks, different files.

M0: now aggregates every Extracted[T] field in the scope via
entities.iter_extracted(), not just Rate.amount — same shared traversal
invariants.py uses, so the two never drift on "where do Extracted values
live in this model."
"""

from __future__ import annotations
from dataclasses import dataclass

from contract_platform.contract_model.entities import ContractScope, iter_extracted
from contract_platform.contract_model.vocabulary import ConfidenceLevel


@dataclass
class ConfidenceReport:
    total_extracted_values: int
    high: int
    medium: int
    low: int

    @property
    def needs_review(self) -> bool:
        return self.low > 0


def assess(scope: ContractScope) -> ConfidenceReport:
    counts = {ConfidenceLevel.HIGH: 0, ConfidenceLevel.MEDIUM: 0, ConfidenceLevel.LOW: 0}
    total = 0
    for _entity_id, _field_name, extracted in iter_extracted(scope):
        counts[extracted.confidence] += 1
        total += 1
    return ConfidenceReport(
        total_extracted_values=total,
        high=counts[ConfidenceLevel.HIGH],
        medium=counts[ConfidenceLevel.MEDIUM],
        low=counts[ConfidenceLevel.LOW],
    )
