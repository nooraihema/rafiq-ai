# M0 — Foundation Hardening: Status

This applies the Phase 1 critique fixes from the frozen Architecture &
Engineering Roadmap (Part 8, M0) on top of the existing Phase 1 foundation.
No architecture decisions were revisited — this milestone only brings the
implementation shape in line with what was already agreed.

## What changed from Phase 1 (17/17 tests pass, zero PDFs involved)

- `contract_model/entities.py`
  - `Extracted` is now generic (`Extracted[T]`) and carries an optional
    `Provenance` (page/table/row/column/raw_text/extraction_method).
  - Applied beyond `Rate.amount`: `Season.start_date`/`end_date`,
    `Occupancy.adults`/`children`/`infants`, `PricingRule.calculation`,
    and every typed-`Restriction` value field.
  - `AgeBand` demoted from an id-bearing entity to a frozen value type,
    inlined on `Occupancy.child_age_band`.
  - `Offer`, `Supplement`, `ChildPolicyRule` merged into one entity,
    `PricingRule`, discriminated by `RuleKind` (`CHILD_POLICY`,
    `SUPPLEMENT`, `SPO_OFFER`). `ContractScope.pricing_rules` replaces the
    three old separate lists.
  - `Restriction` converted from `detail: dict` to a sealed set of typed
    dataclasses: `BlackoutPeriod`, `CombinabilityRule`, `ReleaseRule`,
    `MinMaxStay`.
  - `ContractScope.supersedes_contract_id` added.
  - Added `iter_extracted(scope)`, a single shared traversal of every
    `Extracted[T]` field in a scope, used by both validation and
    confidence reporting so they can't drift on "where do these values live."

- `contract_model/expressions.py` — added `Min`, `Max`, `Round` (with
  `RoundMode` in `vocabulary.py`).

- `expression_engine/evaluator.py` — `evaluate()` converted from an
  `if isinstance(...)` chain to registry dispatch (`NODE_EVALUATORS` +
  `@register_node`). A new node type is now one dataclass plus one
  decorated function; zero lines change in existing evaluator code
  (proven by `test_evaluator_is_registry_dispatch_not_an_isinstance_chain`,
  which registers and later unregisters a throwaway node type).

- `validation/invariants.py` — added the three remaining invariants from
  the final set: `CIRCULAR_SUPERSESSION` (PricingRule chains + the trivial
  ContractScope self-reference case), `DANGLING_RESTRICTION_REFERENCE`,
  `INVALID_MIN_MAX_STAY`. The LOW-confidence check now walks every
  `Extracted[T]` field via `iter_extracted`, not just `Rate.amount`.

- `validation/confidence.py` — same shared-traversal fix.

- `contract_model/schema_version.py` — CHANGELOG entry appended
  documenting the M0 shape change; version stays at draft `1.0.0` — M3 is
  where the roadmap says to formally tag stability, not M0.

## Explicitly not touched

`document_parser`, `semantic_adapters`, `pricing_engine`, `review_ui`,
`registry` remain empty packages — untouched, as they should be; nothing
in them depended on the old shapes yet, which is exactly why the roadmap
called M0 the cheapest possible moment to make this change.

## Test coverage added for M0

All new invariants, `PricingRule`/`RuleKind`, typed `Restriction`,
`AgeBand`-as-value-type, `Min`/`Max`/`Round` (including the real
single+2child-capped-at-double clause shape), and registry-dispatch
extensibility each have a direct test in
`tests/test_model_and_expressions.py`. The dependency-boundary test is
unchanged (it's a generic file scanner) and still green.

## Next: M1 — Walking Skeleton: EXIM

Build `semantic_adapters/exim/adapter.py` + `vocabulary.py` against the
now-hardened Model, wired through `document_parser`, producing a validated
`ContractScope` that flows through a minimal `pricing_engine/calculator.py`
to one correct invoice line for DR01 (46.00 USD PPPN).

---

# M1 — Walking Skeleton: EXIM — Status: COMPLETE

Full vertical slice, built and proven against the real
`Exim_S26.pdf` (Amarina Jannah Resort & Aqua Park, RMF90025), room DR01
only, per the M1 scope decision.

**Pipeline:** `document_parser/pdf_reader.py` (pdfplumber, zero business
knowledge — just page text) → `semantic_adapters/exim/{vocabulary,adapter}.py`
(EXIM-specific regex parsing of the Units table, the free-text Room
Occupancy combo block, and the per-room Rates block) → `ContractScope`
(DR01: 1 RoomType, 7 valid Occupancy combos, 1 Season, PPPN + SOPN Rates)
→ `validation.validate()` → `pricing_engine/calculator.py` (booking-time
checks + `evaluate(RateRef(...))` through `expression_engine`, never a raw
float) → `Invoice`.

**Proven end-to-end (`tests/test_exim_walking_skeleton.py`, real PDF
fixture in `tests/fixtures/Exim_S26.pdf`):**
- DR01 PPPN extracted as exactly `46.00`, HIGH confidence, Provenance
  pointing at page 3.
- A real 7-night / 2-adult booking prices to `644.00 USD` via
  `RateRef` → `expression_engine.evaluate()`, not a shortcut float.
- Invalid occupancy (5 adults) and out-of-season dates are rejected by
  booking-time validation before pricing ever runs.

**Bug found and fixed during this milestone (implementation bug, not
architecture — see classification below):** `check_no_overlapping_rates`
(Invariant #2) originally keyed only on `(room_type_id, season_id,
market_id)`. Real DR01 data has both a PPPN Rate and a SOPN Rate for the
same room/season — legitimate, not a duplicate; `Rate.basis` exists
precisely to distinguish them. Fixed by adding `basis` to the key, with a
regression test (`test_pppn_and_sopn_rates_coexist_without_triggering_duplicate_rate`).
No architecture change; classified and fixed in place per the M1 ground rule.

**Deliberately deferred to M4 (full coverage), not implemented here:**
3rd/4th-adult amount-reduction and child-percentage-reduction rate
columns are parsed and proven against real data (`RATE_COLUMN_CODE_RE`
correctly tokenizes all of them, verified against DR01/DR05/DR07/DR08),
but not yet turned into `PricingRule` objects, and EXIM's `MinMaxStay`
(3/999 nights, page 5) is not yet extracted as a `Restriction`. Neither
was required to prove the one invoice number M1 targets; both are cheap
to add once M4 extends coverage to the full room set — classified as
**Future enhancement**, not a gap in this milestone.

**Exit criteria met:** end-to-end test green; dependency-boundary test
still green (`pricing_engine` and `document_parser` show zero imports
from `semantic_adapters`).

## Next: M2 — Walking Skeleton: Anex

Same pipeline against Anex's real Double Room + 50% child clause —
proves the architecture survives a structurally different TO. Anex's
document/contract file is needed to proceed.

---

# M2 — Walking Skeleton: Anex — Status: COMPLETE

Full vertical slice, built and proven against the real
`Anex_Tours_-_EE_CIS___RSS_-S26.pdf` (Amarina Jannah Resort & Aqua Park,
Anex Tourism Worldwide DMCC). Deliberately structurally different from
EXIM's data shape — that difference is the entire point of this milestone.

**What's structurally different from EXIM, proven against real data:**
- Base rates are keyed off **date ranges within a Market** (East European
  vs. Russia & CIS), not a fixed room-code table — the real data that
  originally justified `Market` as a first-class entity (Part 2).
- Room categories are **Supplements layered on one "Promo Room" base**,
  not independent rows (only Promo Room modeled in M2; Standard/Superior/
  Deluxe/Family/Suite supplements deferred to M4).
- Occupancy is written as `"2 ADL+2CHD OR 03ADL"` — the exact string shape
  Part 5's worked example uses, now confirmed against a real contract, not
  a hypothetical.
- Child pricing is **prose**, not numeric columns: "02 Adult + 02 Children
  (06-12.99): Double Room Rate + 50 % P.P IN DBL" — parsed into the same
  `Add(RateRef, PercentOf(RateRef, Constant(50, PERCENT)))` Expression tree
  the M0 test already proved evaluates correctly, now adapter-sourced from
  the real PDF instead of hand-built.
- The Russia & CIS rate table's rows **continue onto the next page without
  repeating their own market header** — `parse_room_rate_rows` carries
  "current market" state across the page boundary to handle this; a real
  layout quirk, not a hypothetical edge case.

**Proven end-to-end (`tests/test_anex_walking_skeleton.py`, real PDF
fixture in `tests/fixtures/Anex_S26.pdf`):**
- Promo Room PPPN for East European, 21.05.2026-28.06.2026 = exactly
  `62.00`, matching the real "Per Person in DBL" column.
- The Double Room + 50% child clause evaluates to exactly `93.00` — the
  milestone's target number — through `expression_engine.evaluate()`,
  completely unmodified from M1.
- All 9 real date-range rows (4 East + 5 Russia & CIS) independently
  produce a correctly-evaluating child-policy rule (`rate * 1.5`), not
  just the one hand-verified season.
- `pricing_engine.price_booking()` prices a real 3-adult Anex booking
  (the `03ADL` combo actually printed in the source) with **zero code
  changes** to `pricing_engine` or `expression_engine` — the roadmap's
  explicit M2 success criterion, verified by using the identical function
  M1 used for EXIM.
- `document_parser` was reused completely as-is — proven by a structural
  test asserting no Anex- or EXIM-specific text appears in it.

**Deliberately deferred to M4, not implemented here:** Standard/Superior/
Deluxe/Family/Suite room supplements; the other 10 Children Policy rows
(Single/Triple/Family/Quadruple); the Min-node "IN CASE SINGLE + 2 CHILD
RATE IS MORE THAN DOUBLE" clause (needs a modeled Single Room to compare
against — the 60% Single Supplement column is real, parseable data,
confirmed present, just not wired up yet).

**Architectural observation found during this milestone — flagged, not
acted on:** applying a `CHILD_POLICY` `PricingRule` to a real booking
eventually requires matching the booking's child ages against the rule's
target age band. `PricingRule`'s current field set (Part 2: `kind`,
`room_type_id`, `season_id`, `label`, `calculation`, `issued_date`,
`valid_from`, `valid_to`, `supersedes_rule_id`) has no structured place to
put that condition — today it only lives in the free-text `label`, which
`pricing_engine` can't machine-check. M2 avoided needing this by evaluating
the rule's `Expression` directly rather than having `pricing_engine`
auto-select among rules. This will need a real decision once M4 or a
later milestone needs `pricing_engine` to pick the *right* `PricingRule`
automatically — most likely either a structured age-band field on
`PricingRule` or a new typed `Restriction`/condition. **Not proposing a
change now** — this is exactly the kind of thing the roadmap says to
surface and wait on real pressure for, not act on speculatively.

**Exit criteria met:** both EXIM and Anex end-to-end tests green
simultaneously (30/30 total); dependency-boundary test still green.

## Next: M3 — Contract Model v1 Stable

Formal checkpoint per Part 8: since both structurally different TOs now
pass, declare the schema stable, bump `schema_version.py` to `1.0.0`
officially tagged, and write the ADR documenting what changed since M0.
No new extraction work — this is a stop-and-confirm gate.

---

# M3 — Architectural Validation: Alltours — Status: COMPLETE

Third consecutive real TO, structurally different again — this time not
in the domain shape but in the *source format*: `Alltours_Amarina_Jannah_
S2026.pdf` has **zero embedded text on every page** (confirmed: native
pdfplumber extraction returns 0 characters). This is a scanned image, not
native-text PDF.

**Result: `contract_model`, `pricing_engine`, and `expression_engine` were
not touched.** Confirmed by a structural test asserting no "alltours"
string appears in any of those three modules. Only `document_parser`
gained one legitimate, TO-agnostic capability (OCR fallback), and a new
`semantic_adapters/alltours` package was added — exactly the architecture's
claimed shape of change, third time running.

**What required extending `document_parser` (not `contract_model` or
`pricing_engine`):** an OCR fallback, used automatically whenever a page's
native text layer is empty/near-empty. This is explicitly within
`document_parser`'s already-stated scope ("Raw grid reconstruction from
PDF/Excel/Word/**image**", Part 1) — still zero business knowledge, same
category of operation as pdfplumber's native extraction, and it required
no change to any adapter-facing interface (`RawPage` gained an
`extraction_method` field with a safe default; `read_pdf_pages` gained an
optional `page_numbers` parameter with a safe default). EXIM's and Anex's
tests are unaffected and still green.

**Two real OCR engineering problems found and fixed, both empirically
reproducible against the actual file (not speculative):**
1. Rendering the page image in-memory OCR'd measurably worse than saving
   it to a temp PNG and reloading before OCR (a specific date token
   misread without the round trip, correct with it, consistently across
   repeated runs). Fixed inside `document_parser`.
2. "DZP" consistently OCR's as "pzp" in this document's font (a genuine
   character-shape confusion, not random noise). Fixed with a small,
   explicitly-scoped OCR-alias table inside `semantic_adapters/alltours/
   vocabulary.py` — a document-specific workaround in the one place that's
   supposed to hold document-specific workarounds, not a general
   text-matching strategy leaking into `document_parser`.

**Proven end-to-end (`tests/test_alltours_walking_skeleton.py`, real PDF
fixture in `tests/fixtures/Alltours_S26.pdf`, OCR restricted to page 1 —
confirmed that's where every value this milestone needs actually lives):**
- Hotel, tour operator, contract validity, and **currency = EUR** (the
  first real non-USD data point across all three adapters — proof
  `ContractScope.currency`/`Rate.currency` were always genuinely
  TO-agnostic, not USD-shaped in practice).
- DZP room rates for all 3 real periods: **72.00 / 66.00 / 80.00 EUR**,
  read via OCR and matching the printed table exactly.
- Period I is genuinely split across two disjoint calendar ranges in the
  source (low season on both ends of summer) — modeled as two `Season`
  objects sharing a label, the same pattern M1 used for EXIM's
  contract-level period; no Model change needed.
- The stacked min/max occupancy cell doesn't OCR reliably enough to trust
  — correctly flagged **LOW confidence** with a clear `source_note`
  rather than guessed, per Part 5. `validate()` surfaces this as a
  `WARNING`, not a blocking `ERROR` — the draft scope is legitimate, not
  silently treated as final.
- OCR-sourced values default to **MEDIUM** confidence system-wide in this
  adapter (a stated policy, not a per-field judgment call) — reflecting
  that OCR is inherently less certain than a native text layer even when
  a value looks clean.
- `pricing_engine.price_booking()` prices a real Alltours booking with
  the exact same function used for EXIM and Anex, zero changes.

**Deliberately deferred to M4, not implemented here:** the other 9 room
rows; the precise occupancy stack (needs a targeted re-OCR strategy —
cropping to just that cell region at higher resolution is the likely
fix, not attempted here); Early Booking SPOs; child discount table;
Senior/Longstay reductions. All confirmed present and OCR-readable in the
source; out of scope for a one-room walking skeleton.

**Architectural discussion opened this milestone — explicitly not acted
on:** Alltours' Senior discount (age-conditioned) and Longstay discount
(stay-length-conditioned) are the third and fourth distinct kinds of
*rule-applicability condition* seen across three real contracts (after
EXIM/Anex's child-age and room/season scoping). The user's framing —
`PricingRule` owning a generic `RuleApplicability` evaluated before
`Calculation`, rather than accumulating dedicated fields per condition
type — is noted as the leading candidate for M4's design work, once
`pricing_engine` actually needs to auto-select among competing rules
(which M2 and M3 both avoided by evaluating specific rules directly). No
change made to `PricingRule` in this milestone.

**Exit criteria:** all three TOs' end-to-end tests green simultaneously
(37/37 total); dependency-boundary test still green; zero lines changed
in `contract_model`, `pricing_engine`, or `expression_engine`.

## Next

Either M3's formal stability checkpoint (schema version tag + ADR) or a
fourth TO if one becomes available before that. The applicability-layer
question above should get a real design pass before M4 starts building
PricingRules at volume, once there's enough real-contract evidence to
commit to a shape (age condition? stay-length condition? both share a
generic form, or are they different enough to need different
representations? — worth resolving with evidence, not speculation).

---

# Foundation Hardening II (pre-M4) — Status: COMPLETE

Triggered by a fourth real contract (TUI/Travco) whose Early Bird offer
made explicit, textual, and impossible-to-defer two gaps that had been
building since M2 (Anex) and sharpened at M3 (Alltours): **PricingRule
had no way to say when/whether it applies**, and **no way to say how it
combines with another rule that also applies**. Four independent, real
contracts converged on the same two questions — evidence, not
speculation — so this was resolved before M4 builds PricingRules at
volume, following the same "fix the Model before more code depends on
it" logic M0 used.

## What changed

**`contract_model/entities.py`** — `PricingRule` gained one new field:
`applicability: list[ApplicabilityCondition]` (default: empty list, i.e.
"always applies" — the correct default and the reason existing rules
need no changes). `ApplicabilityCondition` is a new sealed typed union,
same pattern as `Restriction`:
- `StayLengthCondition` (TUI Early Bird "1-365 nights"; Alltours Longstay)
- `BookingDateCondition` (TUI Early Bird "24/07/2025 to 30/04/2026")
- `DaysBeforeArrivalCondition` (present as a distinct field in TUI's own
  schema, confirmed real vocabulary even though blank in this contract)
- `AgeCondition` (role: the existing `GuestType` enum + min/max age —
  unifies Anex/EXIM/Alltours child bands and Alltours' Senior discount
  under one shape, since both are "does a guest's role+age fall in this
  range")

Deliberately **not** modeled (see the architecture review this followed
for the full reasoning): child *position* (1st/2nd child — no real
`pricing_engine` need yet to disambiguate multiple children), and TUI's
charge-component scope checkboxes (Room Rate vs. Board Supplements vs.
Gala — reclassified as a composition concern, not applicability, and no
`Fee`/`Gala` concept exists anywhere in the Model to hang it on yet).

**`pricing_engine/applicability.py`** (new) — `rule_applies(rule,
booking) -> bool`. Answers exactly one question, for one rule against one
booking. Fail-safe: a condition needing a fact the booking doesn't supply
(e.g. no `booking_date`) means the rule does **not** apply — a
conditional discount must never fire when eligibility can't be verified.

**`pricing_engine/composition.py`** (new) — `order_rules()` +
`DEFAULT_COMPOSITION_ORDER`, an explicit, named, swappable ordering table
(`CHILD_POLICY` → `SUPPLEMENT` → `SPO_OFFER`), evidenced directly by
TUI's "Combinable with Free Night" clause (child/occupancy adjustments
compute first and become the base other discounts apply against).
Deliberately **not** expressed as an implicit property of `RuleKind`'s
declaration order — `RuleKind` stays a pure classification with no
precedence meaning of its own, proven by a structural test asserting the
words "order"/"precedence"/"composition" never appear in `RuleKind`'s
own source. Applicability and Composition never call each other; each is
independently testable and independently replaceable.

**`pricing_engine/calculator.py`** — `BookingRequest` gains one new
**optional** field, `context: Optional[BookingApplicabilityContext] =
None`. `BookingApplicabilityContext` is a new, separate object
(`booking_date`, `guest_ages: list[GuestAge]`) holding exactly what an
`ApplicabilityCondition` might need to check, kept deliberately apart
from `BookingRequest`'s core identity (room, dates, party size) so future
condition types extend that object, not `BookingRequest` itself — the
core booking shape stays stable regardless of how many condition kinds
get discovered later. `price_booking()` stays a thin orchestrator: it
finds candidate `CHILD_POLICY` rules and delegates to
`applicability.rule_applies` and `composition.order_rules`; it contains
no eligibility or ordering logic of its own. With no `context` and no
children — every pre-existing call site across all three adapters —
behavior is byte-identical to before this change.

**`semantic_adapters/anex/adapter.py`** — the one adapter change this
pass required: its existing `CHILD_POLICY` rule now carries a structured
`AgeCondition(role=CHILD, min_age=6, max_age=12.99)` instead of that
range living only in the free-text `label`. EXIM's and Alltours' adapters
are **unchanged** — neither has ever built a `PricingRule`.

**`validation/invariants.py`** — one new invariant (#8): every
`ApplicabilityCondition` range must be internally consistent (min ≤
max), same shape as the existing `MinMaxStay` check. `iter_extracted()`
extended to walk the new condition fields, keeping confidence reporting
accurate.

## What stayed completely unchanged

`expression_engine` (zero changes — conditions are evaluated as plain
predicates outside the `Expression` tree; no new node type needed),
`document_parser`, `contract_model.expressions`, `registry`, `review_ui`,
and the EXIM and Alltours adapters.

## Proven (`tests/test_applicability_and_composition.py`, 12 new tests
plus the full existing 37 unchanged and still green — 49/49 total)

- Each condition type matches and rejects correctly in isolation,
  including the fail-safe case (no `booking_date` → rule doesn't apply).
- Multiple conditions on one rule AND correctly.
- `order_rules()` respects the default order and accepts a custom one.
- Structural proof `RuleKind` carries no ordering semantics of its own.
- The new invariant fires on an inverted range.
- **Full backward compatibility**: a booking with no `context` reproduces
  the exact pre-change invoice against the real Anex PDF.
- **First real end-to-end proof of a `PricingRule` flowing through
  `price_booking()` itself** (not evaluated by hand in a test, which is
  all M2 could do before this): a real 2-adult/2-child Anex booking,
  using the actual printed "2 ADL+2CHD" occupancy combo, correctly prices
  a base line (62.00 × 7 × 2) and exactly one child line (93.00 × 7) for
  the child whose age falls in the real 06–12.99 band — the second child
  outside that band correctly gets no line, not a guessed one.

## Honest limitation carried forward, not solved here

No real contract data yet shows two `PricingRule`s simultaneously
applicable to the same booking — Anex's is still the only real
`PricingRule` in the system. `composition.order_rules()` is implemented
and unit-tested against synthetic multi-rule cases, but `calculator.py`'s
actual pricing path only exercises the single-rule case end-to-end today.
Full multi-rule threading through one invoice remains deferred until a
real contract forces the shape of that decision — building it now, with
zero real cases to validate against, would be exactly the speculative
work this pass was designed to avoid.

## Next: M4

Full room/rate coverage across all four TOs, now against a Model that
can hold every condition kind seen so far. `PricingRule` volume at scale
is the real stress test for both `applicability.py` (many rules per
room/season) and the still-unproven multi-rule composition path.

## Refinement: applicability dispatch converted to registry pattern

Before closing this pass out, `applicability.py`'s dispatch was corrected
from an `if/elif isinstance(...)` chain to registry dispatch
(`CONDITION_MATCHERS` + `@register_condition`), mirroring
`expression_engine/evaluator.py`'s `NODE_EVALUATORS` pattern exactly —
the isinstance chain was the identical shared-chokepoint problem M0 had
already fixed once for `evaluate()`, reintroduced here by not noticing
the parallel at the time. A fifth condition type is now one new
dataclass plus one `@register_condition` function; zero lines change in
existing code, proven by a test that registers and unregisters a
throwaway condition type mid-test, mirroring M0's identical proof for
the evaluator.

Deliberately kept as an independent registry rather than sharing generic
dispatch infrastructure with `evaluator.py`: the two have opposite
failure philosophies on a miss (`evaluator.py` raises — an unrecognized
`Expression` node must fail loudly; `applicability.py` returns `False` —
an unrecognized condition must fail *safely*, never silently letting a
rule apply when eligibility can't be verified). Unifying them would need
a parameter just to configure that difference, more complexity than the
small amount of duplicated dict-plus-decorator infrastructure it would
save. Behavior-preserving: all 49 prior tests pass unchanged, plus 2 new
ones proving the registry property and the fail-safe-on-unknown property
directly (51/51 total).

Foundation Hardening II is now considered complete. Next: validate the
resulting design against a fifth real contract, rather than continuing
to accumulate adapters against the pre-hardening shape.

---

# Post-Odeon-review fixes: cross-period "Stay" pricing + SOPN consumption

Two `pricing_engine`-only implementation gaps, found while reviewing the
Odeon contract, confirmed real via direct verification before
implementing (both checks documented in the review conversation, not
skipped):

**Cross-period "Stay" pricing.** `price_booking()` previously required
one single `Season` to contain an entire stay, rejecting any booking
spanning a period boundary outright. Verified this is a genuine base-rate
policy, not an offer-only setting, by checking where "Stay" actually
appears in the Odeon contract: it labels the **base rate table's own
period columns** (Section 3), not just the one Early Booking offer —
ruling out narrowing the fix to offer logic only. Before implementing,
grepped every `BookingRequest` across all 5 test files and confirmed none
relied on "must fit in one Season" as an assertion; the sole
`DATES_OUTSIDE_SEASON` test (EXIM, December dates) has zero overlap with
any season at all, a different case entirely. Rate resolution is now
per-night (`_rate_for_night`, `_split_stay_into_segments`), producing
exactly one segment for every pre-existing single-season case — proven
identical by re-running M1's and M2's exact real-PDF scenarios unmodified
— and multiple segments (one invoice line each) for a stay spanning a
boundary.

**SOPN consumption.** `Rate.basis == SINGLE_OCCUPANCY_PER_NIGHT` has been
extracted by the EXIM adapter since M1 (DR01's real 73.60 value) but
`price_booking()` only ever selected `PER_PERSON_PER_NIGHT`. A 1-adult
booking now prefers a SOPN rate when the room/season defines one, falling
back to PPPN otherwise — purely additive, since every other adapter
(Anex, Alltours, Rocket, Touring) has no SOPN rates at all.

**Scope, exactly as requested:** `pricing_engine/calculator.py` only. No
`contract_model`, `expression_engine`, or adapter changes. 8 new tests
(`tests/test_pricing_engine_rate_resolution.py`) cover: single-season
unaffected, boundary-crossing split, a genuine gap still rejected, both
EXIM's and Anex's exact real-PDF scenarios re-verified identical, SOPN
selected/not-selected/falls-back-safely. 59/59 total, 51 pre-existing
unchanged.

---

# Market disambiguation fix (pre-M4)

The last item from the architecture-phase closeout: Anex's Promo Room has
two Markets (East European, Russia & CIS) with overlapping-date Seasons
that genuinely disagree in price — confirmed against the real PDF before
implementing, not assumed: both give different July 2026 rates (74.00 vs.
68.00) for the exact same calendar nights. `_rate_for_night` previously
had no way to prefer one Market over the other and resolved the ambiguity
by `scope.rates` construction order — correct only where test data
happened to tie, not by design.

**Fix:** `BookingRequest` gained one new optional field, `market_id`. This
is a core booking-identity fact (which market a booking is sold through),
not an `ApplicabilityCondition` — it lives on `BookingRequest` directly,
not `BookingApplicabilityContext`, keeping that object's purpose
("facts a condition might check") distinct from rate-selection routing.
Rates with `market_id=None` (every non-Anex adapter today: EXIM, Alltours,
Rocket, Touring) stay eligible regardless of the booking's `market_id`, so
the fix is additive everywhere except Anex. Omitting `market_id` entirely
reproduces the exact pre-fix behavior — every existing test passes
unchanged.

**A test-precision issue found along the way:** this fix's docstring
legitimately cites Anex's real "Promo Room" as evidence, which tripped
the M3 structural test's artifact list (`"promo room"` had been assumed
Alltours-specific but isn't — Anex, EXIM, Rocket, and Odeon all use the
same room name). Same category as the earlier "alltours"-string-ban
false positive: fixed the test's artifact list, not the legitimate
cross-contract citation.

**Tests:** 4 new (`test_pricing_engine_rate_resolution.py`) — unspecified
`market_id` reproduces pre-fix behavior exactly (re-running M2's real
scenario unmodified), specifying `market_id` correctly selects the
differing real rate for each market, and market-agnostic Rates stay
eligible regardless of requested market. **62/62 total, 58 pre-existing
unchanged** (1 test-precision fix, not a regression).

---

# Architecture phase: complete. Transitioning to M4.

Eight real contracts reviewed (EXIM, Anex, Alltours, TUI, Touring, Rocket,
Eden, Odeon) across two rounds of Foundation Hardening. Remaining known
implementation risk, explicitly mapped rather than pre-built, to be
resolved as **M4 checkpoints** — validated the moment real construction
produces each case, not before:

- **Multiple `RuleKind`s on one room** → validate multi-rule
  **composition** (`order_rules()` has never combined two real,
  simultaneously-applicable rules — Anex's `CHILD_POLICY` is still alone).
- **Position-differentiated child rules** (1st/2nd child, same age band —
  evidenced in 4 of 8 contracts) → validate guest-to-rule **assignment**
  in `_child_policy_lines` (a Pricing Engine correctness question, not a
  Model gap — no `AgeCondition.position` field implied).
- **`CombinabilityRule`** (evidenced 3 times: Touring, Rocket, Eden) →
  build only when a real adapter's data forces its exact shape.

No further Contract Model changes proposed. Any future evolution is
driven by concrete M4 implementation evidence, not speculative
contract review.

---

# M4, Slice 1 — EXIM full room coverage: COMPLETE

Deliberately narrow, per the agreed plan: extend EXIM from DR01-only to
all 15 real rooms, validate at full scale, price representative bookings
across diverse rooms. **No new `PricingRule` construction in this
slice** — confirmed by a dedicated test (`scope.pricing_rules == []`).

**Two real EXIM-adapter bugs found and fixed** (both in
`find_rate_block_for_room`, `semantic_adapters/exim/adapter.py` — neither
a Contract Model or Pricing Engine issue):

1. A page-level `if "Rates" not in page.text: continue` pre-filter
   silently skipped page 4 — a continuation of the same Rates table that
   doesn't re-print the section header. FR04's real rate row lives there
   and was unfindable. This had never surfaced because M1's DR01-only
   scope happened to sit entirely on page 3.
2. Removing that filter naively then let the *Units table*'s occurrence
   of a room's header line (which matches the same intentionally-loose
   `ROOM_RATE_HEADER_RE`, since the adapter reuses it for Units too) sit
   earlier in page order and shadow the real Rates-table occurrence —
   every room started returning an empty block. Fixed by discriminating
   candidate blocks by **content** (must contain "PPPN" or "SOPN") rather
   than by page-level text, which correctly excludes Units/Facilities/
   Allocation sections regardless of page layout.

Both were found immediately on first attempt at real multi-room coverage
— exactly the kind of thing this slice was designed to surface cheaply,
before any `PricingRule` work depends on it.

**Proven (`tests/test_exim_full_room_coverage.py`, 7 tests):**
- All 15 real rooms parse successfully; PPPN cross-checked against the
  real source table for every one, not spot-checked.
- Full 15-room `ContractScope` validates with zero blocking errors — the
  first real test of the model-level invariants at actual multi-room
  scale rather than 1-2 hand-built rooms.
- Rooms explicitly enumerated in the source's free-text occupancy block
  (DR01/DR05/DR07/DR08/DR09/FR02/SU02) retain every real combo at HIGH
  confidence; rooms the document doesn't name (all 6 Single rooms, DR10,
  FR04) correctly fall back to the documented M1-era LOW-confidence
  single-combo path — proving that fallback is genuinely conditional,
  not a blanket default, now exercised at scale for the first time.
- 5 representative bookings price correctly across diverse rooms,
  including SR01 correctly engaging the SOPN path (73.60, not a lower
  PPPN figure) and DR09 independently resolving the same rate as DR01
  without cross-contamination between the two RoomTypes.

**Exit criteria:** 69/69 tests total, 62 pre-existing unchanged.
Dependency-boundary test still green.

## Next: M4, Slice 2

The first real `SUPPLEMENT` or additional `CHILD_POLICY` rule — the
natural, evidence-driven trigger for the first M4 checkpoint (generalize
`calculator.py`'s rule-consumption path beyond the current
`CHILD_POLICY`-only filter).

---

# M4, Slice 2 — First real SUPPLEMENT rule: COMPLETE

**Evidence-driven pivot from the original plan.** Before implementing,
checked both EXIM (AMR: "3A AmR pN"/"4A AmR pN") and Alltours ("for 3rd.
adult reduction") for a genuinely position-*independent* SUPPLEMENT case,
to keep Checkpoint 1 (non-`CHILD_POLICY` consumption) isolated from
Checkpoint 3 (guest-position assignment) as originally hoped. **No such
case exists in the real data** — every non-`CHILD_POLICY` rule available
in a built adapter is positional (applies to a specific numbered guest
slot), in two independent TOs. Following the evidence, this slice does
both checkpoints together, scoped as narrowly as the real data allows:
adults only (no age-band matching, unlike children), one adapter (EXIM),
no new adapter work.

**Contract Model change, evidence-justified:** `PricingRule` gained one
new field, `applies_to_pax_number: Optional[int] = None`. Checked before
adding: not an `ApplicabilityCondition` (it doesn't gate *whether* a rule
applies to the booking — every booking with enough adults has a "3rd
adult" slot), not solvable in the adapter alone (the adapter can extract
the number and amount, but nothing in `pricing_engine` could assign it to
the right guest without this field). Justified by the same evidence bar
Foundation Hardening II required: two independent real TOs expressing the
identical shape. `None` (every rule before this slice, including Anex's
`CHILD_POLICY`) means "not positional" — zero behavior change for
anything already built.

**`pricing_engine/calculator.py`:** new `_adult_lines()` helper
generalizes base-rate consumption. A room with no positional rules for
its season (every room built before this slice) produces exactly the
same single invoice line as before — proven directly, not just assumed.
A room with a real positional `SUPPLEMENT` rule now correctly splits into
a standard-adults line plus one line per matched positional slot,
evaluated through `expression_engine`, never a raw float.

**Two Slice-1 tests corrected, not weakened** — both were asserting
values that predate this real data, not testing something this slice
broke:
- `test_no_pricing_rules_were_built_in_this_slice` was Slice 1's
  deliberate scope boundary marker; correctly no longer true now that
  Slice 2 has built real rules. Replaced with a test of what actually
  matters now — positional rules don't leak into bookings they don't
  apply to.
- DR09's 3-adult case was asserting `46.00 × 7 × 3` — **actually wrong**
  once AMR is honored; the real contract's data means the 3rd adult
  should price at 40.00, not 46.00. Corrected to the true total
  (924.00, not 966.00) — a genuine correctness improvement the previous
  slice's test data simply didn't know about yet.
- One M1-era structural test (`..._never_uses_a_raw_float...`) checked
  `price_booking`'s own source text for `"evaluate("`; the refactor
  correctly moved that call into `_adult_lines()`. Updated to check the
  full call chain rather than one function's source in isolation — same
  underlying property, still proven true.

**Tests (`tests/test_exim_supplement_rules.py`, 7 new):** real AMR data
produces a correct SUPPLEMENT rule; validates cleanly; a real 3-adult
DR01 booking splits into standard + reduced lines with the exact correct
total; a 2-adult booking on the *same* room is completely unaffected;
Anex (zero `SUPPLEMENT` rules anywhere) is provably byte-identical to
before this slice; a rule doesn't leak across rooms in a multi-room
scope; the new field defaults to `None`.

**Exit criteria:** 76/76 total, 69 pre-existing (2 corrected for real
accuracy, not regressed).

## Next: M4, Slice 3

EXIM's CHILD_PCT columns (1C2A/2C2A — real, position-*and*-age-dependent
child pricing, already parsed since M1, never built) — the natural
continuation now that pax-position assignment exists for adults; children
add the age-band dimension on top of it.

---

# M4, Slice 3 — EXIM CHILD_PCT rules: COMPLETE

Builds EXIM's `CHILD_PCT` columns ("1C2A 1R %R PN" / "2C2A 2R %R PN" etc.,
parsed since M1, never modeled) into real `CHILD_POLICY` `PricingRule`s —
the first rules that are both position- and age-dependent at once.

**No Contract Model change.** Checked first, per the same evidence
discipline as Slice 2: position (`child_n`, 1st/2nd child) reuses
`PricingRule.applies_to_pax_number`, added in Slice 2 for adults — exactly
the field the M4 checkpoint list predicted this would need, with
"no `AgeCondition.position` field implied." Age band (`age_range_n`, 1 or
2) becomes an `AgeCondition` built from the Units row's existing
`age_band_1`/`age_band_2` columns (e.g. DR05: `2-6` and `7-14`) — no new
field there either.

**`semantic_adapters/exim/adapter.py`:** new `CHILD_PCT` branch in the
rate-column loop, structurally parallel to Slice 2's `AMR` branch: guards
on `pppn_rate` already having been built (same real-data ordering
guarantee AMR relies on), builds `Subtract(RateRef(pppn), PercentOf(
RateRef(pppn), Constant(pct, PERCENT)))`, and attaches one `AgeCondition`
per rule from the matching Units-row age band.

**`pricing_engine/calculator.py`:** `_child_policy_lines` generalized to
match a child's *position* in `booking.context.guest_ages` (1-based,
party order — the same positional convention `_adult_lines` already uses)
against `PricingRule.applies_to_pax_number`, before falling back to
position-agnostic rules (`applies_to_pax_number is None` — every
`CHILD_POLICY` rule before this slice, i.e. Anex's). A party whose only
candidate rules are position-agnostic is unaffected, proven directly
against Anex.

**One Slice-2 test corrected, not weakened:**
`test_dr01_produces_a_real_supplement_rule_from_real_amr_data` asserted
`len(scope.pricing_rules) == 1` for DR01 — true only because DR01 had no
`CHILD_POLICY` rules yet. Now that this slice gives DR01 two real
`CHILD_PCT` rules, the assertion is narrowed to `SUPPLEMENT` rules
specifically (what the test actually verifies), not weakened or dropped.

**Proven (`tests/test_exim_child_pct_rules.py`, 6 new):** DR01 (1st-child
columns only, no 2nd-child row in the real data) produces exactly 2
`CHILD_POLICY` rules, both `applies_to_pax_number == 1`, both evaluating
to a fully-free child (100% reduction); DR05 (both 1st- and 2nd-child
rows) produces 4, with the real data point this slice exists to prove —
2nd child in the older band (7-14) is 50% reduced, not free, while the
1st child and the 2nd child's younger band are both 100%; the new rules
validate cleanly; a real 2-adult/2-child DR05 booking (ages 4 and 10)
prices the 1st child free and the 2nd child at half rate, not both the
same; a single-child booking matches the 1st-child position correctly
rather than falling through to the 2nd-child rule just because the age
band also matches; Anex's one position-agnostic `CHILD_POLICY` rule is
provably unaffected.

**Exit criteria:** 82/82 total, 76 pre-existing (1 corrected for the
reason above, not regressed). Dependency-boundary test still green. Full
15-room EXIM scope validates with zero blocking errors and produces 44
real `CHILD_POLICY` rules across every room with a Children's age-band
policy.

## Next: M4, Slice 4

Remaining EXIM-adjacent gap: `MinMaxStay` (3/999 nights, page 5),
deferred since M1, still not extracted as a `Restriction`. Beyond EXIM,
the three M4 checkpoints flagged after Architecture-phase-complete are
now two-thirds resolved (multi-`RuleKind` composition and
position-differentiated child-rule assignment both exercised by this and
Slice 2); `CombinabilityRule` (Touring, Rocket, Eden) remains the one
unbuilt case, waiting on a real adapter to force its exact shape.

---

# M4, Slice 4 — EXIM Min/Max Stay restriction: COMPLETE

Builds EXIM's contract-level Min/Max Stay clause (real data, page 5:
"01.05.26 31.10.26 All 3/999 ...") into a real `MinMaxStay` Restriction
and enforces it as a new booking-time check in `pricing_engine`.

**No Contract Model change.** `MinMaxStay` and its validation invariant
(#7: `min_nights <= max_nights`) have existed since M0; both
`RATE_DATA_LINE_RE` (a generic date/date/days/rest line shape, not
rate-specific) and `MIN_MAX_STAY_RE` have existed in `exim/vocabulary.py`
since M1, unused until this slice — this is purely wiring already-modeled
pieces together against real data, no new type or field anywhere.

**`semantic_adapters/exim/adapter.py`:** new `parse_min_max_stay()`,
called once per contract (not per room — the clause is printed once,
scoped "All", not repeated per room code, confirmed by inspecting the
real PDF's page 5). Reuses `RATE_DATA_LINE_RE` against the data row and
`MIN_MAX_STAY_RE` against its `rest` field, rather than a new
special-purpose regex for a shape the file could already parse. Produces
one `MinMaxStay` Restriction with `applies_to_contract_scope_id` set to
the scope's own id — the correct real scope, and the one
`DANGLING_RESTRICTION_REFERENCE` (invariant #6) already checks against.

**`pricing_engine/calculator.py`:** new
`check_stay_length_within_min_max_stay`, added to `BOOKING_TIME_CHECKS`
alongside the two existing checks, same shape: a stay whose night count
falls outside any contract-scoped `MinMaxStay` Restriction is a blocking
`ERROR` (`STAY_LENGTH_OUTSIDE_MIN_MAX_STAY`), caught by
`validate_booking` before `price_booking` ever runs — never silently
priced. Restriction-level min/max-stay scoped to a specific `PricingRule`
or `Rate` (the type's other two `applies_to_*` fields, present since M0)
is deliberately not checked here — no real adapter has ever populated
them, so building that path now would be speculative, not
evidence-driven.

**Proven (`tests/test_exim_min_max_stay.py`, 6 new):** the real "3/999"
clause becomes exactly one HIGH-confidence, contract-scoped `MinMaxStay`
Restriction; it validates cleanly; a multi-room scope still produces
exactly one Restriction, not one per room; a 2-night booking (below the
real minimum) is rejected at booking-time validation and raises
`PricingError` before pricing runs; a booking at exactly 3 nights (the
inclusive boundary) is accepted; a normal 7-night booking is
byte-identical to every pre-existing test using that same shape.

**Zero test corrections needed this slice** — unlike Slices 2 and 3, no
pre-existing test's assumptions were invalidated by this change; the new
booking-time check is purely additive for every stay length already
being tested (all ≥ 3 nights).

**Exit criteria:** 88/88 total, 82 pre-existing, all unchanged.
Dependency-boundary test still green. Full 15-room EXIM scope validates
with zero blocking errors and produces exactly one `MinMaxStay`
Restriction regardless of room count.

## Next

EXIM's real, adapter-parseable gaps are now exhausted for the walking
skeleton's original scope (M1's deferred list — AMR, CHILD_PCT, and
MinMaxStay — is fully built as of Slices 2–4). Remaining real, evidenced
work: `CombinabilityRule` (Touring, Rocket, Eden — the one M4 checkpoint
still unbuilt, waiting on a real adapter to force its exact shape), or
extending Slice 1's full-room-coverage treatment (Units + Rates, now also
CHILD_PCT + Min/Max Stay) to Anex, Alltours, or a fifth real TO not yet
onboarded.

---

# M4 (post-Slice-4) — Anex Triple/4th Adult Reduction: COMPLETE

Builds Anex's real "Triple Reduction Per Person" (2.00 USD) and "04th
Room Reduction Per Person" (3.00 USD) columns — parsed by `RATE_ROW_RE`
since M2, alongside PPPN, but never carried past the regex match — into
real `SUPPLEMENT` `PricingRule`s.

**Why this slice, not Alltours' remaining 9 rooms.** Both were real
candidates. Alltours' room-code table was checked first and rejected on
evidence: of its 9 unbuilt room codes, only 3 (`DZP`, `DSP`, `DZB`) OCR
cleanly with the existing `parse_room_rate_row`, and even `DSP`'s own
match is wrong (`85.00` OCR's as `B5.00`, silently parsed as `5.00`). The
other 6 codes (`EZP`, `GO`, `DZG`, `DP`, `DZD`, `DJM`) don't match at all
— inspecting the raw OCR text shows the Roomtype section's two-column
layout is scrambled badly enough that guessing a room-code alias risks
attaching the wrong row's numbers to the wrong room, exactly what Part 5
forbids. That's a real data-quality ceiling on the current OCR pass, not
something safely fixable by pattern-matching harder — flagged, not
guessed around. Anex's Room Rates table, by contrast, is native text,
already fully parsed for the columns this slice needs, and had two more
real, ordinary numeric columns sitting unused.

**No Contract Model or pricing_engine change.** Checked first, same
discipline as every prior slice: Triple/4th Reduction are structurally
identical to EXIM's real AMR columns (Slice 2) — a flat per-night amount
off the base rate for one numbered adult slot, valid regardless of party
size as long as the party has that many adults. `PricingRule.
applies_to_pax_number` and `_adult_lines`' existing positional-consumption
logic handle this without a single line of pricing_engine changing.

**One real value deliberately *not* built as a `PricingRule`: Single
Supplement (60%).** Also real, also parsed (`row["single_supp_pct"]`,
captured since M2), but a genuine semantic mismatch with what
`applies_to_pax_number` means for the other two rules: "this numbered
slot always gets this treatment regardless of total party size" is true
for Triple/4th Reduction, but false for a single-occupancy supplement,
which only makes sense when the *entire* party is 1 adult — modeling it
as `applies_to_pax_number=1` would silently apply a single-occupancy
surcharge to the first adult of a 3-adult booking. Flagged in the
adapter's own comment at the call site, not forced into a field whose
semantics don't fit, and not worked around with a new field either —
today's real occupancy data makes it moot in practice (Promo Room's
`valid_occupancies` never include a 1-adult combo), so there's no live
pressure yet to design the right shape for it.

**`semantic_adapters/anex/adapter.py`:** `parse_room_rate_rows` now
carries `triple_reduction`/`fourth_reduction` through to the returned row
dict (previously matched by the regex, silently dropped). Two new
`SUPPLEMENT` `PricingRule`s built per season/rate row (18 total across 9
real rows), `applies_to_pax_number` 3 and 4, `Subtract(RateRef(rate),
Constant(reduction, USD))`, same Expression shape as EXIM's AMR rules.

**Four pre-existing tests corrected, not weakened** (same discipline as
Slices 2–4): every test asserting a flat `62.00 * 7 * 3` total for a
plain 3-adult Anex booking was only correct in the *absence* of the real
discount this slice now applies — `test_anex_walking_skeleton.
test_pricing_engine_prices_a_plain_three_adult_anex_booking_with_zero_code_changes`,
`test_anex_walking_skeleton.test_anex_adapter_produces_a_valid_contract_scope`
(pricing-rule count), `test_anex_walking_skeleton.
test_all_nine_seasons_produce_a_correctly_evaluating_child_policy_rule`
(now filters to `CHILD_POLICY` specifically, since `scope.pricing_rules`
also holds the new `SUPPLEMENT` rules), `test_pricing_engine_rate_
resolution`'s two market-tie-break regression tests, and
`test_applicability_and_composition.
test_booking_request_with_no_context_behaves_exactly_as_before` — each
corrected to the real 2-standard + 1-reduced-adult split, not reverted to
the old flat total.

**Proven (`tests/test_anex_supplement_rules.py`, 4 new):** all 9 real
rate rows produce exactly 18 `SUPPLEMENT` rules, `applies_to_pax_number
∈ {3, 4}` only (never 1); they validate cleanly; a real 3-adult booking
(the '03ADL' combo actually printed in the source) splits into 2 adults
at 62.00 and 1 at the real reduced 60.00, not a flat 62.00 × 3; a 2-
adult/2-child booking (no 3rd/4th slot in the party) is completely
unaffected.

**Exit criteria:** 92/92 total, 88 pre-existing (4 corrected for the
reason above, not regressed). Dependency-boundary test still green.

## Next

Alltours' remaining room-code coverage stays blocked on real OCR data
quality (see above) — the honest next step there is re-OCR at higher
resolution or a cropped-region pass, a `document_parser` capability that
doesn't exist yet, not an adapter fix. Anex's Single Supplement (real
data, deliberately unmodeled — see above) and its Min-node clause
("IN CASE SINGLE + 2 CHILD RATE IS MORE THAN DOUBLE...", needs a modeled
Single Room to compare against) remain real, evidenced, unbuilt work.
`CombinabilityRule` (Touring, Rocket, Eden) is still the one M4
checkpoint waiting on a real adapter to force its shape.

---

# M4 (next slice) — Alltours 3rd Adult Reduction: COMPLETE

Builds Alltours' real "for 3rd. adult reductlon for all rooms" line
(page 1, Supplements section: 6.00/6.00/6.00 EUR for Periods I/II/III)
into a real `SUPPLEMENT` `PricingRule` per season.

**Why this over the blocked room-code coverage.** Re-checked first, same
discipline as the prior slice: still blocked, same reason (6 of 9
remaining room codes don't OCR-match at all; a 7th silently misreads
`85.00` as `5.00`) — no new evidence changed that since last time. This
Supplements-section line, by contrast, is the *one populated row* in an
otherwise entirely blank "5. Supplements" table (every other
`supplement for` row has no values at all), and reads with zero OCR
corruption — confirmed by regex match against the real text before
writing any production code, same verify-first discipline as every prior
slice.

**No Contract Model or pricing_engine change — and this is the specific
line the Model already cites.** `PricingRule.applies_to_pax_number`'s own
docstring (M4 Slice 2) names this exact Alltours clause, alongside
EXIM's AMR, as the founding evidence for the field. This slice is that
citation's contract finally getting built: structurally identical to
EXIM's AMR and Anex's Triple Reduction (both already built) — a flat
per-night amount off the base rate for the 3rd adult slot, consumed by
`_adult_lines`' existing positional logic with zero pricing_engine
changes.

**Real difference from EXIM/Anex, and why it matters:** the source says
"for all rooms," not scoped to one room code. Built with
`room_type_id=None` — `PricingRule`'s own documented "hotel-wide" meaning
(present since M0, unused by any real adapter until now) — to faithfully
carry the real data's own scope, rather than narrowing it to DZP just
because DZP is the only room currently modeled. Noted honestly in the
adapter comment: because Alltours' Season objects aren't shared across
rooms (each room builds its own, same as EXIM/Anex), `room_type_id=None`
is only actually exercised once a second room's season references this
same rule's `season_id` — moot with today's DZP-only scope, but the
faithful extraction now means no rework is needed if/when full room
coverage is ever unblocked.

**Not end-to-end booking-provable — and that's the correct outcome, not
a gap.** DZP's own real occupancy data (M3) has exactly one confirmed
combo (2 adults) — the occupancy stack didn't OCR reliably enough to
trust a 3-adult combo, so a 3-adult DZP booking is correctly rejected at
booking-time validation (`OCCUPANCY_NOT_PERMITTED`) regardless of this
slice. Proven instead by direct Expression evaluation against each
season's real Rate, the same standard M4 Slice 2 used before EXIM had
booking-level tests, plus an explicit check that a 3-adult booking still
fails for the pre-existing occupancy reason — proof this slice doesn't
silently make an unconfirmed occupancy bookable just because a pricing
rule for it now exists.

**Zero test corrections needed** — unlike the Anex slice immediately
before this one, no pre-existing test asserted a value this rule
changes: DZP's only bookable party size (2 adults) has no 3rd-adult slot,
so every existing Alltours test is untouched.

**Proven (`tests/test_alltours_third_adult_reduction.py`, 4 new):** DZP's
scope produces exactly 4 `SUPPLEMENT` rules (one per season — 2× Period I
+ Period II + Period III), all `applies_to_pax_number == 3`, all
`room_type_id is None`; they validate cleanly; each season's rule
evaluates to that season's own real rate minus 6.00, not a flat
copy-pasted number; a 3-adult DZP booking still fails validation for the
real pre-existing occupancy reason; a 2-adult DZP booking is
byte-identical to before this slice.

**Exit criteria:** 97/97 total, 92 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Remaining real, evidenced work across all three adapters: Alltours'
Senior (60+, 10% all periods) and Longstay (21/29+ nights, 10%/12%)
reductions — also real, also cleanly OCR'd in the same Special Reduction
section, but each needs an `ApplicabilityCondition` shape not yet
exercised by any real adapter (an adult-age condition for Senior; a
stay-length condition for Longstay — both types exist in the sealed
`ApplicabilityCondition` set per Foundation Hardening II, but neither has
real data driving it through a full adapter build yet). Alltours' room-
code coverage stays OCR-blocked. Anex's Single Supplement and Min-node
clause remain flagged, unbuilt. `CombinabilityRule` is still the one M4
checkpoint waiting on a real adapter.

---

# M4 (next slice) — Alltours 21-Night Longstay Reduction: COMPLETE

Builds Alltours' real "Longstay from 21. nights reduction for all rooms"
Special Reduction row (10%/10%/10%, Periods I/II/III) into a real
`SUPPLEMENT` `PricingRule` per season, gated by a real
`StayLengthCondition` — the platform's first real adapter use of that
condition type (`applicability.py` has fully implemented it, generically,
since Foundation Hardening II; no real contract had exercised it until
now).

**Longstay over Senior, per instructions.** Both are real and equally
clean in the source. `StayLengthCondition` needs only
`BookingRequest.check_in`/`check_out` — fields every booking already has.
`AgeCondition` (Senior) needs a populated `BookingApplicabilityContext`
with adult guest ages, a heavier end-to-end setup for the same amount of
real adapter evidence. Smaller change, same evidentiary weight — Longstay
wins on the stated criterion.

**One genuine ambiguity found and deliberately not resolved: the 29-night
tier.** The same Special Reduction section prints a second real row,
"Longstay from 29nights\* reduction ... 12%/12%/12%." A stay of 30+
nights genuinely satisfies *both* tiers' `StayLengthCondition`, and
the contract states no explicit exclusivity or supersession between
them — no "the higher tier replaces the lower" language, no footnote
resolving the overlap, confirmed by inspecting the surrounding text.
`composition.py`'s own docstring had already flagged exactly this shape
of question as an honest, deferred limitation ("no real contract data yet
has two PricingRules simultaneously applicable to the same booking") —
this slice is the first real data to actually force it, for the 29-night
tier specifically. Rather than invent a tie-break (e.g. "higher tier
wins," which is standard industry convention but not stated in this
contract), only the unambiguous 21-night tier is built. Flagged in the
adapter's own comment at the parse site and the call site, not guessed
around.

**One small, evidence-driven `pricing_engine` fix — not a Model change.**
`StayLengthCondition.max_nights` was already `Optional` in the Model, but
`_match_stay_length` crashed (`AttributeError`) on `max_nights=None`.
Real data has no printed ceiling for "from 21 nights" — fixed to treat
`max_nights=None` as open-ended, the same `Optional`-field idiom used
everywhere else in this codebase. Proven by a dedicated unit test
(`test_applicability_and_composition.
test_stay_length_condition_with_no_max_nights_is_open_ended`) before any
adapter code was written.

**One real `pricing_engine` generalization — the actual "smallest
possible change" this slice needed.** Every `SUPPLEMENT` rule built
before this slice (EXIM's AMR, Anex's Triple/4th Reduction, Alltours' own
3rd Adult Reduction) is *positional* (`applies_to_pax_number` set) —
`_adult_lines` had no path at all for a *non*-positional, applicability-
gated rule that reduces the base rate for the whole party. Added: a
non-positional `SUPPLEMENT` rule whose `rule_applies(rule, booking)` (the
whole booking, not a single guest slot — a Longstay-style reduction is a
property of the booking itself) succeeds overrides the base per-person
rate for every adult not otherwise matched by a positional rule. A room
with no such rule, or one that doesn't match, is byte-identical to
before — proven directly against EXIM and Anex's existing tests, both
unaffected.

**No Contract Model change.** `StayLengthCondition`, `room_type_id=None`
("hotel-wide," present since M0), and `applies_to_pax_number=None`
("whole-party," the pre-existing default every rule already had) all
existed before this slice. This is wiring, not new modeling.

**Zero pre-existing tests broken by this slice's booking semantics** —
but 2 needed narrowing for an unrelated reason: the immediately-prior 3rd
Adult Reduction slice's tests filtered `scope.pricing_rules` by
`kind == SUPPLEMENT` alone, which this slice's new non-positional rules
now also satisfy. Corrected to filter by
`applies_to_pax_number == 3` specifically (what those tests actually
verify), not weakened.

**Proven (`tests/test_alltours_longstay_reduction.py`, 5 new, plus 1 in
`test_applicability_and_composition.py`):** DZP's scope produces exactly
4 `SUPPLEMENT` rules (one per season), each gated by a real
`StayLengthCondition(min_nights=21, max_nights=None)`,
`room_type_id=None`, `applies_to_pax_number=None`; they validate cleanly;
a real 21-night DZP booking (2 adults, the one confirmed occupancy combo)
prices the whole party at the real 10%-reduced rate through
`price_booking()` end-to-end — not a hand-called `rule_applies()`; a
20-night booking (one night short) is unaffected, proving the condition
genuinely gates the rule; a 35-night booking (well past the floor, still
inside one rate period) still matches, proving `max_nights=None` is truly
open-ended.

**Exit criteria:** 103/103 total, 97 pre-existing (2 narrowed for the
reason above, not regressed). Dependency-boundary test still green.

---

# M4 (next slice) — Alltours Senior Discount: COMPLETE

Builds Alltours' real "Senior from 60 years reduction for allrooms" row
(10%/10%/10%, same Special Reduction section as Longstay) into a real
`SUPPLEMENT` `PricingRule` per season, gated by a real
`AgeCondition(role=ADULT, min_age=60, max_age=None)` — the platform's
first real adapter use of `AgeCondition` with an adult role (every prior
use, Anex/EXIM's child bands, was `role=CHILD`).

**Chose Senior over the 29-night Longstay tier, as suggested.** Both
remained real, evidenced, and unbuilt going into this slice. Senior
needed genuinely new consumption logic (below); the 29-night tier is
still blocked on the same unresolved same-kind-rule-overlap question
flagged in the prior slice — no new evidence arrived to resolve it, so it
stays deferred.

**Real finding during implementation: Senior needed more than adapter
wiring, unlike Longstay — reported here rather than silently absorbed.**
Longstay is a *booking-level* fact (nights) — the whole-booking override
built for it in the prior slice was correct because a stay's length is
one fact about the whole party. Age is a *per-guest* fact: two adults in
the same room can have different ages. Reusing the Longstay mechanism
(check `rule_applies(rule, booking)` against the whole booking, using
`AgeCondition`'s existing "any guest of this role/age" semantics) would
have been a real, silent bug — if just one of two adults were a senior,
the *other*, non-senior adult would have been discounted too. Caught
before writing any adapter code, by reading `_match_age`'s existing
semantics and comparing them against how `_child_policy_lines` already
uses `AgeCondition` (per single guest, never per whole booking).

**`pricing_engine/calculator.py`:** `_adult_lines` gained a genuine new
consumption path — not a Model change (`AgeCondition` has supported
`role=ADULT` since Foundation Hardening II) and not a new abstraction,
just `_child_policy_lines`' existing per-guest pattern applied to a role
it hadn't been exercised for yet. `AgeCondition`-gated non-positional
`SUPPLEMENT` rules are explicitly excluded from the Longstay-style
whole-booking override and consumed separately: for each `ADULT` guest
identified in `booking.context.guest_ages`, `rule_applies()` is checked
against a single-guest booking (mirroring `_child_policy_lines` exactly);
a match produces its own invoice line; adults with no identified age, or
an identified age that doesn't qualify, fall through to the existing
standard/positional pricing untouched.

**One small, evidence-driven fix, same idiom as the prior slice's
`max_nights` fix — not a Model change.** `AgeCondition.max_age` was
already `Optional`, but `_match_age` crashed on `max_age=None`. Real data
has no printed ceiling for "from 60 years" — fixed to treat it as
open-ended. Proven by a dedicated unit test
(`test_applicability_and_composition.
test_age_condition_with_no_max_age_is_open_ended`) before any adapter
code was written.

**One real bug caught by the project's own dependency-boundary
discipline, not by accident.** An early draft of a code comment in
`_adult_lines` named a specific room code, tripping
`test_alltours_walking_skeleton`'s existing check that
`pricing_engine`/`contract_model`/`expression_engine` never leak
adapter-specific artifacts. Corrected to stay generic before this slice
was considered done — exactly the kind of regression that check exists
to catch.

**One known, flagged, currently-unexercised limitation.** Positional
rules (e.g. a 3rd/4th Adult Reduction) are now indexed over
"remaining adults" (party size after removing identified seniors), not
each adult's original position in the full party. No real booking has
ever combined a positional `SUPPLEMENT` rule with an identified senior
guest — flagged in the code, not solved speculatively, same discipline as
every other real ambiguity this project has declined to guess at.

**One pre-existing test corrected, not weakened:** the Longstay slice's
own rule-count test filtered `scope.pricing_rules` by
`applies_to_pax_number is None` alone, which the new Senior rules also
satisfy. Narrowed to `StayLengthCondition`-gated rules specifically (what
that test actually verifies).

**Proven (`tests/test_alltours_senior_discount.py`, 6 new, plus 1 in
`test_applicability_and_composition.py`):** DZP's scope produces exactly
4 `SUPPLEMENT` rules (one per season), each gated by a real
`AgeCondition(role=ADULT, min_age=60, max_age=None)`,
`room_type_id=None`, `applies_to_pax_number=None`; they validate cleanly;
a real 2-adult DZP booking with one identified senior (age 65) and one
non-senior (age 45) produces exactly one standard-rate line and one
10%-reduced line — never a flat discount applied to both, the specific
bug this slice exists to avoid; both adults identified as seniors
produces two reduced lines; no context at all reproduces the plain rate
exactly; an identified adult below the real 60-year floor is unaffected,
proving the condition genuinely gates the rule.

**Exit criteria:** 110/110 total, 103 pre-existing (1 narrowed for the
reason above, not regressed). Dependency-boundary test and the
Alltours-specific-leak test both still green.

## Next

Alltours' 29-night Longstay tier remains the one real, evidenced,
deliberately-unbuilt piece in the Special Reduction section — still
blocked on the same-kind-rule-overlap question composition.py has always
deferred. Alltours' room-code coverage stays OCR-blocked. Anex's Single
Supplement and Min-node clause remain flagged, unbuilt. `CombinabilityRule`
is still the one M4 checkpoint waiting on a real adapter.

---

# M4 (next slice) — Anex Release Period restriction: COMPLETE

Builds Anex's real "release" column (`RATE_ROW_RE`'s own `release`
group — "... 15 rooms 05 release" / "... 10 rooms 05 release", printed
on every one of the real 9 date-range rows, always 5 in this contract)
into a real `ReleaseRule` Restriction per rate row.

**Chosen for cost/benefit, not size.** Every other backlog item was
already blocked on real, evidenced ambiguity or missing infrastructure
(Alltours' 29-night tier: an unresolved same-kind-rule overlap; Alltours'
room codes: OCR corruption; Anex's Single Supplement and Min-node clause:
flagged semantic/structural gaps; `CombinabilityRule`: no adapter data).
`ReleaseRule` was not blocked at all — a Model type present since M0,
alongside `MinMaxStay`, that no adapter had ever built (confirmed by
inspection: zero references anywhere outside validation's generic
type-union handling), sitting on data already captured by the existing
regex and simply never carried past the match. Smallest genuinely
available slice, not the largest.

**No Contract Model change, no new validation code.** `ReleaseRule.
days_before_arrival` already exists, shaped exactly for this value. The
existing generic Restriction walk (the same dangling-reference and
provenance checks that started covering `MinMaxStay` automatically) picks
up `ReleaseRule` the same way, with zero new invariant code.

**Deliberately modeled as a booking-time WARNING, not a blocking ERROR —
the actual judgment call this slice required.** `MinMaxStay`'s "3/999
nights" is an explicit, black-and-white printed rule — enforcing it as a
hard `ERROR` doesn't invent anything the contract doesn't already state.
"Release 5" doesn't say what happens once a booking falls inside that
window: rejected outright, subject to availability, or flagged for
manual confirmation are all plausible real-world outcomes, and real
hotel contracts commonly still honor such bookings on request. A hard
`ERROR` here would have invented a stricter rule than the contract
actually states — so this uses `Severity.WARNING` (a pre-existing level,
"should be reviewed, doesn't block by itself"), the same restraint this
project has applied to every other real ambiguity (the 29-night Longstay
tier, Anex's Single Supplement) rather than resolved by guessing.

**`pricing_engine/calculator.py`:** new `check_release_period`, the same
shape as the two existing booking-time checks — added to
`BOOKING_TIME_CHECKS`. Only fires when the caller supplies `booking.
context.booking_date` (a field that has existed on
`BookingApplicabilityContext` since Foundation Hardening II, for
`DaysBeforeArrivalCondition`, but had never been populated by any real
booking before this slice) — every pre-existing booking, which never
supplies it, is completely unaffected. Confirms the matched `ReleaseRule`
is scoped to the actual booked room and that its Rate's Season actually
covers the booking's check-in date, so a rule from an unrelated season
never fires.

**Deliberately does NOT build the "rooms" allocation count (15/10)
printed in the same real column.** There is no Contract Model concept
for room allocation/allotment counts — not on `Season`, not on `Rate`,
nowhere. Adding one would be a real Contract Model change with no real
evidence yet forcing its exact shape (does it belong on the `Rate`? The
`Season`? A new `Allocation` type entirely?). Flagged, not guessed at.

**Zero pre-existing tests needed correction** — the first slice since
the original SUPPLEMENT-rule work where nothing had to be narrowed:
`ReleaseRule` is a new Restriction type, consumed only as a non-blocking
`WARNING`, orthogonal to every pricing calculation and occupancy check
already under test.

**Proven (`tests/test_anex_release_rule.py`, 5 new):** all 9 real rate
rows produce exactly 9 `ReleaseRule` Restrictions, each scoped to its own
Rate, `days_before_arrival.value == 5`, HIGH confidence (native text);
they validate cleanly; a booking made 3 days before a real check-in date
(inside the 5-day window) produces a `WARNING` with code
`BOOKING_INSIDE_RELEASE_PERIOD` and `price_booking()` still succeeds
(never blocked); a booking made 24 days ahead (outside the window)
produces no such warning; a booking with no `booking_date` at all
(every pre-existing booking shape) is completely unaffected.

**Exit criteria:** 115/115 total, 110 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Alltours' 29-night Longstay tier and Anex's Single Supplement / Min-node
clause remain the real, evidenced, deliberately-unbuilt items — each
blocked on a genuine ambiguity or missing structure this project has
declined to guess at, not on missing evidence. Alltours' room-code
coverage stays OCR-blocked. `CombinabilityRule` is still the one M4
checkpoint waiting on a real adapter. The "rooms" allocation count
(Anex, this slice) is a new, real, evidenced gap with no Model concept
yet — the next Contract-Model-touching decision this project will
eventually need to make, once (if) real evidence forces its shape.

---

# M4 (next slice) — EXIM Deposit Payments: COMPLETE

Builds EXIM's real page-6 deposit schedule ("The Tour Operator will pay
to the Supplier a deposit of &lt;amount&gt; USD at latest on &lt;date&gt;" —
4 identically-shaped lines in the Turnover Guarantee Conditions box) into
4 real `PaymentRule` entries.

**Chosen for cost/benefit, same reasoning as the Release Rule slice
before it.** Every other backlog item was still blocked on the same real
ambiguities (Alltours' 29-night tier, Anex's Single Supplement/Min-node,
`CombinabilityRule`'s missing adapter data) or OCR corruption (Alltours'
room codes). `PaymentRule` — a Contract Model type present since M0,
alongside `CancellationRule` — had zero references anywhere in
`semantic_adapters/` or `pricing_engine/`, confirmed by inspection before
writing any code. Unlike Release Rule's data (already regex-matched and
simply discarded), this needed one *new* regex — but the source text is
four identically-worded lines with zero variation, verified as an exact,
unambiguous match against the real page before any adapter code was
written, so the extra regex work didn't cost any confidence.

**No Contract Model change.** `PaymentRule.trigger` already had
`PaymentTrigger.FIXED_DEADLINE` — an enum value that already existed for
exactly this shape (a deposit due by a fixed calendar date, unrelated to
any booking's check-in/check-out), unused by any adapter until now.

**A real, structural difference from every prior slice, worth naming
plainly.** `PaymentRule.amount_calculation` and `.deadline_date` have no
`Extracted` wrapper in the Model — unlike every other field this project
has built (`Rate.amount`, `PricingRule.calculation`, `Restriction`
fields), which all carry confidence/provenance. This is a pre-existing
characteristic of the `PaymentRule` type itself, not something this
slice introduced or should paper over — built exactly as the dataclass
already exists, not embellished with an `Extracted` wrapper it doesn't
have. `amount_calculation` is still a real `Expression`
(`Constant(amount, USD)`), evaluated through `expression_engine`, not a
bare float — that part of the discipline holds regardless.

**No pricing_engine consumption — a real, honest difference from every
prior slice, not an oversight.** This is B2B contract-financial metadata
(a deposit schedule between the Tour Operator and the Supplier), not a
customer-booking-facing fact — there's no natural "booking-time check"
for it, the same way there isn't one for `BlackoutPeriod` or
`CombinabilityRule` today. Proven by direct construction and
`Expression` evaluation, the same standard used for EXIM's very first
`SUPPLEMENT` rule before booking-level tests existed for EXIM at all.

**Zero pre-existing tests needed correction** — same as the Release Rule
slice: an entirely new, unconsumed data path, orthogonal to every
pricing calculation, occupancy check, and restriction already under
test.

**Proven (`tests/test_exim_deposit_payments.py`, 3 new):** the scope
produces exactly 4 `PaymentRule` entries matching the real schedule
(1,000,000 USD by 30.09.2025; three 500,000 USD payments by 13.11.2025,
11.12.2025, and 12.02.2026), each `trigger=FIXED_DEADLINE`, each scoped
to the contract; they don't break validation; a multi-room scope still
produces exactly 4 entries, not one set per room built.

**Exit criteria:** 118/118 total, 115 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Alltours' 29-night Longstay tier and Anex's Single Supplement / Min-node
clause remain the real, evidenced, deliberately-unbuilt items — each
blocked on a genuine ambiguity or missing structure. Alltours' room-code
coverage stays OCR-blocked. `CombinabilityRule` is still the one M4
checkpoint waiting on a real adapter. Anex's "rooms" allocation count
still has no Model concept. EXIM's page-6 exclusivity-penalty clauses
(EUR 1,000/day, 30% of commitment turnover, 20% compensation) are real
but B2B-contractual in the same way as this slice's deposits, with no
obviously-fitting existing Model type — not attempted without a clearer
evidenced shape.

---

# M4 (next slice) — Alltours Cancellation Policy: COMPLETE

Builds Alltours' real customer cancellation policy (page 3, "11.
Cancellations by Customers / Cancellation Fees": free cancellation 7+
days out, a 1-night fee for cancellations "from 6 days before arrival
until the day of arrival", a separate 3-night no-show charge) into one
real `CancellationRule` — the 6-day/1-night tier only.

**Chosen for the same reason as Release Rule and Deposit Payments: not
blocked.** Every other backlog item was still blocked on the same
already-flagged ambiguities or missing structure (the 29-night Longstay
tier, Anex's Single Supplement/Min-node, room-code OCR corruption,
`CombinabilityRule`'s missing data, Anex's allocation count, EXIM's
exclusivity penalties with no fitting Model type). `CancellationRule` —
present since M0, alongside `PaymentRule` — had zero references anywhere
in the codebase, confirmed by inspection first, and the real clause
extracts cleanly once the page's own OCR quirk (below) is handled.

**A new page, read for the first time — a real, acknowledged cost, not
hidden.** This adapter had only ever read page 1 (the docstring
explicitly said so: "OCR is the expensive part of this pipeline, so
there's no reason to pay for pages this milestone's scope never reads").
The cancellation clause lives on page 3. Reading it is a genuine, real
increase in OCR cost for every Alltours scope build from here on —
called out plainly rather than absorbed silently, the same way every
other real cost/tradeoff in this project has been.

**One OCR obstacle found and solved cleanly, not routed around with a
looser regex.** Page 3's two-column layout interleaves unrelated text
from the other column mid-sentence: "...the day of arrival, the
organizer" is immediately followed, in extraction order, by a fragment
from the *other* column ("mo caused by the service provider...") before
"will pay the equivalent of 1 night..." ever appears. A single pattern
requiring adjacency between "the organizer" and "will pay..." doesn't
match. Fixed by matching the day-count and the fee amount as two
independent regex fragments, both required on the same page — not by
loosening either pattern's precision.

**Only the 6-day/1-night tier is built — the real judgment call this
slice required, same shape as every prior "flag, don't guess" decision.**
Free cancellation at 7+ days needs no separate entry (it's the implicit
absence of any penalty rule). The real 3-night no-show charge is
deliberately **not** built as a `CancellationRule`, even though it's
equally clean data: the contract's own wording treats a no-show as
distinct from a cancellation (the customer never canceled — they simply
didn't arrive). Forcing it into `CancellationRule.
deadline_days_before_arrival` would misrepresent that real distinction.
Flagged in the adapter's own comment, not guessed into a shape that
doesn't fit — same discipline as Anex's Single Supplement and the
29-night Longstay tier.

**`penalty_calculation` uses `CalculationUnit.NIGHTS`, not an invented
currency amount.** The source says "the equivalent of 1 night," not a
dollar figure — and this contract-wide clause doesn't reference any
specific room's rate to convert it into one. Still a real `Expression`
(`Constant(1, NIGHTS)`), evaluated through `expression_engine`, not a
bare number — the "never a raw float" discipline holds even for a
non-currency unit.

**No pricing_engine consumption — same honest gap as `PaymentRule`'s
slice.** This is a policy fact about a hypothetical future action
(cancelling), not something `price_booking()`/`validate_booking()`
evaluate — there's no "cancel a booking" operation anywhere in this
pricing_engine to wire it into. Proven by direct construction and
`Expression` evaluation instead.

**Zero pre-existing tests needed correction** — third slice in a row
where nothing broke: an entirely new, unconsumed data path, and the new
page-3 read doesn't touch anything page 1's existing parsers already
depend on (confirmed directly against `test_alltours_walking_skeleton`
and `test_alltours_third_adult_reduction`, including the dependency-
boundary-style Alltours-leak check).

**Proven (`tests/test_alltours_cancellation_policy.py`, 3 new):** the
scope produces exactly one `CancellationRule`, `deadline_days_before_
arrival == 6`, scoped to the contract; it doesn't break validation; the
penalty is a real `Expression` in `NIGHTS`, evaluating to `1.0`, not a
guessed currency amount.

**Exit criteria:** 121/121 total, 118 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Alltours' 29-night Longstay tier, Anex's Single Supplement / Min-node
clause, and Alltours' room-code coverage remain the real, evidenced,
deliberately-unbuilt items — each blocked on a genuine ambiguity, OCR
data-quality ceiling, or missing structure. `CombinabilityRule` is still
the one M4 checkpoint waiting on a real adapter. Anex's "rooms"
allocation count and EXIM's exclusivity-penalty clauses both remain real
but with no obviously-fitting Model type. Alltours' own real 3-night
no-show charge (this slice) joins that list — real, clean data, correctly
declined a home in `CancellationRule`'s existing shape.

---

# Pivot: M4 slice-mining -> M5, the first end-to-end workflow

After 11 M4 slices (121/121 tests, no Contract Model change in a long
stretch), assessed whether the highest-value next step was still another
adapter slice or a shift to building PDF -> extraction -> validation ->
review -> pricing end-to-end. The signal: the last three slices (Release
Rule, Deposit Payments, Cancellation Policy) all shared a property none
of the first eight did — none of them touch `price_booking()` at all.
That's the concrete evidence of diminishing returns on the pricing core
specifically, not a subjective sense that M4 has "enough" slices.

The bigger risk sitting unexamined: every one of the ~121 tests proves
`build_contract_scope()` by asserting directly on the Python objects it
returns, in-process, in one call. Nothing has ever exercised
serialization, a draft/persisted distinction, or a review step — despite
the Model documenting the intent for all three since M0 (`Extracted`'s
own docstring: "must never let [a LOW-confidence value] through to a
persisted Model"; `ContractScope.schema_version`, versioned explicitly
for exactly this). That gap is unknown-shaped, which makes it more
valuable to surface now, with 3 adapters and a small surface area, than
after more slices are built on top of an unexamined pipeline.

Remaining M4 items are not abandoned — they're real, evidenced, and
listed above — but are deprioritized behind the workflow build. New gaps
the workflow surfaces are treated as implementation-driven refinements,
using the same slice discipline, not planned speculatively in advance.

# M5, Slice 1 — Commit Gate: COMPLETE

The first piece of the end-to-end workflow. `registry/store.py`:
`commit_scope(scope) -> CommitResult` enforces the draft-vs-persisted
distinction `Extracted`'s docstring has promised since M0 but nothing
had ever enforced — every prior test built a scope and priced against it
directly, bypassing that distinction entirely.

**Chosen over serialization as the actual first slice, on evidence found
during inspection, not assumed in advance.** The original plan named
four candidate prerequisites (serialization, commit gate, review loop,
a full EXIM run) without ordering them. Inspecting the codebase first
turned up two decisive facts: (1) both halves of the commit gate's logic
already existed and were already proven correct —
`validation.invariants.validate()` (structural correctness) and
`entities.iter_extracted()` (the same per-field walk
`validation.confidence.py` already uses) — so this slice needed only
orchestration glue, not new logic; (2) a full generic JSON round-trip
for `ContractScope` (20 dataclasses, a 13-node `Expression` union, a
7-type `Restriction` union) is real, substantial work with no proven
value yet — there is nothing worth persisting until something has
decided what's committable. Smaller, safer, and it directly implements
a promise the Model's own docstrings had already made — chosen for that
reason, not because it was listed first.

**Lives in `registry/`, not a new package.** `registry/` already existed
in the codebase, empty, scaffolded — `TourOperator`'s own docstring
already read "used by semantic_adapters and registry" before this slice
touched anything. Used the intended home rather than inventing a
`persistence/` module alongside it.

**No Contract Model change.** Nothing about `ContractScope`,
`Extracted`, or any entity changed. `commit_scope()` is thin
orchestration only, the same discipline every `pricing_engine`
booking-time check already follows — it calls two pre-existing, already-
tested functions and makes one decision from their combined output.

**`tests/test_dependency_boundaries.py` extended, not bypassed.** Added
`"registry": ["semantic_adapters", "document_parser"]` to
`FORBIDDEN_IMPORTS`, mirroring `pricing_engine`'s own restriction —
`registry` only needs `contract_model` and `validation`, so this closes
the same class of violation the project has guarded against everywhere
else, for a package this project is about to build more into.

**Proven against real, already-known evidence, not synthetic
fixtures:** EXIM's real DR01 scope (native text, M1) has zero
LOW-confidence fields among 34 real `Extracted` values — commits
successfully. Alltours' real DZP scope (M3) has exactly two real
LOW-confidence fields — the occupancy stack's `adults`/`children`,
flagged "not invented" since M3 — and is correctly rejected, not
silently committed. A deliberately constructed `RoomType` with no `Rate`
(invariant #1, `MISSING_BASE_RATE`) proves the gate honors `validate()`
independently of the confidence check. Re-committing the same scope id
simply replaces the stored version — the ordinary behavior a
dict-backed store gives for free.

**Deliberately NOT attempted this slice:** serialization (nothing to
persist to a durable form yet without a commit decision upstream of it);
review_ui (the mechanism for a human to fix what gets rejected — this
slice only proves rejection happens correctly and carries enough detail
in `CommitResult` to route a future reviewer, not the reviewing itself).

**Exit criteria:** 125/125 total, 121 pre-existing, all unchanged.
Dependency-boundary test still green, now covering `registry` too.

## Next

Two natural continuations, both real and both still undecided: (1) a
serialization layer for `ContractScope`, now that the commit gate gives
it something worth persisting; (2) `review_ui`'s first slice — surfacing
`CommitResult.low_confidence_fields` for a human to act on, closing the
loop `commit_scope`'s rejection path already opened. Neither is chosen
yet; the next slice will inspect the codebase again before deciding,
same discipline as this one.

---

# M5, Slice 2 — review_ui Corrections: COMPLETE

Closes the loop the Commit Gate (M5 Slice 1) explicitly opened.
`review_ui/corrections.py`: `list_review_items(scope)` surfaces every
real LOW-confidence field for a human; `apply_correction(scope,
entity_id, field_name, value, confidence)` lets them act on it.

**Chosen over serialization, on the same evidence-driven basis as the
commit gate itself.** Inspecting the codebase (not the two-item "Next"
list from last slice) surfaced the deciding fact: `CommitResult.
low_confidence_fields` already carries everything needed to route a
human to what needs correcting, but nothing existed yet that let them
act on it — a visibly incomplete loop, not a speculative nice-to-have.
Closing it uses entirely real data already proven in the suite
(Alltours' DZP occupancy stack, LOW-confidence since M3, already the
real rejection case in `test_registry_commit_gate.py`). Serialization
remains real and undecided, but doesn't complete a loop by itself the
way this does, and isn't coupled to this slice's design either way — a
mutation-based correction API works unchanged regardless of how a scope
is later serialized.

**No Contract Model change.** `Extracted` (value, confidence,
provenance, source_note) was already a plain, mutable dataclass —
correcting a field is a direct in-place mutation of the exact object
`entities.iter_extracted()` already yields, not a new field, a new
entity, or a rebuild-and-replace. Both `list_review_items` and
`apply_correction` are thin wrappers around `iter_extracted()` — the
same canonical, already-tested walk `validation.confidence` and the
commit gate itself already reuse, rather than a second, independently-
maintained traversal of "where do Extracted values live in this model."

**Lives in `review_ui/`, not a new package** — already scaffolded,
empty, in the codebase, the same discovery that put the commit gate in
`registry/` last slice.

**The correction applied in tests is a real, defensible reviewer
action, not an invented contract fact.** DZP's real occupancy value
(2 adults, 0 children) is confirmed correct and upgraded from LOW to
HIGH confidence — the honest, evidence-only action available (this
project has no new visual/document evidence about DZP's true occupancy
stack beyond what M3 already extracted), not a fabricated replacement
number.

**`test_dependency_boundaries.py` extended again**, mirroring
`registry`'s own addition last slice: `"review_ui": ["semantic_adapters",
"document_parser"]` added to `FORBIDDEN_IMPORTS` — `review_ui` only
needs `contract_model`, so this closes the same class of violation the
project guards against everywhere else, for a second package this
project is about to build more into.

**Deliberately not attempted:** a real user interface (this is the
capability a UI would call, not the UI itself); recording who reviewed a
field or when (`Extracted` has no `reviewed_by`/`reviewed_at` field, and
adding one without a real UI or workflow driving that requirement would
be a speculative Contract Model change — flagged, not built); resolving
*which* value is correct (`apply_correction` enforces nothing about
where its value came from, the same way `commit_scope()` enforces
nothing about how a scope was built).

**Proven (`tests/test_review_ui_corrections.py`, 4 new):**
`list_review_items` surfaces exactly DZP's 2 real LOW-confidence fields,
nothing more; confirming one upgrades it to HIGH in place and removes it
from the review list while leaving the other untouched; a stale or wrong
`(entity_id, field_name)` pair fails loudly (`False`, no mutation), never
silently no-ops; and the real end-to-end proof — a scope rejected by the
commit gate becomes committable once every flagged field is corrected,
closing draft -> reject -> correct -> re-commit for the first time.

**Exit criteria:** 129/129 total, 125 pre-existing, all unchanged.
Dependency-boundary test still green, now covering `registry` and
`review_ui` both.

## Next

Serialization remains the one clearly real, undecided piece: a
persistence layer for `ContractScope` now that the commit gate has
something worth persisting durably (today's `registry` store is
in-memory only, lost on process restart). No Contract Model change is
expected to be required going in, but — same discipline as every slice
so far — that will be confirmed by inspection, not assumed, before any
code is written.

---

# M5, Slice 3 — End-to-End Workflow Proof: COMPLETE

The first real proof of the whole point of the M4 -> M5 pivot: PDF ->
extraction -> commit gate -> (review + correction, where needed) ->
registry retrieval -> pricing, as one continuous chain, for both the
direct-success path (EXIM) and the needs-review path (Alltours).

**Chosen by inspecting the codebase, not by working down the "Next"
list.** Before deciding between serialization and anything else, the
composition itself was checked directly — scripted by hand against the
real EXIM and Alltours fixtures, outside of any test file, before
writing a single line of test code. Both flows (commit-succeeds-
immediately, and reject-correct-recommit) worked **with zero new
production code**. That is this slice's real, honestly-reported
finding: the gap was in test coverage of the *composition* across M5
Slices 1–2, not in any individual piece. Every M5 test up to this point
proved one function in isolation — `commit_scope` alone,
`list_review_items`/`apply_correction` alone — nothing had ever proven
that a scope obtained via `get_committed_scope` (not the adapter's
direct return value) is what `price_booking()` actually receives in a
real workflow, or that the full reject -> correct -> re-commit -> price
path produces the right real numbers together.

**No implementation, by design — and that absence is reported here
plainly, not hidden.** This slice adds one test file
(`tests/test_end_to_end_workflow.py`) and zero production code. The
"smallest possible implementation" this discipline calls for turned out
to be *no* implementation — the four existing layers (adapters, the
commit gate, review_ui, pricing_engine) already composed correctly.
Writing the slice as if a change were needed, when inspection showed
none was, would have been the actual violation of the project's
discipline here.

**No new abstraction introduced.** No `workflow.py` orchestration
wrapper was added. The existing layered functions already compose
legibly via direct calls (`build_contract_scope` ->
`commit_scope` -> `get_committed_scope` -> `price_booking`, with
`list_review_items`/`apply_correction` between the first two when
needed). There's no evidence yet that a caller needs a wrapper function
instead of calling these directly — inventing one now would be
speculative design. If a real caller (a future CLI or API layer) forces
that shape later, it gets built then.

**What this closes.** The commit gate (M5 Slice 1) and review_ui (M5
Slice 2) were each proven correct in isolation but never proven to
compose. This slice is the first test coverage of the composition
itself: (1) EXIM's real DR01 scope commits immediately (zero
LOW-confidence fields) and prices correctly from the registry-retrieved
object; (2) Alltours' real DZP scope is rejected on first commit (2 real
LOW-confidence occupancy fields, since M3), corrected via `review_ui`,
succeeds on the second commit, and prices correctly from the registry-
retrieved object — draft -> reject -> correct -> re-commit -> price, as
one continuous chain, for the first time; (3) a rejected scope is
never retrievable through the registry, proving the gate is a real gate
for that path, not merely advisory; (4) two independently-built, real
scopes (EXIM and a corrected Alltours) coexist in the registry without
interfering with each other.

**Proven (`tests/test_end_to_end_workflow.py`, 4 new):** all four points
above, each against real fixture data and real expected totals (EXIM:
46.00 × 7 × 2; Alltours: 66.00 × 7 × 2, the real Period II rate
confirmed since M3) — not synthetic numbers.

**Exit criteria:** 133/133 total, 129 pre-existing, all unchanged.
Dependency-boundary test still green. Zero production files changed —
only a new test module.

## Next

Serialization remains the one clearly real, undecided piece — the
`registry` store is still in-memory only, and this slice's proof of the
full workflow makes that limitation more concrete, not less: everything
proven end-to-end here is lost on process restart. Same discipline as
every slice so far — its actual shape (a hand-rolled JSON scheme vs.
something else, how the `Expression`/`Restriction` type unions get
tagged for round-tripping) will be decided by inspection when that
slice starts, not assumed here.

---

# M5, Slice 4 — Serialization: COMPLETE

`contract_model/serialization.py`: `serialize_scope()` /
`deserialize_scope()`, a full JSON round-trip for `ContractScope` — Part
7 of the original architecture ("the persistence layer"), referenced and
explicitly deferred at least three times in this codebase before this
slice (`invariants.py`'s `check_no_circular_supersession` docstring:
"while ContractScope objects are in-memory/**JSON**"; `registry/store.py`:
"no serialization yet"; `ContractScope.schema_version`, carried since M0
for exactly this).

**Confirmed as the right next slice by inspection, not assumed from the
prior "Next" note.** Before writing any code, searched the codebase for
every reference to "Part 7" and to persistence/serialization by name.
That surfaced the `check_no_circular_supersession` comment above —
direct, concrete confirmation that JSON was always the intended form,
and that this was a named, deliberately-deferred piece of the original
architecture, not a speculative addition. Nothing else surfaced during
that same search as a more urgent or higher-risk gap.

**Full type surface mapped before any design decision** — 20 dataclasses
in `entities.py`, a 13-node `Expression` union, 4-type `Restriction` and
`ApplicabilityCondition` unions, 8 `str`-Enum vocabularies — read in full
before choosing an encoding scheme, not designed against an assumed
shape.

**The one real design decision this slice required: self-describing
`__type__` tags, not a type-hint-driven scheme.** `entities.py` uses
`from __future__ import annotations`, so `dataclasses.fields()`'s `.type`
values are unresolved strings, not usable type objects — correctly
resolving every `Union`/`Optional`/`Generic` field shape from those
strings would be real, avoidable complexity. Tagging every encoded
object with its own class name sidesteps that entirely: decoding never
has to guess or pre-know a field's expected type. An unrecognized tag
raises `SerializationError` immediately — the same "never silently
guess" discipline Part 5 has always applied to adapter extraction,
extended here to the serialization boundary for the first time.

**Reflection drives the mechanical round-trip, not a hand-enumerated
field list — a deliberate, explained departure from `iter_extracted`'s
own style, not an inconsistency.** `iter_extracted` is a *filtering*
walk making a business judgment call (which fields matter for confidence
review) — explicitness matters there because a human is choosing what's
meaningful. This is a *preserving* walk with no judgment call to make
(every field must survive, always, regardless of what it means) —
`dataclasses.fields()` reflection is the correct tool for "preserve
everything, decide nothing." The two registries this module does define
explicitly (dataclass name -> class, enum name -> class) are the same
style of typed dispatch table `applicability.py`'s `register_condition`
already uses — what this module supports is a visible, auditable list,
not implicit.

**No Contract Model change.** Purely additive — one new module, zero
changes to any existing entity, expression, or validation code.

**Deliberately out of scope, named plainly rather than silently
skipped:** wiring `serialize_scope`/`deserialize_scope` into the
`registry` store to make it durable (a separate, later slice — this one
proves the round-trip works, not that anything uses it yet);
cross-contract cycle detection for `supersedes_contract_id`
(`invariants.py` already named this as needing "other contracts loaded",
explicitly deferred — not attempted here either); schema migration
across `schema_version` values (the version string is preserved
faithfully through the round trip, but no migration logic exists — only
one real schema version is in use by any adapter so far, so nothing
forces that design yet).

**Proven against two real scopes chosen for type-surface coverage, not
arbitrarily:** EXIM's DR01 (`MinMaxStay` Restriction, `PaymentRule` with
a bare, non-`Extracted` `Expression`, `CHILD_PCT` `AgeCondition` rules,
deep `Expression` trees) and Alltours' DZP (`StayLengthCondition`,
`AgeCondition(role=ADULT)`, `CancellationRule`'s bare `Expression` in
`CalculationUnit.NIGHTS`) — between them, every `Restriction` and
`ApplicabilityCondition` subtype any real adapter has built is exercised
at least once.

**Proven (`tests/test_serialization.py`, 6 new):** output is real,
parseable JSON, independently verified through the stdlib `json` module,
not this project's own decoder; `price_booking()` produces
**byte-identical invoices** before and after a full round trip, for both
EXIM (3-adult positional-rule booking) and Alltours (per-guest Senior
Discount booking) — not just structurally similar, the actual real
numbers; full structural equality (`restored == scope`) holds for EXIM,
including fields `price_booking()` never touches (`payment_rules`,
`restrictions`); a real, deep `Expression` tree (`Subtract(RateRef,
Constant)`) reconstructs into a structurally equal tree; a corrupted
type tag raises `SerializationError` immediately, never a silent
misreconstruction.

**Exit criteria:** 139/139 total, 133 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Two real, undecided continuations: (1) wiring `serialize_scope`/
`deserialize_scope` into `registry/store.py` so committed scopes survive
a process restart — the natural next step now that round-trip fidelity
is proven; (2) schema migration, once (if) a real second
`schema_version` value is ever produced by an adapter — no evidence
forces that design yet, so it stays unbuilt rather than guessed at.
Neither is chosen yet; the next slice will inspect the codebase again
before deciding, same discipline as every slice before it.

---

# M5, Slice 5 — Registry Persistence: COMPLETE

Wires `contract_model/serialization.py` (M5 Slice 4) into
`registry/store.py` (M5 Slice 1): `commit_scope()` and
`get_committed_scope()` both gain an optional `storage_dir` parameter,
so a committed `ContractScope` can survive a process restart instead of
only living in the in-memory dict.

**Chosen over a CLI/API/UI pivot, on evidence weighed both ways, not
by default.** The instruction explicitly opened the door to a different
direction if inspection supported it. It didn't: persistence has strong,
repeated, textual evidence of intent already in this codebase
(`invariants.py` and `registry/store.py` both explicitly named "Part
7"/serialization as a deferred piece, and M5 Slice 4 closed the
round-trip half of it). A CLI/API has none — no scaffolded empty package
exists for one anywhere (unlike `registry/` and `review_ui/`, both
pre-scaffolded before the slices that filled them in), and no code
comment anywhere references a "Part N" for a product-facing entry point.
Building one now, with nothing in the codebase pointing at its shape,
would have been exactly the speculative design this project has
consistently avoided. Persistence was the evidenced choice, not merely
the expected one.

**Kept deliberately, provably backward compatible.** Both functions'
existing signatures still work with zero changes — every pre-existing
call site (5 tests in `test_registry_commit_gate.py`, 4 in
`test_end_to_end_workflow.py`) needed no changes and were re-run
unmodified as part of this slice's own verification, not just the full
suite. Omitting `storage_dir` reproduces M5 Slice 1's exact in-memory-
only behavior — this is additive, not a breaking change to an
already-tested function signature.

**No hardcoded storage location anywhere.** `storage_dir` is always
caller-supplied; nothing in this codebase gives evidence for what a
"right" default location would be, and inventing one would be the same
kind of silent guess Part 5 forbids adapters from making about contract
data — applied here to infrastructure instead.

**The commit gate itself is unchanged.** A rejected scope is still
never written to disk, the same way it was never added to the in-memory
cache — persistence only ever applies to what already passed the gate,
proven directly with the same `MISSING_BASE_RATE` deliberate-construction
trick `test_registry_commit_gate.py` already used, so this slice's test
file needed zero OCR cost of its own.

**No Contract Model change.** Nothing about `ContractScope` or any
entity changed — this slice is orchestration wiring two already-proven
pieces (the commit gate's gating logic, the serializer's round-trip
fidelity) together, the same "thin orchestration only" discipline every
`registry`/`pricing_engine` addition has followed.

**Proven (`tests/test_registry_persistence.py`, 5 new):** omitting
`storage_dir` behaves exactly as before, confirmed by clearing the cache
and showing the scope is gone (nothing was ever written to disk for it);
a real committed scope with `storage_dir` produces a real,
independently-parseable JSON file on disk; the actual point of this
slice — clearing the in-memory cache (simulating a process restart)
does not lose the scope when `storage_dir` was used, `get_committed_scope`
recovers a genuinely different object (`recovered is not scope`) that is
structurally identical (`recovered == scope`) and prices a real booking
identically; omitting `storage_dir` on retrieval never silently falls
back to a file that happens to exist from an earlier call; a rejected
scope never produces a file on disk.

**Exit criteria:** 144/144 total, 139 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

The end-to-end workflow (M5 Slice 3) has never been re-run through the
disk-durability path specifically — a natural, cheap next check, not
necessarily a full slice on its own. Beyond that, still genuinely
undecided: a CLI/API/UI entry point (now with more evidence pressure
than before, since the engine, review loop, and persistence are all
proven — but still no scaffolded package or "Part N" reference pointing
at its exact shape); schema migration (unchanged from last slice — no
second `schema_version` value exists yet to force that design). Neither
chosen yet; decided by inspection when the next slice starts.

---

# M5, Slice 6 — Review + Persistence Composition Proof: COMPLETE

Closes the one real, evidenced combination still untested after M5
Slice 5: a scope that needed `review_ui` correction, *committed with
disk persistence*, surviving a simulated process restart with its
correction intact. Every prior persistence test used EXIM (never needs
review); every prior review test used the in-memory-only registry.
Nothing had proven the two together.

**Chosen over a CLI/API pivot, by the same evidence-weighing as last
slice, with the same result.** Searched again for any scaffolding or
"Part N" reference pointing at a CLI/API/UI shape — found none, same as
last time. The gap that *is* evidenced: M5 Slice 5's own "Next" note
named this exact combination as an open, cheap, real check, not a
full slice on its own — which is exactly what it turned out to be.

**Found the same way every composition proof in this project has been
found: scripted by hand against the real Alltours fixture before
writing any test.** The combination worked with zero new production
code — `commit_scope`'s persistence logic doesn't care about a scope's
history (whether it needed correction or committed cleanly on the first
attempt), it just serializes whatever object is handed to it at commit
time. That's the honestly-reported finding here, same as M5 Slices 3
and 5 before it: the value is closing a real gap in proof of
composition, not in discovering new functionality.

**One new test, added to the existing composition-proof file, not a new
one.** `test_end_to_end_workflow.py` already existed specifically to
prove untested combinations of already-correct pieces — this is one
more combination in the same spirit, so it was added there rather than
starting a new file that would only duplicate that file's own stated
purpose.

**No Contract Model or production code change at all** — the third
slice in this project to have that property (after M5 Slice 3's initial
proof and, partially, this one), and each time the absence of
implementation is reported plainly rather than treated as a slice that
didn't happen.

**Proven
(`test_end_to_end_workflow.test_a_scope_needing_review_survives_a_restart_after_persisted_correction`,
1 new):** Alltours' real DZP scope is rejected, corrected via
`review_ui`, and committed with `storage_dir` — then the in-memory
cache is cleared (simulating a restart) and the scope recovered from
disk is a genuinely different object, carries zero remaining review
items (the correction itself survived serialization, not just the
originally-extracted fields), and prices a real booking to the exact
same total as before the restart.

**Exit criteria:** 145/145 total, 144 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Every pairwise combination of the M5 pieces (commit gate, review
correction, registry retrieval, persistence, pricing) that real adapter
data can exercise has now been proven at least once. The two real,
undecided items are unchanged from last slice: a CLI/API/UI entry point
(still no scaffolding or "Part N" reference pointing at its shape,
despite every underlying piece now being proven) and schema migration
(still no second `schema_version` value to force that design). Neither
is evidenced yet — the next slice will inspect the codebase again
before choosing, same discipline as every slice before it.

---

# Pivot: M5 composition-proofs -> M6, reachability

Re-evaluated the whole project from its current state, per instructions
not to continue the roadmap mechanically. Checked every candidate for
"the next qualitative leap" against real evidence, the same discipline
this project has applied to every adapter gap:

- **A fourth adapter** — needs a fourth real contract PDF. Checked
  `tests/fixtures/` and the rest of the repo directly: none exists.
  Fabricating one from synthetic data would violate this project's
  real-data-only discipline outright — the same reason `CombinabilityRule`
  has stayed unbuilt since M4.
- **Schema migration** — needs a second real `ContractScope.
  schema_version` value to migrate between. None has ever been produced
  by any adapter. Nothing to migrate, nothing to design against.
- **`CombinabilityRule`** — same blocker as the fourth adapter: needs
  Touring/Rocket/Eden's real data to force its shape.
- **Registry evolution** (listing, deletion, etc.) — no evidenced need
  anywhere in this codebase or its usage so far.

**The CLI is different, and that difference is the actual finding this
pivot rests on.** Every previous rejection of a CLI/API/UI pivot (going
back several slices) cited the same reason: no scaffolded empty package,
no "Part N" reference — the kind of textual evidence that correctly
pointed to `registry/`, `review_ui/`, and serialization each time before.
Re-checked again this time and found the same absence. But re-evaluating
the *whole* project this time, not slice-by-slice, surfaced a different,
stronger signal: every other candidate above is blocked by missing
*real-world data*, the same category of blocker this project has
respected throughout — not a correctness gap, not a design gap, a real
evidence gap. The CLI has no such blocker. Every piece it needs
(adapters, the commit gate, review_ui, persistence, pricing) is already
built and already proven. The actual remaining gap is reachability —
none of this is usable except by importing internal modules directly,
exactly the way this test suite itself does. That gap doesn't need new
data to close; it needs a thin, honest layer over what already exists.

# M6, Slice 1 — CLI: COMPLETE

`contract_platform/cli.py`: `run_ingest(adapter_name, pdf_path,
room_codes=None, storage_dir=None) -> IngestResult`, and `main(argv)` —
the first way to run this project's pipeline from an actual command,
not just a test. `python -m contract_platform <adapter> <pdf_path>
[--room-codes ...] [--storage-dir ...]` now works as a real, runnable
command (`contract_platform/__main__.py` added for `python -m` support),
smoke-tested directly via subprocess-equivalent invocation, not just
through test imports.

**Deliberately minimal — one command, not a CLI framework.** `ingest`
runs a real PDF through extraction and the commit gate and reports the
result: committed with basic scope stats, or rejected with the real
validation issue count and the real review items a human would need to
act on next. Pricing a specific booking, listing committed scopes, and
applying corrections from the command line are all real, plausible
future commands — none is built, because nothing yet evidences which
one matters most. Guessing would repeat the exact mistake this project
avoided with the 29-night Longstay tier and Anex's Single Supplement:
building a shape nothing has actually asked for.

**A real, adapter-signature inconsistency found by inspection, not
assumed away.** EXIM's and Alltours' `build_contract_scope` both accept
an optional `room_codes` list; Anex's does not — it always builds the
single real Promo Room product, M2's own documented scope. `_build_scope`
in `cli.py` handles this explicitly per adapter name, and passing
`--room-codes` for `anex` fails with a clear `ValueError` naming the
adapter, rather than a confusing `TypeError` from deep inside the
adapter module or a silently-ignored flag.

**No Contract Model, `pricing_engine`, or adapter change.** `cli.py` is
pure orchestration over already-tested functions — `run_ingest()`
composes `build_contract_scope()`, `commit_scope()`, and, on rejection,
`list_review_items()`, the same "thin orchestration only" discipline
`registry/store.py` and `review_ui/corrections.py` both already follow.
`main()` is a thin `argparse`/`print` wrapper around `run_ingest()` —
the decision logic is fully unit-testable without capturing stdout; only
`main()`'s own two tests need to.

**Dependency boundaries deliberately left unrestricted for `cli`** —
unlike `registry`/`review_ui`, which are guarded from importing
`semantic_adapters`/`document_parser`, the CLI is the outermost
composition layer and is expected to import everything below it. Adding
a restriction here would contradict what this module is for.

**Proven (`tests/test_cli.py`, 7 new):** EXIM's real DR01 scope commits
with real, non-zero counts; Alltours' real DZP scope is rejected with
exactly the 2 real review items `review_ui.list_review_items()` would
surface directly; an unknown adapter name and `anex` with `--room-codes`
both fail with clear, specific `ValueError`s; ingesting with
`storage_dir` actually persists through the real M5 Slice 5 path
(confirmed by clearing the in-memory cache and recovering from disk);
`main()` prints a real commit summary and returns exit code 0 on
success, and prints the real rejection detail and returns non-zero on
rejection. A direct `python -m contract_platform` invocation against the
real EXIM fixture was also run as a genuine subprocess-style smoke test,
not just through test imports.

**Exit criteria:** 152/152 total, 145 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Real, undecided next commands for the CLI, none chosen yet: `price` (a
specific booking against an already-committed scope — needs evidence for
how booking details should be supplied on a command line); `review`/
`correct` (surfacing and applying `review_ui` corrections without
writing Python — the natural CLI-side completion of the M5 review loop);
`list` (enumerating committed scopes — the registry itself has no
enumeration capability yet either, so this would need a registry change
first, not just a CLI one). Schema migration and a fourth adapter remain
blocked on the same missing real-world evidence as before. Decided by
inspection when the next slice starts, same discipline as every slice
before it.

---

# M6, Slice 2 — CLI `list` command: COMPLETE

`registry/store.py` gains `list_committed_scope_ids(storage_dir=None)`;
`cli.py` gains a `list` subcommand built on it. `python -m
contract_platform list --storage-dir DIR` now enumerates what's already
committed — the natural next gap after Slice 1, named directly in that
slice's own "Next" note.

**Chosen because it was the one CLI gap already named with real
reasoning, not because it was next on a list.** Slice 1's `ingest` could
report review items on rejection but gave no way to see what's already
been committed from a separate invocation — and a CLI's in-memory cache
always starts empty on every new process, so without this, `list` isn't
a nice-to-have, it's the only way a second command could ever discover
what a first one committed.

**A real design point worth naming: `main()` needed real subcommands for
the first time.** Slice 1's flat `main(["exim", pdf, ...])` structure
only worked because there was exactly one command. Adding a second
forced `argparse` subparsers (`ingest`, `list`) — a real, evidenced
restructuring, not a preemptive one; it wasn't done in Slice 1 because
nothing yet justified it.

**Two pre-existing tests corrected, not silently changed** — the same
"corrected, not weakened" discipline this project has applied to every
slice that changed real, evidenced behavior. Slice 1's two `main()`-level
tests invoked the old flat form; both were updated to
`main(["ingest", ...])` and documented as a deliberate correction in the
test file's own docstring, not quietly rewritten.

**Same `storage_dir` discipline as every registry function before
it.** `list_committed_scope_ids()` unions the in-memory cache with
`storage_dir`'s `*.json` files only when `storage_dir` is explicitly
given — omitting it never silently reflects disk-only entries, matching
`get_committed_scope`'s existing behavior exactly.

**No Contract Model, `pricing_engine`, or adapter change.**

**Proven (`tests/test_cli.py`, 4 new, 2 corrected):** a freshly committed
scope appears in its own `storage_dir`'s listing; the real point of this
command — clearing the in-memory cache (simulating a new process) and
still finding the scope via `storage_dir` — works; omitting `storage_dir`
never silently reflects a disk-only entry; `main(["list", ...])` prints
real committed scope ids. Also verified with a genuine two-process
subprocess smoke test outside the test suite: `ingest` in one `python -m
contract_platform` invocation, `list` in a completely separate one,
correctly finding what the first process committed — real cross-process
persistence, not just composed test imports.

**Exit criteria:** 156/156 total, 152 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Real, undecided next commands for the CLI: `price` (needs evidence for
how booking details should be supplied on a command line) and `review`/
`correct` (the CLI-side completion of the M5 review loop — a rejected
scope's draft form isn't persisted anywhere yet, only committed scopes
are, so this would need that gap closed first, not just a new command).
Schema migration and a fourth adapter remain blocked on the same
missing real-world evidence as before. Decided by inspection when the
next slice starts.

---

# M6, Slice 3 — Draft Persistence + CLI `review`/`correct`: COMPLETE

Closes the CLI's most visible dead end: `registry/store.py` gains
`save_draft_scope()` / `load_draft_scope()` / `discard_draft_scope()`;
`commit_scope()` now saves a rejected scope as a draft whenever
`storage_dir` is given, and discards it once a later commit succeeds.
`cli.py` gains `review` and `correct` subcommands built on this — the
first way to actually act on a rejection from the command line, not
just see it and stop.

**Chosen after re-inspecting the whole project fresh, not by reading the
previous "Next" note** (which happened to name the same gap — re-derived
independently by asking what a real user would actually hit first).
Running `ingest`, seeing "Rejected: 2 fields need review", and then
having no way to proceed via the CLI at all is the most visible dead end
in the product today — more so than a `price` command (only useful once
a scope is already committed) or an API (no scaffolding or dependency
evidence anywhere in this codebase, the same absence that has ruled out
an API/UI pivot every time it's been checked).

**The real reason this needed its own slice, not just a CLI addition: a
rejected scope had no persistence at all before this.** Every previous
persistence slice (M5 Slice 5) only covered *committed* scopes. A
rejected scope existed only in the calling process's memory — gone the
moment that process exited, which made a CLI review/correct loop across
separate invocations structurally impossible, not just unbuilt.

**Reuses `contract_model/serialization.py` exactly the way committed-
scope persistence already does** — the same mechanism applied to a
second real state (draft, not just committed), not a new one. Drafts
live in a `drafts/` subdirectory, deliberately kept separate from
committed scopes' `<scope_id>.json` files at the top level — "committed"
and "draft" must never be confused by filename alone.

**A deliberate, honest design choice: every rejection saves a draft, not
just LOW-confidence-field rejections.** A scope rejected purely for a
blocking validation error (e.g. a `RoomType` with no `Rate`) also gets
saved — `review_ui.list_review_items()` can't actually fix that kind of
problem (it only surfaces LOW-confidence fields), so the CLI's `review`
command will honestly show "0 fields need review" alongside the real
validation issue count in that case, rather than hiding that the scope
is still rejected for a different reason.

**One pre-existing test corrected, not silently weakened.**
`test_a_rejected_scope_is_never_written_to_disk` asserted the entire
`storage_dir` stayed empty on rejection — true only because drafts
didn't exist yet. Renamed to `test_a_rejected_scope_is_never_committed_to_disk`
and narrowed to what it actually verifies (no `<scope_id>.json` at the
top level), with the new, real draft-file behavior asserted explicitly
alongside it — not dropped, not glossed over.

**`correct` applies one field per invocation, not a batch** — matching
how a human actually works through a review list (fix one, see the
result, fix the next), not a shape nothing has evidenced a need for.
`--value` is typed as an integer in `argparse` — the only real
evidenced correction type anywhere in this project (Alltours' real
occupancy counts) — rather than speculatively supporting arbitrary
value types no real data has ever required.

**No Contract Model change.**

**Proven (`tests/test_registry_drafts.py`, 6 new; `tests/test_cli.py`,
6 new):** direct save/load round-trip of a draft; `commit_scope()`
itself saves the draft on rejection, with no draft saved at all when
`storage_dir` is omitted; the real end-to-end loop — Alltours' real DZP
scope rejected, saved as a draft, loaded fresh from disk (not the
original in-memory object), corrected via `review_ui`, and
re-committed successfully, with the draft discarded afterward, not left
stale; at the CLI level, `review` lists real review items from a saved
draft, `correct` applies one field and reports either "still needs
review" or "committed successfully," and a full `main()`-driven
`ingest -> review -> correct -> correct -> committed` sequence closes
the loop end-to-end.

**Verified beyond the test suite, with real separate process
invocations** — not just composed test imports: `python -m
contract_platform ingest` (rejected) -> `review` -> `correct` (still
needs review) -> `correct` (committed successfully) -> `list` (shows
the now-committed scope) — four genuinely independent process runs,
confirming the loop survives real process boundaries, which is the
entire point of this slice.

**Exit criteria:** 168/168 total, 156 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

The CLI's remaining real, undecided command is `price` — pricing a
specific booking against an already-committed scope. Genuinely blocked
on a design question, not effort: a booking needs a `room_type_id` (a
UUID), and nothing today lets a CLI user discover one without already
having Python access to inspect a scope — `price` likely needs a
`describe`/`show` command first, to list a committed scope's room types
in a human-usable way, not just its counts. Schema migration and a
fourth adapter remain blocked on the same missing real-world evidence as
every prior slice. Decided by inspection when the next slice starts.

---

# M6, Slice 4 — CLI `describe` + `price` commands: COMPLETE

Closes the single most visible product gap in the whole project: this
is a pricing platform, and there was no way to get a price out of it
from the command line. `cli.py` gains `run_describe()`/`RoomTypeSummary`
and `run_price()`/`PriceResult`, plus `describe` and `price` subcommands
built on them.

**Chosen over registry concurrency hardening — the other real candidate
from the last full project assessment — on product-impact grounds, not
by following either the previous "Next" note or the assessment
mechanically.** Concurrency safety closes a risk nothing has ever
exercised: this is still a single-operator CLI, no server, no evidence
anywhere of concurrent access actually happening. `price` closes a gap
every single use of this system has already run into — every `ingest`
example throughout this whole project ends at "committed" or "rejected,"
never at an actual price, despite the entire point of the engine
underneath being pricing. Re-inspected the codebase specifically to
weigh these two against each other before choosing, rather than
defaulting to the order they were written down in.

**`describe` exists because `price` needed it, not as its own
independent feature.** `price` requires a `room_type_id` — a UUID — and
nothing before this slice let a CLI user discover one without already
having Python access to inspect a committed scope directly. This was
the exact blocker M6 Slice 3's own "Next" note had already named.

**`price` is deliberately scoped to the core booking fields only** —
room, dates, adult/child/infant counts — with no
`BookingApplicabilityContext` (guest ages, booking date) support yet.
Nothing has evidenced a CLI-level need for per-guest or
per-booking-date conditions specifically, as opposed to what
`--adults`/`--children`/`--check-in`/`--check-out` already cover — the
same restraint every prior CLI slice has applied to unevidenced shapes.

**No Contract Model or `pricing_engine` change.** Pure orchestration
over `get_committed_scope()`, `validate_booking()`, and `price_booking()`
— all already proven — the same "thin orchestration only" discipline
`cli.py`'s three prior slices have all followed.

**Proven (`tests/test_cli.py`, 8 new):** `describe` lists a committed
EXIM scope's real room type with its real `room_type_id` and canonical
code; it raises clearly for an unknown/uncommitted id rather than
returning an empty, falsely reassuring list; `price`, using the
`room_type_id` `describe` actually returned, produces the real known
invoice total (46.00 PPPN × 7 nights × 2 adults = 644.00); a 4-adult
booking against a room whose real occupancy combos top out at 3 adults
is correctly reported invalid with the real `OCCUPANCY_NOT_PERMITTED`
issue, not silently priced; both commands are proven at the `main()`
level for exit codes and printed output, not just as internal functions.

**Verified beyond the test suite, with genuinely separate process
invocations** — the strongest proof this project's discipline asks for:
`python -m contract_platform ingest` (committed) -> `describe` (a
completely separate process, discovering the real `room_type_id`) ->
`price` (a third separate process, producing `Total: 644.00 USD`) — the
first time this system has produced an actual price entirely from the
command line, PDF in, real number out.

**Exit criteria:** 176/176 total, 168 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

Every core CLI verb this project's own evidence has pointed to is now
built: `ingest`, `list`, `review`, `correct`, `describe`, `price`. What
remains, genuinely undecided: registry concurrency hardening (atomic
writes, file locking — a real risk, but still unexercised by any actual
concurrent usage); an HTTP API layer over the same orchestration
functions `cli.py` already proves out (no scaffolding or dependency
evidence anywhere yet); `price` gaining `BookingApplicabilityContext`
support (per-guest ages, booking date) once a real CLI use case asks for
it. Schema migration and a fourth adapter remain blocked on the same
missing real-world evidence as every prior slice. Decided by inspection
when the next slice starts.

---

# M6, Slice 5 — `price` gains guest-age and booking-date context: COMPLETE

Closes the gap Slice 4 deliberately left open. `run_price()` and the
`price` command gain `--child-ages`, `--adult-ages`, and
`--booking-date`, wired straight through to the same
`BookingApplicabilityContext`/`GuestAge` objects `pricing_engine` has
used since M4 — no new engine logic anywhere in this slice.

**Chosen by re-inspecting the CLI immediately after Slice 4, not by
treating "the CLI is done" as settled.** Real inspection found that a
meaningful share of already-built, already-tested `PricingRule`s were
completely unreachable through `price` as it stood: EXIM's CHILD_PCT
age-band discounts (M4 Slice 3), Alltours' Senior Discount (M4), and
Anex's Release Rule warning (M4) all require `BookingApplicabilityContext`
— none of which `price` could supply. A user could `ingest`, `commit`,
and `describe` these scopes perfectly, then get a price that silently
skipped real, evidenced discount and warning logic for lack of any way
to say a guest's age or when the booking was being made.

**Valid-booking output now also prints `WARNING`-level issues, not just
the invoice.** Previously `price` only surfaced issues on the invalid
(`ERROR`) path — a booking inside Anex's real Release Rule window would
price successfully with the warning silently dropped. Extends the same
"never hide information" discipline `review`/`correct` already follow to
a case `price` hadn't covered: a *valid* booking with something still
worth knowing.

**A real bug caught during test-writing, not shipped.** An early version
of the Senior Discount test assumed Alltours' DZP scope would commit on
the first `ingest` — it forgot DZP's real occupancy fields are
LOW-confidence (flagged since M3) and always need `review`/`correct`
first. Caught immediately by the test failing with a clear, specific
error; fixed to follow the same correction pattern every other
Alltours-based test in this project already uses, not treated as a
special case.

**No Contract Model or `pricing_engine` change.** Pure CLI-to-engine
wiring — `child_ages`/`adult_ages` become `GuestAge` objects,
`booking_date` becomes part of the same `BookingApplicabilityContext`
`AgeCondition` and `DaysBeforeArrivalCondition` matching has used since
M4; nothing about how those get matched or evaluated changed.

**Proven (`tests/test_cli.py`, 4 new):** a 2-adult/1-child EXIM DR01
booking with the child's real age (4) supplied produces the real
100%-reduction `CHILD_PCT` line (`unit_rate` 0.0), not the standard
adult rate; a 2-adult Alltours DZP booking with one identified senior
(65) and one non-senior (45) produces exactly one standard-rate line and
one 10%-reduced line; a 3-adult Anex booking made 3 real days before a
real check-in (inside the real 5-day release window) surfaces the real
`BOOKING_INSIDE_RELEASE_PERIOD` warning; `main()`'s printed output
includes that warning alongside a still-successful invoice, proving a
warning never blocks pricing.

**Verified beyond the test suite, with a genuine five-process subprocess
sequence** — `ingest` (rejected) -> `correct` x2 (committed) ->
`describe` (real `room_type_id`) -> `price --adult-ages 65 45`,
each a separate `python -m contract_platform` invocation, producing the
real numbers: one adult at 66.00 EUR, one senior at the real
10%-discounted 59.40 EUR, `Total: 877.80 EUR`.

**Exit criteria:** 180/180 total, 168 pre-existing, all unchanged.
Dependency-boundary test still green.

## Next

The CLI now reaches every real `PricingRule` and `Restriction` type any
of the three adapters has ever built. What remains, genuinely
undecided: registry concurrency hardening (atomic writes, file locking —
a real risk, still unexercised by any actual concurrent usage); an HTTP
API layer over the same orchestration functions `cli.py` already proves
out (no scaffolding or dependency evidence anywhere yet). Schema
migration and a fourth adapter remain blocked on the same missing
real-world evidence as every prior slice. Decided by inspection when the
next slice starts.

---

# Pivot: product feature -> engineering infrastructure — PDF page cache

Given full ownership of the next decision, re-inspected the whole
project from scratch rather than continuing down the CLI/product-feature
track or picking the next item off the prior "Next" note. The highest-
value finding wasn't a missing feature — it was a concrete, extensively
observed engineering problem: `document_parser.read_pdf_pages()` re-runs
600-DPI OCR from scratch on every single call, with zero caching
anywhere. Confirmed by reading `pdf_reader.py` directly before writing
any code, the same "inspect first" discipline every slice has followed —
this wasn't assumed from the pattern of past pain, it was verified.

**The evidence wasn't hypothetical — it was the project's own operating
history.** Across many recent slices, the full regression suite needed
2-3 relaunches per attempt and 10-15+ minutes to complete, because dozens
of independent test functions each build an Alltours scope from the same
PDF, the same pages, producing byte-identical OCR input every time, and
none of that redundant work was ever cached. This is the single most
concretely evidenced problem in the entire project's history — more data
points than any adapter gap or CLI feature ever had — and it directly
degrades the reliability of the one thing every other slice depends on:
the full regression suite itself.

# Engineering Infrastructure Slice — PDF Page Cache: COMPLETE

`document_parser/pdf_reader.py` gains an in-memory cache, keyed by
`(absolute path, file mtime, page number)`. A second read of a page
already extracted in this process — native text or OCR — returns the
cached result with zero re-extraction.

**Judged safe to default-enable with no new parameters, unlike every
`storage_dir`-style parameter elsewhere in this project.** Registry
persistence always requires an explicit, caller-supplied location
because it's real business data — guessing a default would be exactly
the kind of silent invention Part 5 forbids. This is different in kind:
a cache of a *deterministic* function's output (the same path + mtime +
page number always extracts to the same text) cannot silently produce a
wrong result. A cache miss only ever costs time, never correctness — so
there's no business-data risk to guard against by requiring
configuration, and none was added.

**Scoped to in-memory, per-process only — not persisted to disk.**
Covers the concretely observed problem (every full-suite run is one
process; dozens of tests in that process re-read the same pages)
without taking on a bigger, less-evidenced design question
(cache-directory location, eviction, cross-run invalidation policy).
Disk-level caching — which would also help the many separate
`python3 -m contract_platform`/ad hoc process invocations used
throughout this project's own development — is a real, plausible future
enhancement, named here rather than built speculatively.

**Correctness guarded explicitly, not assumed.** The cache key includes
file mtime specifically so a modified PDF at the same path never
silently reuses stale text — proven directly (not just reasoned about)
by a test that touches a temp copy's mtime forward and confirms the
cache grows a distinct second entry rather than reusing the first.

**No Contract Model, `pricing_engine`, or adapter change** — and
critically, no adapter or test needed to change at all to benefit from
this. Every existing caller of `read_pdf_pages()` gets the speedup for
free, with byte-identical results, because caching a pure function's
output is invisible to every caller by construction.

**Proven (`tests/test_pdf_reader_caching.py`, 5 new):** a second read of
the same real Alltours page doesn't call `pytesseract` again at all
(verified directly, not inferred from timing alone); a cached read is
measurably faster than the first; different pages of the same file
cache independently; native-text extraction (EXIM) stays correct under
caching; a modified file's mtime change produces a genuinely new cache
entry, not a stale reuse.

**The real-world proof, not just unit tests:** four Alltours test
modules that previously each independently paid ~30-50s of OCR cost
— roughly 150-200 seconds combined — now complete together in **41.7
seconds total**, because page 1's OCR now runs exactly once across all
of them. The complete full-suite regression (185 tests) ran to
completion in **129 seconds, in a single attempt, with zero crashes** —
down from 10-15+ minutes and 2-3 relaunches every previous full run in
this project's history needed.

**Exit criteria:** 185/185 total, 180 pre-existing, all unchanged.
Dependency-boundary test still green. Full regression now completes
reliably in about 2 minutes instead of 10-15+, in one attempt.

## Next

Disk-level page caching (surviving across separate process invocations)
is the one natural, evidenced follow-on to this slice, named but not
built — genuinely useful given how much of this project's own
development involved repeated separate `python3` invocations against
the same fixtures, but a real design question (cache location,
staleness policy across runs) deserving its own inspection rather than
being bundled in speculatively here. Beyond that, the product-facing
items are unchanged from before this pivot: registry concurrency
hardening, an HTTP API layer, schema migration, and a fourth adapter —
each still exactly as blocked or undecided as they were before this
slice, since this was infrastructure work, not a product decision.

---

# Engineering Infrastructure Slice — Atomic Registry Writes: COMPLETE

`registry/store.py` gains `_atomic_write()`: every write to disk (a
committed scope's file, a draft's file) now writes to a temp file in
the same directory first, then `os.replace()`s it into place, instead
of a plain `open(path, "w")`.

**Chosen by continuing the same "inspect the whole project, find the
highest real value" mandate that led to the PDF page cache — not by
picking the next item off a list.** This was this project's own full
assessment's top-flagged risk, deferred twice already in favor of
product features (M6 Slices 4 and 5) on the reasoning that nothing had
exercised it yet. Re-inspecting after the cache slice, the reasoning for
deferring it further didn't hold up as well the second time: this
protects the one place this system persists real data, the fix is small
and well-understood (a standard atomic-write pattern), and the risk it
closes — a crash or a genuinely concurrent writer leaving a corrupted,
partially-written JSON file behind — is strictly worse than anything a
missing CLI command costs. Continuing to defer a well-understood,
cheap, real correctness fix in favor of more features stops being the
right call once there's nothing more urgently unproven left to build.

**Deliberately scoped to atomicity only, not full write-write mutual
exclusion.** `os.replace()` guarantees a reader never observes a
partially-written file — but two genuinely concurrent commits to the
same scope id still resolve last-write-wins after this slice. Real file
locking (a lock file, timeout handling, contention behavior) is a
separate, smaller-but-real design question this slice doesn't attempt
without more specific evidence of the exact concurrency pattern to
design a lock around — named here, not built speculatively, the same
restraint every unevidenced shape in this project has gotten.

**No Contract Model or `pricing_engine` change; no adapter or CLI
change either.** Every existing caller of `commit_scope`/
`save_draft_scope` benefits automatically — the write path changed, not
its callers' contract with it.

**Proven (`tests/test_registry_atomic_writes.py`, 6 new):** a write
produces a complete, correctly-parseable file; no stray temp files are
left behind, on a fresh write or an overwrite; overwriting fully
replaces the previous content, never a leftover mix. The real proof —
**25 genuine OS-level threads writing to the same path concurrently**
must never produce a corrupted or partially-written file: the result is
always exactly one complete writer's content, fully parseable JSON,
never a truncated or interleaved mix of two writers' bytes. `commit_scope`
and `save_draft_scope` themselves leave no stray temp files after a real
commit/save, proving the integration, not just the primitive.

**Verified with a real CLI smoke test too:** `ingest` via `python -m
contract_platform` against the real EXIM fixture, storage directory
inspected directly afterward — exactly one file, the committed scope's
JSON, nothing else.

**Exit criteria:** 191/191 total, 185 pre-existing, all unchanged.
Dependency-boundary test still green. Full regression completed in 153
seconds, in one attempt, continuing the reliability the PDF cache slice
established.

## Next

Full write-write mutual exclusion (a real lock, not just atomicity) is
the one natural, evidenced follow-on named but not built this slice —
same reasoning as disk-level page caching after the cache slice: real,
plausible, but a separate design question deserving its own inspection.
Disk-level page caching itself remains open too. Beyond those two,
unchanged from before: an HTTP API layer, schema migration, and a
fourth adapter — each still exactly as blocked or undecided as before
this slice.

---

# Engineering Infrastructure Slice — Consolidate LOW-Confidence Filtering: COMPLETE

`contract_model/entities.py` gains `iter_low_confidence(scope)` — the
subset of `iter_extracted()` whose confidence is `LOW`. `registry.
commit_scope()` and `review_ui.list_review_items()` are both rewired to
use it instead of independently re-deriving the same filter.

**Chosen by continuing the same "inspect the whole project for the
highest real value" mandate as the two slices before it, applied this
time to code quality rather than performance or durability.** Checking
whether `validation.confidence.assess()` — a module clearly designed to
answer "does this scope need review" — was actually used anywhere in
production code turned up a real finding: it wasn't. `registry.store.
commit_scope()` re-implemented the identical `iter_extracted()` +
`confidence == LOW` filter independently. Checking further,
`review_ui.corrections.list_review_items()` had written the *same*
filter a third time. Three independently-maintained copies of one
decision — "which fields need review" — is exactly the "two
independent, drifting copies" risk `iter_extracted()`'s own docstring
already warns about for a different concern (where Extracted values
live); here it was the same risk applied to a filtering decision instead
of a traversal path, found by inspection, not assumed from that
docstring's warning.

**A pure refactor — the safest kind of change, and this project's own
discipline made it easy to prove that's all it was.** No new
capability, no changed decision logic, no changed output shape:
`commit_scope()` and `list_review_items()` both behave exactly as
before, verified by every one of their existing tests passing
unmodified. The only change is where the filtering logic is defined —
once, not three times.

**Why `assess()` itself wasn't rewired to use the new generator.**
`assess()` counts *all three* confidence levels (`HIGH`/`MEDIUM`/`LOW`),
not just `LOW` — it still needs the full `iter_extracted()` walk, so
consolidating it onto `iter_low_confidence()` wouldn't remove any real
duplication there. Noted in `iter_low_confidence()`'s own docstring:
a caller that only needs the yes/no "does this need review" answer
(not the field list) should still prefer `assess(scope).needs_review`
for that specific question — this generator is for callers needing the
actual fields, which `assess()` was never built to provide.

**No Contract Model or `pricing_engine` change; no behavior change for
any adapter, the CLI, or any existing caller.** A now-unused
`ConfidenceLevel` import was removed from `registry/store.py` as part of
the cleanup — the only other file touched.

**Proven (`tests/test_model_and_expressions.py`, 2 new):**
`iter_low_confidence()` yields exactly the LOW-confidence fields (and
nothing else) for a scope with a mix of confidence levels; it yields
nothing at all for a fully HIGH-confidence scope. Both real consumers —
`registry`'s commit-gate tests and `review_ui`'s correction tests — were
re-run in full afterward and pass completely unchanged, the actual proof
this was a pure refactor and not a behavior change in disguise.

**Exit criteria:** 193/193 total, 191 pre-existing, all unchanged.
Dependency-boundary test still green. Full regression completed in 154
seconds, in one attempt — the reliability the last two engineering
slices established continues to hold.

## Next

No new gaps surfaced by this slice specifically — it was a
consolidation, not a discovery of further duplication elsewhere (checked
directly: no other module independently re-derives an `iter_extracted()`
filter). The real open items are unchanged from before: full write-write
mutual exclusion for the registry, disk-level page caching, an HTTP API
layer, schema migration, and a fourth adapter — each still exactly as
blocked, undecided, or deliberately deferred as before this slice.

## HTTP API + launch hardening

Built after the slice above, undocumented until now: `api/app.py`
(Flask, application-factory pattern) exposes the same five operations
the CLI has always had — ingest, list, describe, review, correct,
price — as HTTP routes, calling into a new `orchestration.py` module
extracted verbatim from `cli.py` so both transports share one
business-logic layer (see that module's own docstring for why).

Two things were added specifically because this is the layer real
outside callers hit, not just the CLI operator:

- **API-key auth.** Every route requires an `X-API-Key` header matching
  `CONTRACT_PLATFORM_API_KEY`. If that env var (or the equivalent
  `create_app(api_key=...)` argument) isn't set, the app refuses to
  serve *any* request (503) — fails closed, not open.
- **Path scoping.** `pdf_path` and `storage_dir` were, and still are,
  caller-supplied strings. Once this became a network-reachable API
  rather than a local CLI, that meant anyone with a valid key could
  make the server read or write arbitrary paths on disk. If
  `CONTRACT_PLATFORM_UPLOAD_DIR` / `CONTRACT_PLATFORM_DATA_DIR` are
  set, every path is checked (via `os.path.realpath`, so symlinks and
  `../` traversal don't bypass it) to resolve inside the configured
  directory; otherwise the request is rejected with 400. Unset, there's
  no restriction — the same permissive behavior the CLI always had —
  so this is opt-in, and deployment must opt in.

**Proven (`tests/test_api.py`, all new):** the full ingest → review →
correct → describe → price loop over real HTTP against real fixtures;
missing/wrong/unset API key all rejected (401/401/503); a `pdf_path`
outside a configured upload dir rejected (400). 208/208 total, all
pre-existing tests unchanged.

**Deployment package:** `requirements.txt` (pinned: Flask, pdfplumber,
gunicorn), `wsgi.py` (real WSGI entrypoint — Flask's dev server is
never used to actually serve this), `Dockerfile`, `docker-compose.yml`,
and `.env.example`. `docker-compose up` builds the image, mounts
persistent volumes for storage/uploads, and refuses to start without
`CONTRACT_PLATFORM_API_KEY` set in `.env`.

**Not yet built, still open:** the two items already listed above
(registry write-write locking, disk-level caching) plus, now that the
API is real: request size/rate limiting, HTTPS termination (left to
whatever sits in front — nginx/Caddy/a cloud load balancer — not
built into the Flask app itself), and a non-CLI/non-curl human
interface for day-to-day use.

## Browser UI

`api/static/index.html` — one static page (vanilla HTML/JS, no build
step, no external dependencies), served at `/` by the same Flask app
that serves the API, so there's exactly one URL to open. Covers the
full loop a day-to-day operator needs: enter the API key once (kept in
the browser tab's session storage, never sent anywhere but this
server's own API), ingest a contract, list saved scopes, open one to
see its room types and any fields still needing review, correct a
value, and price a booking.

`/` and `/static/*` are exempted from the API-key check in
`before_request` — the page shell has no data in it, only the calls its
JS makes to `/scopes*` do, and those still require the real key. Proven
by one new test (`test_ui_root_loads_without_an_api_key`); 209/209
total.

**Not covered by the UI yet:** it still asks for `pdf_path` and
`storage_dir` as raw server-side paths rather than a file upload —
matching what the API itself accepts today, not a UI limitation on top
of a more capable API. Actual file upload (multipart, saved server-side
into the configured upload dir) is the natural next step if typing a
path on the server's disk turns out to be the wrong workflow for daily
use.

## Registry write-write locking

The last item on the atomic-writes slice's own deferred list, closed
now: `registry.store.scope_lock(scope_id, storage_dir)` serializes the
entire load → modify → commit sequence per scope id, not just the final
disk write atomic-writes already covered. Two layers — a
`threading.Lock` for same-process concurrency (multiple threads in one
gunicorn worker) and, when `storage_dir` is given, an `flock()` on a
per-scope lock file under `<storage_dir>/.locks/` for cross-process
concurrency (gunicorn's multi-worker default, or two separate CLI
runs). `orchestration.run_correct()` and `run_ingest()` now wrap their
full read-modify-write sequences in it — locking only the final write
would not have closed the real gap, since the stale read that causes a
lost update already happens before that point.

**Proven with real thread concurrency, not just a logical argument**
(`tests/test_registry_locking.py`, 2 new): a deliberately slow critical
section entered by 10 threads at once never overlaps; and, using
Alltours' real DZP fixture (the same two-LOW-confidence-field scope
`test_review_ui_corrections.py` already relies on), two genuine threads
correcting its two different fields at the same instant — synchronized
with a `Barrier` so neither can simply finish before the other starts —
always converge to a fully committed scope, regardless of which thread
acquires the lock first. Both new tests re-run 10–20x in isolation with
no flakiness observed. 211/211 total, all pre-existing tests unchanged.

**Known limitation:** `fcntl` is POSIX-only, so the cross-process layer
is inactive on Windows — irrelevant for this project's only real
deployment target (the Linux-based Dockerfile), but worth knowing if
this is ever run outside a container.

## Launch-readiness status

Every item this project's own assessments flagged as blocking real use
is now closed: API authentication, path-traversal protection,
containerized deployment, a browser UI, and write-write registry
locking. What remains is explicitly deferred, not overlooked — disk-
level page caching (a performance optimization, not a correctness
gap), schema migration (no schema change has occurred yet to migrate
from), a fourth tour-operator adapter, and file-upload support in the
UI (currently server-side paths, matching the API) — each undecided
for the same reason this project has deferred everything else without
concrete evidence: no real use has yet exercised them.
