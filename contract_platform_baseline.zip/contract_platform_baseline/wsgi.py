"""
Production entrypoint for the HTTP API.

Run with a real WSGI server, never Flask's dev server:
    gunicorn -w 4 -b 0.0.0.0:8000 wsgi:app        (Linux/Mac)
    waitress-serve --port=8000 wsgi:app           (Windows)

Requires CONTRACT_PLATFORM_API_KEY to be set in the environment -- the
app itself refuses to serve any request (503) if it isn't, so there is
no silent "forgot to set it" failure mode.
"""
from contract_platform.api.app import create_app

app = create_app()
