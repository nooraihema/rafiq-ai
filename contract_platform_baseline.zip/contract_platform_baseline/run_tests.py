import sys, traceback, importlib

test_modules = [
    "contract_platform.tests.test_model_and_expressions",
    "contract_platform.tests.test_dependency_boundaries",
    "contract_platform.tests.test_exim_walking_skeleton",
    "contract_platform.tests.test_anex_walking_skeleton",
    "contract_platform.tests.test_alltours_walking_skeleton",
    "contract_platform.tests.test_applicability_and_composition",
    "contract_platform.tests.test_pricing_engine_rate_resolution",
    "contract_platform.tests.test_exim_full_room_coverage",
    "contract_platform.tests.test_exim_supplement_rules",
    "contract_platform.tests.test_exim_child_pct_rules",
    "contract_platform.tests.test_exim_min_max_stay",
    "contract_platform.tests.test_anex_supplement_rules",
    "contract_platform.tests.test_alltours_third_adult_reduction",
    "contract_platform.tests.test_alltours_longstay_reduction",
    "contract_platform.tests.test_alltours_senior_discount",
    "contract_platform.tests.test_anex_release_rule",
    "contract_platform.tests.test_exim_deposit_payments",
    "contract_platform.tests.test_alltours_cancellation_policy",
    "contract_platform.tests.test_registry_commit_gate",
    "contract_platform.tests.test_review_ui_corrections",
    "contract_platform.tests.test_end_to_end_workflow",
    "contract_platform.tests.test_serialization",
    "contract_platform.tests.test_registry_persistence",
    "contract_platform.tests.test_cli",
    "contract_platform.tests.test_registry_drafts",
    "contract_platform.tests.test_pdf_reader_caching",
    "contract_platform.tests.test_registry_atomic_writes",
    "contract_platform.tests.test_registry_locking",
    "contract_platform.tests.test_api",
]

total, passed, failed = 0, 0, 0
for mod_name in test_modules:
    mod = importlib.import_module(mod_name)
    test_funcs = [getattr(mod, n) for n in dir(mod) if n.startswith("test_")]
    for func in test_funcs:
        total += 1
        try:
            func()
            print(f"PASS: {mod_name}.{func.__name__}")
            passed += 1
        except Exception:
            print(f"FAIL: {mod_name}.{func.__name__}")
            traceback.print_exc()
            failed += 1

print(f"\n{passed}/{total} passed, {failed} failed")
sys.exit(1 if failed else 0)
